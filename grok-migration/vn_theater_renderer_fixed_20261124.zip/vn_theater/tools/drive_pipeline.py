#!/usr/bin/env python3
"""Read one matched Gemini MP3+JSON from private Drive; upload its rendered video.

Auth: GOOGLE_DRIVE_SA_JSON env containing a service-account JSON. The user must share
both source and output folders, and the avatar/BGM ZIPs, with that service account.
Do not embed Google credentials, audio, or avatar files in this public repository.
"""
from __future__ import annotations
import argparse
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile


def drive():
    try:
        from google.oauth2 import service_account
        from googleapiclient.discovery import build
    except ImportError as exc:
        raise SystemExit('Missing google-api-python-client/google-auth (see workflow)') from exc
    raw = os.getenv('GOOGLE_DRIVE_SA_JSON', '')
    if not raw:
        raise SystemExit('GOOGLE_DRIVE_SA_JSON is missing; workflow is not authenticated')
    try:
        cfg = json.loads(raw)
        auth = service_account.Credentials.from_service_account_info(
            cfg, scopes=['https://www.googleapis.com/auth/drive'])
    except (ValueError, KeyError) as exc:
        raise SystemExit('GOOGLE_DRIVE_SA_JSON is invalid') from exc
    return build('drive', 'v3', credentials=auth, cache_discovery=False)


def list_folder(svc, folder: str) -> list[dict]:
    rows, token = [], None
    while True:
        resp = svc.files().list(
            q=f"'{folder}' in parents and trashed = false",
            fields='nextPageToken,files(id,name,mimeType,size,createdTime)',
            pageSize=1000, pageToken=token).execute()
        rows.extend(resp.get('files', []))
        token = resp.get('nextPageToken')
        if not token:
            return rows


def select_pair(files: list[dict], code: str) -> tuple[dict,dict,str]:
    """Never pair two episodes or two version numbers based on recency alone."""
    if not re.fullmatch(r'(?:EP|R|Z)\d{1,5}', code, re.I):
        raise ValueError('Episode code must be EP##, R##, or Z##')
    code = code.upper()
    candidates = []
    for f in files:
        name = f.get('name', '')
        if not re.match(r'^' + re.escape(code) + r'(?:[_ .-]|$)', name, re.I):
            continue
        ext = Path(name).suffix.lower()
        if ext not in ('.json', '.mp3'):
            continue
        ver = re.search(r'(?:^|[_ .-])v(\d+)(?:[_ .-]|$)', name, re.I)
        candidates.append((f,ext, int(ver.group(1)) if ver else 0))
    grouped = {}
    for f,ext,ver in candidates:
        grouped.setdefault(ver, {}).setdefault(ext,[]).append(f)
    for ver in sorted(grouped, reverse=True):
        group=grouped[ver]
        if '.mp3' in group and '.json' in group:
            choose=lambda ext: sorted(group[ext],key=lambda f:f.get('createdTime',''), reverse=True)[0]
            return choose('.mp3'),choose('.json'),f'v{ver}'
    raise FileNotFoundError(f'No complete {code} MP3+JSON pair in input folder')


def download_file(svc,file_id: str,dest: Path) -> None:
    from googleapiclient.http import MediaIoBaseDownload
    dest.parent.mkdir(parents=True, exist_ok=True)
    req=svc.files().get_media(fileId=file_id)
    with dest.open('wb') as out:
        obj=MediaIoBaseDownload(out, req, chunksize=4*1024*1024)
        done=False
        while not done:
            _, done=obj.next_chunk()


def unpack_assets(zip_path: Path, dest: Path) -> None:
    # Protect against path traversal from a swapped cloud asset ZIP.
    root=dest.resolve()
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            target=(root / info.filename).resolve()
            if target != root and root not in target.parents:
                raise ValueError(f'Unsafe archive path: {info.filename}')
        z.extractall(root)


def fetch(svc,args):
    files=list_folder(svc,args.input_folder)
    mp3, js,ver=select_pair(files,args.episode)
    incoming=Path(args.root).resolve()/'vn_theater'/'incoming'
    incoming.mkdir(parents=True,exist_ok=True)
    audio=incoming/f'{args.episode}_audio.mp3'
    data=incoming/f'{args.episode}_render.json'
    download_file(svc,mp3['id'],audio)
    download_file(svc,js['id'],data)
    try:
        j=json.loads(data.read_text('utf-8'))
    except Exception as e:
        raise ValueError('Downloaded JSON is not valid UTF-8 JSON; reject Base64 masquerading as JSON') from e
    if str(j.get('episode_code','')).upper()!=args.episode.upper():
        raise ValueError(f'JSON episode_code mismatch: {j.get("episode_code")} != {args.episode}')
    head=audio.read_bytes()[:4]
    if not (head.startswith(b'ID3') or (len(head)>=2 and head[0] == 0xff and head[1]&0xe0 == 0xe0)):
        raise ValueError('Downloaded MP3 header invalid; reject Base64 masquerading as audio')
    duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(audio)], text=True).strip())
    expected=float(j.get('total_audio_duration_sec') or 0)
    if expected and abs(duration-expected)>3:
        raise ValueError(f'Audio/JSON duration mismatch {duration:.2f}s vs {expected:.2f}s')
    for zip_id,label in [(args.avatars_zip,'avatars'),(args.bgm_zip,'bgm')]:
        if not zip_id:
            raise ValueError(f'Missing {label} zip file ID; do not render using stand-in avatars')
        path=Path(args.root).resolve()/f'{label}.zip'
        download_file(svc,zip_id,path)
        unpack_assets(path,Path(args.root).resolve())
    print(f'Validated {args.episode} {ver}: audio {duration:.2f}s, matching JSON, private assets loaded')


def upload(svc,args):
    from googleapiclient.http import MediaFileUpload
    path=Path(args.video).resolve()
    if not path.is_file() or path.stat().st_size<10000:
        raise FileNotFoundError('MP4 missing or too small')
    name=f'{args.episode}_GitHub_render_run{args.run_id}.mp4'
    media=MediaFileUpload(str(path),mimetype='video/mp4',resumable=True)
    result=svc.files().create(body={'name':name,'parents':[args.output_folder]},media_body=media,fields='id,name,size,webViewLink').execute()
    print('UPLOADED_VIDEO_ID=' + result['id'])
    print('UPLOADED_VIDEO_URL=' + result.get('webViewLink','https://drive.google.com/file/d/'+result['id']+'/view'))


def main():
    parser=argparse.ArgumentParser()
    subs=parser.add_subparsers(dest='command',required=True)
    f=subs.add_parser('fetch')
    f.add_argument('--episode',required=True)
    f.add_argument('--input-folder',required=True)
    f.add_argument('--avatars-zip',required=True)
    f.add_argument('--bgm-zip',required=True)
    f.add_argument('--root',default='.')
    u=subs.add_parser('upload')
    u.add_argument('--episode',required=True)
    u.add_argument('--output-folder',required=True)
    u.add_argument('--video',required=True)
    u.add_argument('--run-id',required=True)
    args=parser.parse_args()
    svc=drive()
    (fetch if args.command=='fetch' else upload)(svc,args)
if __name__=='__main__':
    main()
