#!/usr/bin/env python3
"""越南语词义自动生成。用法: .venv/bin/python glossary.py script.txt [--outdir out]
优先级：1) 脚本里自带的写法（X = Y / X（Y） / Y(X)） 2) 系列词库 glossary.json（自动累积） 3) 离线机器翻译 Argos（vi→en→zh，标 source=mt）
输出：<script>.gloss.json（本集用到的 词→义）和 out/<EP>_words.txt"""
import re, sys, os, json, argparse
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
LAT = r"[A-Za-zÀ-ỹĐđ]+(?:[ \-][A-Za-zÀ-ỹĐđ]+)*"
CJK = r"[\u4e00-\u9fff]+"
VN_RE = re.compile(LAT)
GPATH = os.path.join(HERE, "glossary.json")

def key(w): return re.sub(r"[!?.,，。！？]+$", "", w.strip()).lower()

def from_script(txt):
    found = {}
    pats = [(rf"({LAT})\s*=\s*({CJK})", 1, 2), (rf"({LAT})\s*[（(]\s*({CJK})\s*[)）]", 1, 2), (rf"({CJK})\s*[（(]\s*({LAT})\s*[)）]", 2, 1)]
    for p, wi, mi in pats:
        for m in re.finditer(p, txt):
            k = key(m.group(wi))
            if re.search(r"[à-ỹđ]", k) or k in found or len(k) <= 6:  # 只要越南语样子的
                found.setdefault(k, m.group(mi)[-4:])
    return found

def shorten(zh):
    zh = re.sub(r"[。，！？、,.!?\s\"“”]", "", zh)
    for p in ("你这个", "我们", "你们", "你", "我", "请"):
        if zh.startswith(p) and len(zh) > len(p) + 1: zh = zh[len(p):]
    return zh[:4]

_mt = None
def mt(word):
    global _mt
    if _mt is None:
        import argostranslate.translate as T; _mt = T
    en = _mt.translate(word, "vi", "en"); zh = _mt.translate(en, "en", "zh")
    return shorten(zh), en

def extract(shots, board, title):
    words = []
    for s in shots:
        for t in [s["line"]] + s["caps"]:
            for m in VN_RE.finditer(t):
                k = key(m.group(0))
                if k and re.search(r"[a-zà-ỹđ]", k) and k not in words: words.append(k)
    return words

def build(script, outdir):
    from render import parse
    txt = open(script, encoding="utf-8").read(); title, shots = parse(script)
    sc = from_script(txt); words = extract(shots, None, title)
    g = json.load(open(GPATH, encoding="utf-8")) if os.path.exists(GPATH) else {}
    ep = re.match(r"(EP\d+)", os.path.basename(script)); ep = ep.group(1) if ep else os.path.splitext(os.path.basename(script))[0]
    res = {}
    for w in words:
        if w in sc: zh, src = sc[w], "script"
        elif w in g: zh, src = g[w]["zh"], g[w]["source"] + "(词库)"
        else:
            try: zh, en = mt(w); src = "mt"
            except Exception as e: print("机器翻译失败:", w, e); zh, src = "", "none"
        res[w] = dict(zh=zh, source=src)
        if src in ("script", "mt") and (w not in g or g[w]["source"] == "mt"):
            g[w] = dict(zh=zh, source=src, first_ep=g.get(w, {}).get("first_ep", ep))
    json.dump(g, open(GPATH, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump({k: v["zh"] for k, v in res.items()}, open(os.path.splitext(script)[0] + ".gloss.json", "w", encoding="utf-8"), ensure_ascii=False)
    os.makedirs(outdir, exist_ok=True); wp = os.path.join(outdir, f"{ep}_words.txt")
    with open(wp, "w", encoding="utf-8") as f:
        f.write("越南语\t中文\t来源\n")
        for k, v in res.items(): f.write(f"{k}\t{v['zh']}\t{v['source']}\n")
    print(open(wp, encoding="utf-8").read()); return res

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("script"); ap.add_argument("--outdir", default=os.path.join(HERE, "out"))
    a = ap.parse_args(); build(a.script, a.outdir)
