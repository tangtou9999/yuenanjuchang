"""聊天风格B：暗黑模式，大字；最新一条又大又亮，旧消息缩小变暗；关键词卡片居中弹出"""
import math
from PIL import Image, ImageDraw
from .chat_common import *
TOP, BOTTOM = 220, 1820
BIG, SMALL = F(66), F(38)

def _cfg(idx): return (BIG, 92, 800) if idx == 0 else (SMALL, 54, 760)

def _measure(st):
    def m(it, idx):
        if it["kind"] == "cap": return 0
        f, lh, mw = _cfg(idx); return 70 + len(wrap(it["shot"]["line"], f, mw))*lh + 40
    return m

def _layer(st, it, h, idx):
    s = it["shot"]; c = st["chars"][s["name"]]; f, lh, mw = _cfg(idx); new = idx == 0
    L = Image.new("RGBA", (W, h)); d = ImageDraw.Draw(L); r = 50 if new else 32
    lines = wrap(s["line"], f, mw); bw = max(tw("".join(t for t, _ in ln), f) for ln in lines) + 60
    d.ellipse([30, 0, 30+2*r, 2*r], fill=c["color"]); d.text((30+r, r), c["avatar"], font=F(46 if new else 30), fill="white", anchor="mm")
    x0 = 50 + 2*r
    d.text((x0, 30 if new else 18), s["name"], font=F(40 if new else 28), fill=c["color"], anchor="lm")
    bg = tuple(int(v*0.35 + 40) for v in c["color"]) if new else (34, 36, 44)
    d.rounded_rectangle([x0, 64, x0+bw, 64+len(lines)*lh+30], 30, fill=bg, outline=c["color"] if new else None, width=4)
    draw_rich(d, x0+30, 76, lines, f, lh, (255,255,255) if new else (150,150,160), (0, 255, 200) if new else (60, 170, 140))
    if not new: L.putalpha(L.getchannel("A").point(lambda v: int(v*0.75)))
    return L

def _keycard(im, text, dt):
    if not (0 <= dt < 3.5): return
    f = F(130); w = tw(text, f) + 140; h = 260
    L = Image.new("RGBA", (W, h + 40)); d = ImageDraw.Draw(L)
    for g in range(6): d.rounded_rectangle([(W-w)//2-g*6, 20-g*6+g*6, (W+w)//2+g*6, 20+h], 60, outline=(0, 229, 255, 50-g*8), width=6)
    d.rounded_rectangle([(W-w)//2, 20, (W+w)//2, 20+h], 60, fill=(10, 14, 30, 240), outline=(0, 229, 255), width=8)
    d.text((W//2, 20+h//2), text, font=f, fill=(0, 255, 200), anchor="mm")
    sc = 0.3 + dt/0.2*0.9 if dt < 0.2 else (1.2 - (dt-0.2)/0.15*0.2 if dt < 0.35 else 1.0)
    l = L.resize((max(1, int(L.width*sc)), max(1, int(L.height*sc))))
    if dt > 3.2: l.putalpha(l.getchannel("A").point(lambda v: int(v*(3.5-dt)/0.3)))
    im.alpha_composite(l, ((W - l.width)//2, 760 - l.height//2))

def draw_frame(state):
    im = Image.new("RGBA", (W, H), (12, 12, 18)); d = ImageDraw.Draw(im)
    items = [i for i in visible(state) if i["kind"] == "msg"]
    for n, (it, y, h, k) in enumerate(layout_stack(items, state["t"], _measure(state), BOTTOM, TOP, 30)):
        pop(im, _layer(state, it, h, n), (0, y), k)
    d.rectangle([0, 0, W, 190], fill=(12, 12, 18)); d.text((W//2, 80), state["title"].split("：")[0], font=F(40), fill=(0, 229, 255), anchor="mm")
    d.text((W//2, 140), "● 群聊直播中", font=F(30, False), fill=(255, 80, 120), anchor="mm"); d.line([(80, 188), (W-80, 188)], fill=(0, 229, 255), width=3)
    for it in visible(state):
        if it["kind"] == "cap": _keycard(im, it["text"], state["t"] - it["t0"])
    return im.convert("RGB")
