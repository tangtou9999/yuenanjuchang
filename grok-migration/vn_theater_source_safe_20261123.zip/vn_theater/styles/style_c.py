"""风格C：清新笔记本/课本风"""
from .common import draw_frame as _df
THEME = dict(name="c", wall=[(250,250,245),(232,240,236)], window=(205,235,225), frame=(120,170,150),
  board_frame=(90,150,130), board=(255,255,255), board_head=(90,150,130), board_text=(40,60,55),
  table=[(220,200,170),(240,228,205),(225,210,185)], seat_label=(70,90,85), card_fill=(255,255,255), card_radius=60, card_text=(40,60,55),
  title_bg=(90,150,130,245), accent=(255,170,60), title_text=(255,255,255), sub_bg=(255,255,255,225), sub_text=(40,50,50),
  sub_stroke=(255,255,255), vn=(230,90,40), cap_bg=(255,170,60), cap_text=(255,255,255), cap_stroke=(160,80,0), zoom=0.08)
def draw_frame(state): return _df(state, THEME)
