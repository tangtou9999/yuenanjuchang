# 《越南语趣味大剧场》15人群聊渲染程序 · 交接说明

版本：2026-11-23（北京时间晚）从渲染机 `/workspace/vn_theater` 直接打包的**当前正式程序**。
R03、R04、R05、EP06、EP07、EP04 正式版都是用这一套代码渲染的（风格 `chat_final`，即微信群聊页面）。
已去掉：`*.bak_*` 历史备份、`__pycache__`、`.venv`、旧 EP01 测试素材、头像备份目录。
不含任何密码、API Key、Token。

## 1. 环境
- Python 3.13（3.11+ 应该也行，未验证）
- ffmpeg 7.x（需要 libx264 + aac）
- `pip install -r requirements.txt`（`requirements_frozen.txt` 是渲染机完整依赖快照，已删掉 torch/nvidia，正式渲染不需要显卡）
- 字体（路径写死在代码里，GitHub Actions 上需要放到同样位置，或改代码里的常量）：
  - `/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc`、`NotoSansCJK-Regular.ttc` → Ubuntu `apt install fonts-noto-cjk`
  - `/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf` → `apt install fonts-noto-color-emoji`
  - `/usr/share/fonts/truetype/sand-box/google/Ma Shan Zheng/MaShanZheng-Regular.ttf`
  - `/usr/share/fonts/truetype/sand-box/google/Patrick Hand/PatrickHand-Regular.ttf`
  - `/usr/share/fonts/truetype/sand-box/google/Dela Gothic One/DelaGothicOne-Regular.ttf`（只有封面用）
  - 后三个已放在本包 `fonts/` 目录（Google Fonts，OFL 许可）。
- Whisper 模型：`faster-whisper small`，首次运行自动从 HuggingFace 下载（约 500MB），CPU int8。可用环境变量 `WHISPER_MODEL` 改。

## 2. 正式渲染命令（每集一条）
```bash
cd vn_theater
python run_episode.py incoming/R03_render.json incoming/R03_audio.mp3 \
    --style chat_final --no-cover-hold --no-endcard --no-cover \
    --outdir /path/to/episodes/R03
```
- 输出：`<outdir>/R03.mp4`，以及导入后的脚本、`*.align.json`（逐字时间）、`*.effects.json`、`*.mix.json`、`*_import_report.txt`。
- 规则：**不加片尾单词页/封面**（封面由 ChatGPT 另做）。`--outdir` 已存在且非空会自动改名，不会覆盖旧成片。
- 样片：加 `--dur 15`；单帧预览：`--still 12.5`。
- 示例输入：`examples/R03/`（真实 MP3+JSON），其他集 JSON 在 `examples/`。

## 3. 输出编码（iPhone 可保存，已验证）
竖屏 1080x1920、30fps：
`-c:v libx264 -preset medium -crf 20 -profile:v main -level:v 4.0 -pix_fmt yuv420p -tag:v avc1 -c:a aac -ar 48000 -ac 2 -b:a 192k -map_metadata -1 -map_chapters -1 -fflags +bitexact -shortest -movflags +faststart`
（在 `render.py` 里；混音也是 48kHz。不要改回 High profile，否则 iPhone「无法保存到照片」。）

## 4. Gemini MP3 + JSON 接口（`import_voiceapp.py` 解析）
每集两个文件，放同一目录，同名前缀：`<集号>_audio.mp3` + `<集号>_render.json`。
JSON 顶层字段：
- `cast_schema_version`、`episode_code`（如 R03）、`project_title`（标题）、`global_scene`
- `timing_source`、`total_audio_duration_ms` / `total_audio_duration_sec`、`duration_policy`
- `vocab_summary`：本集单词表（`vi`、`zh`，可选 `homophone`）
- `sfx_spotting_list_seconds`：音效清单（秒 + 描述，自动匹配到台词）
- `millisecond_timeline`：数组，每句一项：
  `shot_index, start_ms, end_ms, character_id("05"), character_name("苏姐"), speaker, gender, voice_id, expression_id, expression_label, emotion_tone, vietnamese_terms[{vi, zh, homophone, hook}], dialogue_text, camera_instruction, character_action, visual_render_prompt`
- 字幕时间以 MP3 为准：程序用 faster-whisper 把台词逐字对齐到音频，对不上的句子按字数平均分配。
- **谐音只取 JSON 里的 `homophone` / `谐音` 字段**，没有就不显示，程序不猜。
- 说话人必须按 `roster15.json` 的 id+姓名（或别名）匹配；编号和姓名冲突、或不在名单里会**中止**，不会乱猜。

## 5. 15 人素材配置
- `roster15.json`：01唐哥 02大鹏 03老刘 04坦克 05苏姐 06小宇 07阿强 08安娜 09小雨 10阿丽 11欣欣 12佳佳 13肖雨晴（画面显示 `display_name`「肖老师」）14依琳 15小美；含颜色、别名、头像目录。
- `assets/avatars/<姓名>/`：每人按表情编号的头像图（JSON 的 `expression_id` 对应）。
- `assets/banner/` 顶部横幅；`assets/bgm/`（`bgm.json` 选曲和音量）；`assets/sfx/`（`sfx.json`）；许可证见各目录 `LICENSES.md`。
- `characters.json` 是旧 EP01–EP04 的配置，保留兼容。

## 6. 代码文件
- `run_episode.py` 总入口：导入 → 对齐 → 渲染。
- `import_voiceapp.py` 把 Gemini JSON 转成内部脚本。
- `align.py` faster-whisper 逐字对齐。
- `render.py` 混音（人声 + BGM + 音效）+ 逐帧画面通过管道送 ffmpeg 编码。
- `styles/chat_final.py` 正式风格（群聊页面、左上角「每天一分钟学习越南语」、今日单词黑板等）；`styles/chat_common.py` 公共函数（含消息上弹的亚像素平滑滚动）。
- `make_effects.py` 音效/画面特效表；`glossary.py` 越南语词义库。
- `make_cover.py`、`stage_recap.py`：封面/片尾页，现在已停用（保留备查）。
- `styles/` 里 `style_a/b/c`、`chat_a/b/c`、`radio_podcast.py` 是旧/备选风格，正式流程不用。

## 7. 性能（参考）
渲染机纯 CPU：1 分钟成片约 3–5 分钟（含 whisper 对齐）。GitHub Actions 免费机器上的时间未验证。

## 8. 已知注意点
- 代码里有几处 `/workspace/...` 绝对路径（仅用于旧测试目录和默认 incoming 目录），迁移时用参数传路径即可，必要时改成相对路径。
- EP07 字幕时间可能略松；R04 对齐尾部约 5.4 秒被裁掉过（音频尾部静音）。
