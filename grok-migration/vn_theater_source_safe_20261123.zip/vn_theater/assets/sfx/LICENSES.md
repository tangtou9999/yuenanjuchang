# SFX licenses

All files in this folder are CC0 or public domain and may be used commercially. No login or payment was required to obtain them. Original filenames and sources are recorded below.

| File | Use (effect type) | Source work | Author | License | Source URL |
|---|---|---|---|---|---|
| `crow.wav` | crow (awkward beat) | *Corvus brachyrhynchos call.ogg* (trimmed to the last ~2.3 s of calls, high-passed and normalized) | United States Geological Survey; transcoded by Wikimedia user Superm401 | Public domain (US federal work, PD-USGS) | https://commons.wikimedia.org/wiki/File:Corvus_brachyrhynchos_call.ogg |
| `thud.wav` | shake (table slap) | Kenney *Impact Sounds* 1.0 — `impactWood_heavy_000.ogg` (normalized) | Kenney (www.kenney.nl) | CC0 1.0 | https://kenney.nl/assets/impact-sounds |
| `impact.wav` | impact (bang / 撞击) | Kenney *Impact Sounds* 1.0 — `impactPunch_heavy_000.ogg` (pre-delay trimmed, normalized) | Kenney (www.kenney.nl) | CC0 1.0 | https://kenney.nl/assets/impact-sounds |
| `ding.wav` | sparkle / ding (叮咚) | Kenney *Interface Sounds* 1.0 — `confirmation_004.ogg` (normalized) | Kenney (www.kenney.nl) | CC0 1.0 | https://kenney.nl/assets/interface-sounds |
| `pop.wav` | laugh (short comedy pop, no laugh track) | Kenney *Interface Sounds* 1.0 — `bong_001.ogg` (normalized) | Kenney (www.kenney.nl) | CC0 1.0 | https://kenney.nl/assets/interface-sounds |
| `whoosh.wav` | whoosh (嗖 / 飘过) | Original synthesized pink-noise frequency sweep (numpy), created for this project | vn_theater | CC0 1.0 | (generated in-repo) |
| `chalk.wav` | chalk (soft tick when a word lands on the board) | Original synthesized chalk-scratch tick (numpy), created for this project | vn_theater | CC0 1.0 | (generated in-repo) |

Kenney packs: “This content is free to use in personal, educational and commercial projects.” Credit is not mandatory. CC0 text: https://creativecommons.org/publicdomain/zero/1.0/

The Kenney *Interface Sounds* zip was downloaded from the OpenGameArt mirror (no account): https://opengameart.org/content/interface-sounds — file `kenney_interfaceSounds.zip`, identical CC0 pack. Individual *Impact Sounds* files were downloaded from the public CC0 mirror https://cc0-sounds.exi.software/collection/kenney_impactsounds/ after Kenney.nl’s signed download endpoint returned 403 without a browser session. Source of truth for the license remains kenney.nl.
