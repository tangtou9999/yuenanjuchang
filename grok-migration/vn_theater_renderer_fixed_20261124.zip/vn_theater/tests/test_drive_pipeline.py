import unittest
from tools.drive_pipeline import select_pair

class PairTests(unittest.TestCase):
    def test_picks_only_complete_latest_version(self):
        files=[{'name':'Z002_v1_配音.mp3','id':'old_a'}, {'name':'Z002_v1_渲染数据包.json','id':'old_j'}, {'name':'Z002_v2_配音.mp3','id':'no_json'}, {'name':'Z001_v2_渲染数据包.json','id':'other'}]
        a,j,v=select_pair(files,'Z002')
        self.assertEqual((a['id'],j['id'],v),('old_a','old_j','v1'))
    def test_requires_complete_pair(self):
        with self.assertRaises(FileNotFoundError):
            select_pair([{'name':'Z002_v1_配音.mp3','id':'a'}],'Z002')
    def test_does_not_mix_episode_prefix(self):
        with self.assertRaises(FileNotFoundError):
            select_pair([{'name':'Z0022_v1_配音.mp3','id':'a'},{'name':'Z0022_v1_渲染数据包.json','id':'j'}],'Z002')
if __name__=='__main__':unittest.main()
