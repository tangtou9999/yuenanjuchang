#!/usr/bin/env python3
"""音频 ↔ 脚本 逐字对齐。用法: .venv/bin/python align.py script.txt audio.mp3 [out.json]

字幕永远使用脚本原文；本程序只从音频里给每个字打时间。
输出 {"lines":[{"n":镜头号,"chars":[[字,开始秒,结束秒],...],"method":"whisper|charcount","match":匹配率}], "rms":[每帧响度...]}
"""
import sys, json, os, subprocess, unicodedata, difflib
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render import parse

# 窗长：先用近窗，整句对不上再放宽（台词里常有重复短语，不宜一开始就全局对齐）
PAD_NEAR, PAD_FAR = 1.0, 2.5


def fold(c):
    """匹配用：小写并去掉越南语声调。不改脚本原文。"""
    c = unicodedata.normalize("NFD", c).lower()
    return "".join(ch for ch in c if unicodedata.category(ch) != "Mn")


def is_key(c):
    return any(ch.isalnum() for ch in fold(c))


def rms_env(audio, fps=30):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", audio, "-ac", "1", "-ar", "16000", "-f", "s16le", "-"])
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    hop = 16000 // fps
    r = np.sqrt(np.convolve(x ** 2, np.ones(hop) / hop, "same")[::hop])
    return (r / (np.percentile(r, 99) + 1e-6)).clip(0, 1).round(3).tolist()


def load_pcm(audio, sr=16000):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", audio, "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"])
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768


def transcribe(pcm):
    from faster_whisper import WhisperModel
    m = WhisperModel(os.environ.get("WHISPER_MODEL", "small"), device="cpu", compute_type="int8")
    # 不要把台词当作 initial_prompt：当前 faster-whisper 会几乎只吐出提示词，整集对不齐。
    segs, _ = m.transcribe(
        pcm, language="zh", word_timestamps=True, vad_filter=False,
        condition_on_previous_text=False,
    )
    words = []
    for sg in segs:
        for w in sg.words or []:
            cs = [fold(c) for c in w.word if is_key(c)]
            if not cs:
                continue
            dur = max(w.end - w.start, 1e-3)
            for i, c in enumerate(cs):
                a = w.start + dur * i / len(cs)
                words.append((c, a, a + dur / len(cs)))
    return words


def median_char_dur(words, default=0.12):
    d = [w[2] - w[1] for w in words if w[2] > w[1]]
    if not d:
        return default
    d.sort()
    return float(d[len(d) // 2])


def match_window(key, words, t0, t1, pad):
    """在时间窗里用 SequenceMatcher 把脚本字对到识别字。返回 {脚本下标: 开始秒} 和命中数。"""
    idx = [k for k, w in enumerate(words) if t0 - pad <= w[1] <= t1 + pad]
    if not idx or not key:
        return {}, 0, idx
    ref = "".join(c for _, c in key)
    sub = "".join(words[k][0] for k in idx)
    sm = difflib.SequenceMatcher(None, ref, sub, autojunk=False)
    times, hit = {}, 0
    for blk in sm.get_matching_blocks():
        for j in range(blk.size):
            times[key[blk.a + j][0]] = words[idx[blk.b + j]][1]
            hit += 1
    return times, hit, idx


def interpolate(n, times, t0, t1, char_dur, win_words):
    """未匹配的字（标点、越南语被听成近音汉字等）按相邻锚点插值。
    句首句尾跟着实际语音走，不把整句强行拉到脚本标的 t0/t1。"""
    hits = sorted((i, t) for i, t in times.items())
    if not hits or n <= 0:
        return None
    first_i, first_t = hits[0]
    last_i, last_t = hits[-1]
    # 句首：用该镜头里、第一个匹配字之前的识别起点，避免“哎阿呆”被听成“嗨嗨”时karaoke来晚
    lead = [w[1] for w in win_words if w[1] <= first_t and w[1] >= t0 - 0.3]
    if lead:
        start = min(first_t, max(t0 - 0.15, min(lead)))
    else:
        start = min(first_t, max(t0 - 0.15, first_t - first_i * char_dur))
    # 句尾：用最后一个匹配字之后、仍落在镜头附近的识别终点
    tail = [w[2] for w in win_words if w[2] >= last_t and w[1] <= t1 + 0.3]
    if tail:
        end = max(last_t + char_dur * 0.5, min(t1 + 0.15, max(tail)))
    else:
        end = max(last_t + char_dur * 0.5, min(t1 + 0.15, last_t + (n - last_i) * char_dur))

    anchors = []
    if first_i > 0:
        anchors.append((0, start))
    anchors.extend(hits)
    if anchors[-1][0] < n:
        anchors.append((n, end))

    clean = [anchors[0]]
    for a in anchors[1:]:
        if a[0] > clean[-1][0] and a[1] >= clean[-1][1]:
            clean.append(a)
    # 去掉过密的异常锚点（识别抖了一下）
    ok = True
    while ok and len(clean) > 2:
        ok = False
        for j in range(1, len(clean) - 1):
            (i0, a0), (i1, a1) = clean[j - 1], clean[j]
            if i1 > i0 and (a1 - a0) / (i1 - i0) < 0.04:
                clean.pop(j)
                ok = True
                break
    if clean[-1][0] != n:
        clean.append((n, max(end, clean[-1][1] + char_dur)))

    ts = []
    for i in range(n):
        for (i0, a0), (i1, a1) in zip(clean, clean[1:]):
            if i0 <= i < i1:
                ts.append(a0 + (a1 - a0) * (i - i0) / max(i1 - i0, 1))
                break
        else:
            ts.append(clean[-1][1])
    ts.append(clean[-1][1])
    for i in range(1, len(ts)):
        if ts[i] < ts[i - 1]:
            ts[i] = ts[i - 1]
    return ts


def align_shot(s, words, char_dur):
    chars = list(s["line"])
    key = [(i, fold(c)) for i, c in enumerate(chars) if is_key(c)]
    t0, t1 = s["t0"], s["t1"]
    times, hit, idx = {}, 0, []
    pad_used = PAD_NEAR
    for pad in (PAD_NEAR, PAD_FAR):
        times, hit, idx = match_window(key, words, t0, t1, pad)
        pad_used = pad
        if hit:
            break
    rate = hit / max(len(key), 1)
    if not hit:
        L = max(len(chars), 1)
        ts = [t0 + (t1 - t0) * i / L for i in range(L + 1)]
        ts[-1] = t1
        return ts, 0.0, "charcount"
    win_words = [words[k] for k in idx] if idx else []
    ts = interpolate(len(chars), times, t0, t1, char_dur, win_words)
    if not ts:
        L = max(len(chars), 1)
        ts = [t0 + (t1 - t0) * i / L for i in range(L + 1)]
        ts[-1] = t1
        return ts, rate, "charcount"
    return ts, rate, "whisper"


def main(script, audio, out):
    title, shots = parse(script)
    words = []
    try:
        pcm = load_pcm(audio)
        words = transcribe(pcm)
        print("whisper 字数:", len(words))
    except Exception as e:
        print("whisper 失败，回退字数计时:", e)
    char_dur = median_char_dur(words)
    res = []
    for s in shots:
        ts, rate, method = align_shot(s, words, char_dur)
        chars = list(s["line"])
        res.append(dict(
            n=s["n"], method=method, match=round(rate, 3),
            chars=[[c, round(ts[i], 3), round(ts[i + 1], 3)] for i, c in enumerate(chars)],
        ))
        print(f"#{s['n']:>2} 匹配率 {rate:.0%} {method}")
    json.dump(dict(lines=res, rms=rms_env(audio)), open(out, "w", encoding="utf-8"), ensure_ascii=False)
    print("写入", out)


if __name__ == "__main__":
    a = sys.argv[1:]
    main(a[0], a[1], a[2] if len(a) > 2 else os.path.splitext(a[0])[0] + ".align.json")
