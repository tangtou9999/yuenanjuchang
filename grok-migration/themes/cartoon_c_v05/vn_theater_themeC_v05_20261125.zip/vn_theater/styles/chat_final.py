"""最终风格：仿群聊界面（#EDEDED 底、白气泡左尾巴、方圆角头像、灰色小名字、居中时间）+ 越南语黄色荧光+中文小注
+ 逐字卡拉OK（音频对齐）+ 正在输入… + 头像随音量跳动 + 音效画面反应（震屏/哈哈哈/乌鸦/叮咚）+ 片尾单词卡。
不使用任何真实 App 标志、名字或头像。"""
import math, random, os, re, hashlib
from PIL import Image, ImageDraw, ImageFont
from .common import F, VN_RE, W, H
from .chat_common import gloss, ease, tw, layout_stack, pop

DEFAULT_SELF_NAME = "唐哥"      # 新版 15 人群聊默认从唐哥视角显示右侧绿色气泡
BG, GREEN = (237, 237, 237), (149, 236, 105)
BANNER_H, HEADER_H = 280, 132
TOP = BANNER_H + HEADER_H
INPUT_BAR_TOP = 1810                     # 输入栏下移，聊天主体尽量铺满竖屏
BOTTOM = INPUT_BAR_TOP - 16             # 对话区保持紧贴输入栏而不重叠
ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
BANNER_DEFAULT = os.path.join(ASSETS, "banner", "stage_right_redesign_v1.png")
GROUP_NAME = "越南语学习交流群"
BRAND_IMAGE = os.path.join(ASSETS, "banner", "stage_right_redesign_v1.png")
# 方案C（手绘卡通）：独立背景素材 + 程序化字幕与动态黑板。
CARTOON_C_BG = os.path.join(ASSETS, "banner", "cartoon_c_fixed_1080x1920.png")
CARTOON_C_BOARD_TOP = 350
CARTOON_C_CHAT_TOP = 610

def _cartoon_c_enabled(state):
    # 方案C为本独立v05演示版默认主题；旧版可通过 mix.ui_theme=classic 显式回退。
    mix = state.get("mix") or {}
    return str(mix.get("ui_theme", "cartoon_c")).lower() != "classic"

def _cartoon_c_background():
    if not os.path.isfile(CARTOON_C_BG):
        raise FileNotFoundError(f"方案C背景缺失: {CARTOON_C_BG}")
    cached = _cache.get("cartoon_c_background")
    if cached is None:
        cached = Image.open(CARTOON_C_BG).convert("RGBA")
        if cached.size != (W, H):
            raise ValueError(f"方案C背景必须为1080x1920，实际{cached.size}")
        _cache["cartoon_c_background"] = cached
    return cached.copy()

SAFE_TOP = 120                   # 抖音顶部遮挡大约这么高，关键文字放在此线之下
# 黑板单词栏（微信顶栏之下、聊天区之上）
WOOD, BOARD_INSET, BOARD_PAD_Y = 8, 16, 4
CHIP_GAP_X, CHIP_GAP_Y, BOARD_ROWS = 12, 6, 2
BOARD_H = 174 + 26  # 一行大卡约占内高 75%；两行时再缩小。比 v4 增高 26px（上限 +30）
CHIP_H = 74  # 仅作默认/回退；实际高度由 layout_chips 按行数计算
CHAT_TOP = TOP + BOARD_H
CARD_HOLD, CARD_FLY, CARD_POP = 0.60, 1.15, 0.22
_FONT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts")
_CHALK_ZH = os.path.join(_FONT_DIR, "MaShanZheng-Regular.ttf")
_CHALK_VI = os.path.join(_FONT_DIR, "PatrickHand-Regular.ttf")
def Fchalk(sz, vi=False):
    custom = _CHALK_VI if vi else _CHALK_ZH
    # GitHub Actions 可不安装额外 Google Fonts：优先使用合法提供的字库，缺失时回退 Noto CJK。
    fallback = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
    return ImageFont.truetype(custom if os.path.isfile(custom) else fallback, int(sz))
def ease_inout(x):
    x = min(max(x, 0.0), 1.0)
    return 0.5 - 0.5 * math.cos(math.pi * x)
FN, FNAME, FG = F(54, False), F(34, False), F(32)
LH, GH, MAXW, AV = 76, 39, 700, 112
SPOKEN, UNSPOKEN = (20, 20, 20), (165, 165, 165)
EMOJI = "/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf"
def self_name(state):
    """新版默认唐哥为自己；旧12人没有唐哥时仍可沿用阿呆。

    可在输入 JSON 的 self_character / self_name 字段指定自己的角色，
    导入器透传到 mix 后由 render.resolve_episode 读取；不凭某句台词猜测。
    """
    ep = state.get("episode") or {}
    configured = ep.get("self_name") or state.get("self_name")
    chars = state.get("chars") or {}
    if configured:
        if configured not in chars:
            raise ValueError(f"自己角色 {configured!r} 不在本集出场名单中")
        return configured
    if DEFAULT_SELF_NAME in chars:
        return DEFAULT_SELF_NAME
    if "阿呆" in chars:
        return "阿呆"
    return None  # 某集唐哥未出场时，全部群友按左侧显示，不造虚构的自己消息


def chat_clock(state, t=0):
    """优先使用本集自定义 HH:MM，其次根据剧集编号生成稳定、不重复的模拟时间。

    输出时间随剧情时间推进到下一分钟；同一集重复渲染结果相同。
    """
    ep = state.get("episode") or {}
    raw = str(ep.get("chat_start_time") or "").strip()
    match = re.fullmatch(r"([01]\d|2[0-3]):([0-5]\d)", raw)
    if raw and not match:
        raise ValueError(f"聊天起始时间不合法: {raw!r}，须为 HH:MM")
    if match:
        start_minutes = int(match.group(1)) * 60 + int(match.group(2))
    else:
        code = str(ep.get("episode_code") or state.get("title") or "default")
        salt = hashlib.sha256(code.encode("utf-8")).digest()
        # 仅为短剧虚构聊天时间，不代表现实生成时刻
        start_minutes = 18 * 60 + int.from_bytes(salt[:4], "big") % (3 * 60)
    minute = (start_minutes + max(0, int(float(t))) // 60) % (24 * 60)
    return f"{minute // 60:02d}:{minute % 60:02d}"

# ---------- 文本排版（带字符下标，供卡拉OK用） ----------
def toks(text):
    out, pos = [], 0
    for m in VN_RE.finditer(text):
        out += [(c, False, pos + i) for i, c in enumerate(text[pos:m.start()])]; out.append((m.group(0), True, m.start())); pos = m.end()
    return out + [(c, False, pos + i) for i, c in enumerate(text[pos:])]

def wrap(text):
    lines, cur, cw = [], [], 0
    for t in toks(text):
        # 越南语高亮左右各约 6px，按略宽估一下，避免把后面的「！」挤到下一行
        w = tw(t[0], FN) + (12 if t[1] else 0)
        if cur and cw + w > MAXW:
            if t[0] in "，。！？；、…—）」!?,.":
                cur.append(t)
                lines.append(cur)
                cur, cw = [], 0
                continue
            lines.append(cur)
            cur, cw = [], 0
        if not cur and t[0] == " ":
            continue
        cur.append(t)
        cw += w
    if cur:
        lines.append(cur)
    # 不要让「！」等标点单独成行
    merged = []
    for ln in lines:
        if merged and ln and all((tk[0] in "，。！？；、…—）」!?,. " or not str(tk[0]).strip()) for tk in ln):
            merged[-1].extend(ln)
        else:
            merged.append(ln)
    return merged

def _shot_homophones(state):
    """Only audited source JSON homophones; Chinese translations are never pronunciation aids."""
    return {
        re.sub(r"[!?.,，。！？]+$", "", (w.get("word") or "").strip().lower()): (w.get("homophone") or "").strip()
        for w in (state.get("words") or []) if (w.get("homophone") or "").strip()
    }

def _homophone(tk, homos):
    return (homos or {}).get(re.sub(r"[!?.,，。！？]+$", "", tk.strip().lower()), "")

def text_h(lines, homos=None):
    return sum(LH + (GH if any(v and _homophone(t, homos) for t, v, _ in ln) else 0) for ln in lines)
def text_w(lines): return max(sum(tw(t, FN) for t, _, _ in ln) for ln in lines)

def char_times(state, s):
    al = state.get("align")
    if al:
        for l in al["lines"]:
            if l["n"] == s["n"] and len(l["chars"]) == len(s["line"]): return [c[1] for c in l["chars"]]
    L = max(len(s["line"]), 1); return [s["t0"] + (s["t1"] - s["t0"]) * i / L for i in range(L)]

def draw_text(L, x, y, lines, times=None, t=None, ink=SPOKEN, dim=UNSPOKEN, homos=None):
    d = ImageDraw.Draw(L)
    for ln in lines:
        cx = x; g = any(v and _homophone(tk, homos) for tk, v, _ in ln)
        for tk, v, i in ln:
            w = tw(tk, FN); on = times is None or t >= times[i]
            col = ink if on else dim
            if v:
                dt = (t - times[i]) if times is not None else 9
                sc = 1 + 0.35 * math.sin(min(max(dt / 0.35, 0), 1) * math.pi) if times is not None else 1
                hl = (255, 226, 60) if on else (255, 242, 180)
                if sc > 1.01:  # 弹跳：单独画成小图放大
                    wi = Image.new("RGBA", (w + 16, LH + 10)); wd = ImageDraw.Draw(wi)
                    wd.rounded_rectangle([0, 10, w + 16, LH + 4], 10, fill=hl); wd.text((8, 0), tk, font=FN, fill=(200, 40, 20))
                    wi = wi.resize((int(wi.width * sc), int(wi.height * sc)))
                    L.alpha_composite(wi, (int(cx - 8 - (wi.width - w - 16) / 2), int(y - (wi.height - LH - 10) / 2)))
                else:
                    d.rounded_rectangle([cx - 6, y + 10, cx + w + 6, y + LH - 2], 10, fill=hl)
                    d.text((cx, y), tk, font=FN, fill=(200, 40, 20) if on else (190, 120, 100))
                if _homophone(tk, homos): d.text((cx + w / 2, y + LH - 2), _homophone(tk, homos), font=FG, fill=(185, 95, 33), anchor="mt")
            else:
                d.text((cx, y), tk, font=FN, fill=col)
            cx += w
        y += LH + (GH if g else 0)

# ---------- 头像：有照片则圆形裁切+角色色描边，否则退回色块 ----------
AVATAR_DIR = os.path.join(ASSETS, "avatars")
_AVATAR_CAT = {}
_AVATAR_IMG = {}
_EMOTION_RULES = [
    (r"哈哈+|大笑|笑死|救命啊", "大笑"),
    (r"坏笑|嘿嘿|阴险", "坏笑"),
    (r"震惊|不敢相信|啊？？|？？|什么我", "震惊"),
    (r"生气|哼！|恼", "生气"),
    (r"害羞|不好意思|脸红", "害羞"),
    (r"无语|无言", "无语"),
    (r"委屈|呜呜", "委屈"),
    (r"懵了|一头雾水", "懵"),
]


def _avatar_catalog(name):
    if name not in _AVATAR_CAT:
        folder = os.path.join(AVATAR_DIR, name)
        cat = {}
        if os.path.isdir(folder):
            for fn in sorted(os.listdir(folder)):
                m = re.match(r"^(\d+)_(.+)\.(png|jpg|jpeg|webp)$", fn, re.I)
                if not m:
                    continue
                idx, emo = int(m.group(1)), m.group(2)
                path = os.path.join(folder, fn)
                cat[emo] = path
                cat[idx] = path
                cat[str(idx)] = path
        _AVATAR_CAT[name] = cat
    return _AVATAR_CAT[name]


def pick_emotion(shot, char=None):
    """镜头可带 emotion；否则按台词关键词猜；默认普通微笑。"""
    for src in ((shot or {}).get("emotion"), (char or {}).get("emotion")):
        if src:
            return str(src).strip()
    line = (shot or {}).get("line") or ""
    for pat, emo in _EMOTION_RULES:
        if re.search(pat, line):
            return emo
    return "普通微笑"


def _resolve_avatar_path(char, emotion=None):
    name = (char or {}).get("name") or (char or {}).get("avatar_name") or ""
    folder = (char or {}).get("avatar_dir")
    cat = {}
    if folder and os.path.isdir(folder):
        # 允许角色表指定文件夹
        key = folder
        if key not in _AVATAR_CAT:
            fake = os.path.basename(folder.rstrip(os.sep))
            _AVATAR_CAT[fake] = _avatar_catalog(fake) if os.path.basename(os.path.dirname(folder.rstrip(os.sep))) == "avatars" else {}
            # scan this folder directly
            cat = {}
            for fn in sorted(os.listdir(folder)):
                m = re.match(r"^(\d+)_(.+)\.(png|jpg|jpeg|webp)$", fn, re.I)
                if not m:
                    continue
                idx, emo = int(m.group(1)), m.group(2)
                path = os.path.join(folder, fn)
                cat[emo] = path
                cat[idx] = path
                cat[str(idx)] = path
            _AVATAR_CAT[key] = cat
        cat = _AVATAR_CAT[key]
    elif name:
        cat = _avatar_catalog(name)
    if not cat:
        return None
    if emotion and emotion in cat:
        return cat[emotion]
    # 数字或近义
    aliases = {
        "微笑": "普通微笑", "普通微笑": "普通微笑",
        "笑": "大笑", "大笑": "大笑", "坏笑": "坏笑",
        "疑惑": "懵", "懵": "懵",
        "震惊": "震惊", "惊讶": "震惊", "吃惊": "震惊",
        "生气": "生气",
        "尴尬": "害羞", "害羞": "害羞",
        "翻白眼": "无语", "无语": "无语",
        "委屈": "委屈",
    }
    raw = (emotion or "").strip()
    # 允许 "05震惊" / "05:震惊" / "5"
    m = re.match(r"^0?([1-9])[:：]?([一-鿿]*)$", raw)
    if m:
        idx = int(m.group(1))
        lab = m.group(2)
        if lab:
            raw = lab
        elif idx in cat:
            return cat[idx]
    emo = aliases.get(raw, raw)
    if emo and emo in cat:
        return cat[emo]
    if m and int(m.group(1)) in cat:
        return cat[int(m.group(1))]
    return cat.get("普通微笑") or cat.get(1) or next((v for k, v in cat.items() if isinstance(k, str) and not k.isdigit()), None)


def _circle_mask(sz):
    m = Image.new("L", (sz * 4, sz * 4), 0)
    ImageDraw.Draw(m).ellipse([0, 0, sz * 4 - 1, sz * 4 - 1], fill=255)
    return m.resize((sz, sz), Image.Resampling.LANCZOS)


def _prepare_face(path, size, zoom=1.0, head_shift=0.0):
    """把方图放进圆形头像。zoom=1.0 用整张 512 图（不再 1.1 倍裁掉头顶的发髻/墨镜/马尾）；
    head_shift>0 时裁切窗口略向上移，多留头发、少留肩膀。"""
    key = (path, size, zoom, head_shift)
    if key not in _AVATAR_IMG:
        im = Image.open(path).convert("RGB")
        w, h = im.size
        side = min(w, h) / max(zoom, 1.0)
        l = (w - side) / 2
        t = (h - side) / 2 - head_shift * side
        # 向上移位时不要裁出上沿；多出来的从下沿扣
        if t < 0:
            t = 0
        if t + side > h:
            t = max(0, h - side)
        if l < 0:
            l = 0
        if l + side > w:
            l = max(0, w - side)
        im = im.crop((int(l), int(t), int(round(l + side)), int(round(t + side))))
        _AVATAR_IMG[key] = im.resize((size, size), Image.Resampling.LANCZOS)
    return _AVATAR_IMG[key]


def avatar(c, size=AV, pulse=0.0, emotion=None, name=None):
    """有 assets/avatars/<角色名>/<序号>_<情绪>.png 则圆形头像+色圈，否则方圆角色色块。"""
    if name and "name" not in (c or {}):
        c = dict(c or {}, name=name)
    pad = 24
    im = Image.new("RGBA", (size + 2 * pad, size + 2 * pad))
    d = ImageDraw.Draw(im)
    s2 = int(size * (1 + 0.30 * max(0.0, min(1.0, pulse))))
    o = pad + (size - s2) // 2
    path = _resolve_avatar_path(c, emotion)
    if pulse > 0.02:
        g = int(pad * min(pulse * 1.6, 1))
        if path:
            d.ellipse([pad - g, pad - g, pad + size + g, pad + size + g], fill=c["color"] + (90,))
        else:
            d.rounded_rectangle([pad - g, pad - g, pad + size + g, pad + size + g], 22 + g, fill=c["color"] + (90,))
    if path:
        bw = max(4, int(s2 * 0.07))
        inner = max(8, s2 - 2 * bw)
        d.ellipse([o, o, o + s2 - 1, o + s2 - 1], fill=c["color"] + (255,))
        face = _prepare_face(path, inner)
        masked = Image.new("RGBA", (inner, inner), (0, 0, 0, 0))
        masked.paste(face, (0, 0))
        masked.putalpha(_circle_mask(inner))
        im.alpha_composite(masked, (o + bw, o + bw))
        return im
    d.rounded_rectangle([o, o, o + s2, o + s2], 16, fill=c["color"])
    d.text((o + s2 / 2, o + s2 * .5), c["avatar"], font=F(int(s2 * .5)), fill="white", anchor="mm")
    return im

def rms_at(state, t):
    al = state.get("align")
    if not al or not al.get("rms"): return 0
    r = al["rms"]; i = int(t * 30); return r[i] if 0 <= i < len(r) else 0

# ---------- 单条消息 ----------
def measure(it, idx=0, state=None):
    if it["kind"] == "time": return 70
    if it["kind"] == "cap": return 150
    if it["kind"] == "typing": return AV + 20
    return 46 + text_h(wrap(it["shot"]["line"]), _shot_homophones(state or {})) + 34 + 10

def msg_layer(state, it, h, t):
    s = it["shot"]; c = state["chars"][s["name"]]; me = s["name"] == self_name(state)
    lines = wrap(s["line"]); homos = _shot_homophones(state); bw = text_w(lines) + 56; bh = text_h(lines, homos) + 30
    live = s["t0"] <= t <= s["t1"] + 0.3
    L = Image.new("RGBA", (W, h)); d = ImageDraw.Draw(L)
    # Enlarges the actual face by up to 30% while speaking, with smoothly breathing zoom.
    # Works even if the source does not contain an RMS cache.
    dt = min(max(t - s["t0"], 0), max(s["t1"] - t, 0))
    gate = ease_inout(min(1.0, dt / 0.22)) if live else 0.0
    breathe = 0.70 + 0.30 * math.sin(max(0, t - s["t0"]) * 7.5) ** 2
    audible = min(1.0, max(0.0, rms_at(state, t)))
    pulse = gate * min(1.0, breathe * (0.88 + audible * 0.12))
    av = avatar(c, pulse=pulse, emotion=pick_emotion(s, c), name=s["name"])
    times = char_times(state, s) if live else None
    if me:
        L.alpha_composite(av, (W - 36 - AV - 24, -24)); x1 = W - 36 - AV - 22; x0 = x1 - bw; by = 6
        d.rounded_rectangle([x0, by, x1, by + bh], 14, fill=GREEN); d.polygon([(x1, by + 34), (x1 + 14, by + 44), (x1, by + 54)], fill=GREEN)
        draw_text(L, x0 + 28, by + 14, lines, times, t, dim=(80, 140, 60), homos=homos)
    else:
        L.alpha_composite(av, (36 - 24, -24)); x0 = 36 + AV + 22
        d.text((x0 + 4, -2), c.get("display_name") or s["name"], font=FNAME, fill=(150, 150, 150)); by = 42
        d.rounded_rectangle([x0, by, x0 + bw, by + bh], 14, fill="white"); d.polygon([(x0, by + 34), (x0 - 14, by + 44), (x0, by + 54)], fill="white")
        draw_text(L, x0 + 28, by + 14, lines, times, t, homos=homos)
    return L

def typing_layer(state, it, t):
    s = it["shot"]; c = state["chars"][s["name"]]; me = s["name"] == self_name(state)
    L = Image.new("RGBA", (W, AV + 20)); d = ImageDraw.Draw(L); txt = "正在输入"; f = F(34, False)
    bw = tw(txt, f) + 140; bh = 76; n = int(t * 6) % 4
    emo = pick_emotion(it.get("shot") or {}, c)
    nm = (it.get("shot") or {}).get("name")
    if me: x1 = W - 36 - AV - 22; x0 = x1 - bw; L.alpha_composite(avatar(c, emotion=emo, name=nm), (W - 36 - AV - 24, -24))
    else: x0 = 36 + AV + 22; L.alpha_composite(avatar(c, emotion=emo, name=nm), (22, -24))
    d.rounded_rectangle([x0, 14, x0 + bw, 14 + bh], 14, fill=GREEN if me else "white")
    d.text((x0 + 26, 14 + bh / 2), txt, font=f, fill=(140, 140, 140), anchor="lm")
    for j in range(3):
        cx = x0 + 26 + tw(txt, f) + 24 + j * 26
        d.ellipse([cx - 7, 14 + bh / 2 - 7 - (6 if j == n % 3 else 0), cx + 7, 14 + bh / 2 + 7 - (6 if j == n % 3 else 0)], fill=(150, 150, 150))
    return L

def cap_layer(it):
    L = Image.new("RGBA", (W, 150)); d = ImageDraw.Draw(L); f = F(56); txt = it["text"]
    vn, _, zh = txt.partition("="); w = max(tw(txt, f) + 220, 520); x0 = (W - w) // 2
    d.rounded_rectangle([x0, 12, x0 + w, 138], 22, fill=(255, 250, 230), outline=(245, 175, 40), width=4)
    d.rounded_rectangle([x0 + 22, 46, x0 + 150, 104], 12, fill=(245, 150, 30)); d.text((x0 + 86, 75), "划重点", font=F(30), fill="white", anchor="mm")
    d.text((x0 + 172, 75), txt, font=f, fill=(170, 70, 0), anchor="lm")
    if not zh.strip() and gloss(vn.strip()): d.text((x0 + 172 + tw(txt, f) + 16, 75), f"({gloss(vn.strip())})", font=F(36, False), fill=(200, 120, 40), anchor="lm")
    return L

def time_layer(clock):
    L = Image.new("RGBA", (W, 70))
    ImageDraw.Draw(L).text((W // 2, 35), clock, font=F(30, False), fill=(170, 170, 170), anchor="mm")
    return L


# ---------- 顶部横幅 + 单词卡 ----------
_banner_cache = {}

def _tb(d, s, font):
    b = d.textbbox((0, 0), s, font=font); return b[2] - b[0], b[3] - b[1]

def vietnam_flag(w=92, h=62):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w - 1, h - 1], 6, fill=(218, 37, 29))
    star(d, w / 2, h / 2 + 1, h * 0.32, (255, 213, 0))
    return im

def _banner_image(path):
    key = ("v2", BRAND_IMAGE)
    if key in _banner_cache:
        return _banner_cache[key]
    L = Image.new("RGBA", (W, BANNER_H), (18, 19, 43, 255))
    d = ImageDraw.Draw(L)
    # Lightweight navy-to-plum gradient, keeping the title readable at iPhone size.
    for yy in range(BANNER_H):
        k = yy / max(1, BANNER_H - 1)
        col = (int(19 + k * 15), int(19 + k * 3), int(45 - k * 5), 255)
        d.line((0, yy, W, yy), fill=col)
    # right original artwork: never stretch across the whole frame
    path = BRAND_IMAGE if os.path.isfile(BRAND_IMAGE) else path
    if path and os.path.isfile(path):
        art = Image.open(path).convert("RGBA")
        art = art.resize((410, 270), Image.Resampling.LANCZOS)
        L.alpha_composite(art, (670, 5))
        # Gradual left blend for headline text.
        f = Image.new("RGBA", (470, BANNER_H), (0, 0, 0, 0));fd = ImageDraw.Draw(f)
        for xx in range(470):
            a = int(255 * max(0, 1 - xx / 240) ** 1.5)
            fd.line((xx, 0, xx, BANNER_H), fill=(20, 20, 43, a))
        L.alpha_composite(f, (610, 0))
    # Baseline accent
    d = ImageDraw.Draw(L)
    d.line([(0, BANNER_H - 4), (W, BANNER_H - 4)], fill=(222, 174, 85, 235), width=4)
    _banner_cache[key] = L
    return L

def _episode(state):
    return state.get("episode") or {}

def banner_layer(state):
    ep = _episode(state)
    L = _banner_image(ep.get("banner")).copy()
    d = ImageDraw.Draw(L)
    # Move all branding UP; form two explicit typographic levels.
    fx, fy = 28, 74
    L.alpha_composite(vietnam_flag(78, 52), (fx, fy))
    x = fx + 92
    title_font = F(57)
    d.text((x + 2, 74 + 3), "越南语", font=title_font, fill=(8, 8, 18))
    d.text((x, 74), "越南语", font=title_font, fill=(248, 248, 248))
    x += _tb(d, "越南语", title_font)[0] + 7
    d.text((x + 2, 74 + 3), "趣味大剧场", font=title_font, fill=(8, 8, 18))
    d.text((x, 74), "趣味大剧场", font=title_font, fill=(255, 208, 97))
    sub = "每天一分钟学习越南语"
    fsub = F(33, False)
    sw, sh = _tb(d, sub, fsub)
    sx, sy, pw, ph = 44, 159, sw + 48, 56
    d.rounded_rectangle([sx+2, sy+4, sx+pw+2, sy+ph+4], 23, fill=(8, 8, 18, 170))
    d.rounded_rectangle([sx, sy, sx+pw, sy+ph], 23, fill=(139, 41, 52, 255), outline=(235, 178, 99, 255), width=2)
    d.text((sx + pw/2, sy + ph/2-1), sub, font=fsub, fill=(255, 249, 235), anchor="mm")
    # short secondary cue; avoids placing unreadably long episode tags over right artwork
    label = str(ep.get("episode_code") or f"EP{int(ep.get('number',1)):02d}")
    ftag = F(22, False)
    d.rounded_rectangle([42, 231, 42+126, 263], 11, fill=(255, 208, 97, 245))
    d.text((105, 247), label[:9], font=ftag, fill=(41, 22, 35), anchor="mm")
    d.text((183, 247), "轻松看剧 · 顺手学越语", font=F(24,False), fill=(195, 194, 207), anchor="lm")
    return L

def _round_gradient(size, c0, c1, radius, border=None, bw=5):
    w, h = size
    base = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    px = base.load()
    for y in range(h):
        k = y / max(h - 1, 1)
        # 轻微斜向
        col = tuple(int(c0[i] * (1 - k) + c1[i] * k) for i in range(3)) + (255,)
        for x in range(w):
            px[x, y] = col
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius, fill=255)
    base.putalpha(mask)
    if border:
        ImageDraw.Draw(base).rounded_rectangle([bw // 2, bw // 2, w - 1 - bw // 2, h - 1 - bw // 2], radius, outline=border, width=bw)
    return base

def vocab_card_layer(word, ep=None):
    """参考旧模板的「今日单词」卡：红标签、大红越南语词、中文义、例句。"""
    cw, pad = 930, 36
    fword, fmean, fex, fzh, flab, ftip, fhomo = F(112), F(54), F(36), F(28, False), F(29), F(24, False), F(34, False)
    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    word_s = word.get("word") or ""
    mean_s = word.get("meaning") or ""
    avail = cw - 64 - 32
    # 词条+释义并排时必须完整露出来（如「đợi một chút | 等一下」）
    for wsz, msz in ((112, 54), (100, 48), (88, 42), (76, 36), (64, 32), (56, 28)):
        fword, fmean = F(wsz), F(msz, False) if msz <= 36 else F(msz)
        ww = _tb(probe, word_s, fword)[0]
        mw = _tb(probe, mean_s, fmean)[0] if mean_s else 0
        sep = (36 + 8 + 36) if mean_s else 0
        if ww + sep + mw <= avail:
            break
    ww = _tb(probe, word_s, fword)[0]
    mw = _tb(probe, mean_s, fmean)[0] if mean_s else 0
    ex = word.get("example_vi") or ""
    zh = word.get("example_zh") or ""
    homo = (word.get("homophone") or word.get("谐音") or "").strip()
    has_ex, has_homo = bool(ex or zh), bool(homo)
    homo_block = 52 if has_homo else 0
    ch = pad + 56 + 16 + 130 + homo_block + (120 if has_ex else 16) + pad // 2
    L = _round_gradient((cw, ch), (255, 250, 243), (251, 228, 214), 30, border=(224, 176, 79), bw=5)
    d = ImageDraw.Draw(L)
    # 红标签：喇叭与「今」字之间留出空隙，避免重叠
    lab = "今日单词"
    lw, lh = _tb(d, lab, flab)
    lx, ly = 36, 28
    pad_x, pad_y, icon_w, gap = 14, 9, 28, 12
    tag_h = max(lh + pad_y * 2, 46)
    tag_w = pad_x + icon_w + gap + lw + pad_x
    d.rounded_rectangle([lx, ly, lx + tag_w, ly + tag_h], 22, fill=(218, 61, 58))
    cx = lx + pad_x + icon_w / 2
    cy = ly + tag_h / 2
    # 小喇叭（整体落在 icon_w 槽内，右沿不超过 gap）
    d.polygon([(cx - 11, cy - 6), (cx - 2, cy - 4), (cx - 2, cy + 4), (cx - 11, cy + 6)], fill="white")
    d.polygon([(cx - 2, cy - 10), (cx + 11, cy - 14), (cx + 11, cy + 14), (cx - 2, cy + 10)], fill="white")
    d.arc([cx + 7, cy - 8, cx + 15, cy + 8], -70, 70, fill="white", width=2)
    d.text((lx + pad_x + icon_w + gap, cy), lab, font=flab, fill="white", anchor="lm")
    n = (ep or {}).get("number", 1)
    tip = word.get("tip") or f"越南语词汇卡 · 第{int(n):02d}集"
    d.text((cw - 32, ly + tag_h / 2), tip, font=ftip, fill=(142, 104, 99), anchor="rm")
    midy = ly + tag_h + 16 + 65
    d.text((64, midy), word_s, font=fword, fill=(214, 34, 33), anchor="lm")
    if mean_s:
        sep_x = 64 + ww + 36
        d.line([(sep_x, midy - 42), (sep_x, midy + 42)], fill=(122, 85, 78, 100), width=3)
        d.text((sep_x + 36, midy), mean_s, font=fmean, fill=(42, 28, 26), anchor="lm")
    if has_homo:
        hy = midy + 64
        hl, flh = "谐音", F(22)
        hlw, hlh = _tb(d, hl, flh)
        pill_w, pill_h = hlw + 20, 32
        d.rounded_rectangle([64, hy, 64 + pill_w, hy + pill_h], 8, fill=(224, 176, 79))
        d.text((64 + pill_w / 2, hy + pill_h / 2), hl, font=flh, fill="white", anchor="mm")
        d.text((64 + pill_w + 14, hy + pill_h / 2), homo, font=fhomo, fill=(122, 70, 28), anchor="lm")
    if has_ex:
        ey = midy + 70 + homo_block
        d.rounded_rectangle([36, ey, cw - 36, ch - 28], 14, fill=(255, 247, 241))
        d.text((56, ey + 16), ex, font=fex, fill=(31, 37, 40))
        if zh:
            d.text((56, ey + 62), zh, font=fzh, fill=(120, 89, 83))
    return L


def word_phase(w, t):
    """pending / card / fly / landed，以及该阶段内的本地时间。"""
    if w.get("t") is None:
        return "pending", 0.0
    dt = t - w["t"]
    hold = float(w.get("dur", CARD_HOLD))
    fly = float(w.get("fly", CARD_FLY))
    if dt < 0:
        return "pending", dt
    if dt < hold:
        return "card", dt
    if dt < hold + fly:
        return "fly", dt - hold
    return "landed", dt - hold - fly


def _zh_short(meaning):
    zh = meaning or ""
    for sep in ("、", "，", ",", "；", ";"):
        zh = zh.split(sep, 1)[0]
    return zh.strip()


def _chip_h_for_rows(rows, inner_h, inner_board):
    """一行时小卡约占黑板内高 75%；两行时均分剩余高度。"""
    if rows <= 1:
        return max(48, min(inner_h, int(round(inner_board * 0.75))))
    return max(40, (inner_h - CHIP_GAP_Y * (rows - 1)) // rows)


def _fonts_for_chip_h(chip_h, scale=1.0):
    """越南语略大于释义；谐音至少是释义字号的 70%。"""
    fzh = max(22, int(chip_h * 0.36 * scale))
    fvi = max(26, int(chip_h * 0.44 * scale))
    fho = max(int(math.ceil(fzh * 0.70)), int(chip_h * 0.26 * scale))
    return F(fvi), F(fzh), F(fho, False)


def _chip_fonts(scale=1.0, chip_h=None):
    # 小卡沿用大词汇卡字体（Noto），不是粉笔字
    h = chip_h or CHIP_H
    fvi, fzh, _ = _fonts_for_chip_h(h, scale)
    return fvi, fzh


def _homo_font(scale=1.0, meaning_size=None):
    if meaning_size:
        return F(max(int(math.ceil(meaning_size * 0.70)), int(meaning_size * 0.70)), False)
    return F(max(16, int(20 * scale)), False)


def _measure_mixed(vn, zh, fvi, fzh, gap=10):
    probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    vw = _tb(probe, vn, fvi)[0] if vn else 0
    zw = _tb(probe, zh, fzh)[0] if zh else 0
    return vw + (gap if vn and zh else 0) + zw


def _draw_mixed(d, x, y, vn, zh, fvi, fzh, fill_vi, fill_zh=None, gap=10):
    if fill_zh is None:
        fill_zh = fill_vi
    if vn:
        d.text((x, y), vn, font=fvi, fill=fill_vi, anchor="lm")
        x += _tb(d, vn, fvi)[0] + (gap if zh else 0)
    if zh:
        d.text((x, y), zh, font=fzh, fill=fill_zh, anchor="lm")


def _chip_size(word, fvi, fzh, chip_h=None, pad_x=None):
    vn, zh = (word.get("word") or ""), _zh_short(word.get("meaning"))
    homo = (word.get("homophone") or word.get("谐音") or "").strip()
    ch = chip_h or CHIP_H
    if pad_x is None:
        pad_x = max(14, int(ch * 0.10))
    gap = max(16, int(ch * 0.16))
    main = _measure_mixed(vn, zh, fvi, fzh, gap=gap) + max(8, int(ch * 0.06))
    hw = 0
    if homo:
        probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))
        hw = _tb(probe, f"谐音：{homo}", _homo_font(meaning_size=fzh.size))[0]
    return max(main, hw, int(ch * 0.9)) + pad_x * 2, ch


def _board_metrics():
    """黑板内沿和「今日单词」标签列宽。"""
    x0, y0 = BOARD_INSET + WOOD + 10, WOOD + BOARD_PAD_Y
    x1, y1 = W - BOARD_INSET - WOOD - 10, BOARD_H - WOOD - BOARD_PAD_Y
    flab = Fchalk(46)
    probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    lab_w = _tb(probe, "今日单词", flab)[0] + 12
    return x0, y0, x1, y1, lab_w, flab


def _place_chips(word_list, fvi, fzh, origin, max_x, chip_h):
    """按从左到右、最多两行排布，返回 (slots, rows) 或 None（放不下）。slots 里 y 先记行号。"""
    slots, x, row = [], origin, 0
    for w in word_list:
        cw, ch = _chip_size(w, fvi, fzh, chip_h=chip_h)
        if x + cw > max_x:
            row += 1
            x = origin
            if row >= BOARD_ROWS:
                return None
        slots.append((w, x, row, cw, ch))
        x += cw + CHIP_GAP_X
    return slots, row + 1 if word_list else 1


def layout_chips(words, plan=None, cartoon=False):
    """把单词从左到右排成最多两行。一行时用约占内高 75% 的大卡；需要两行时再缩小。plan 决定行数，避免后出现的词把已落子挤跳。"""
    plan = list(plan if plan is not None else words)
    x0, y0, x1, y1, lab_w, flab = _board_metrics()
    origin, max_x = (max(350, x0 + lab_w + 10) if cartoon else x0 + lab_w + 10), x1
    inner_h = y1 - y0
    inner_board = BOARD_H - 2 * WOOD

    def try_rows(rows_hint):
        ch = _chip_h_for_rows(rows_hint, inner_h, inner_board)
        for scale in (1.0, 0.92, 0.84, 0.76, 0.68, 0.6):
            fvi, fzh, fho = _fonts_for_chip_h(ch, scale)
            placed = _place_chips(plan, fvi, fzh, origin, max_x, ch)
            if placed is None:
                continue
            raw, rows = placed
            if rows <= rows_hint:
                return raw, rows, ch, fvi, fzh
        return None

    result = try_rows(1)
    if result is None:
        result = try_rows(2)
    if result is None:
        ch = _chip_h_for_rows(2, inner_h, inner_board)
        fvi, fzh, fho = _fonts_for_chip_h(ch, 0.6)
        raw, rows, x, row = [], 2, origin, 0
        for w in plan:
            cw, chs = _chip_size(w, fvi, fzh, chip_h=ch)
            if x + cw > max_x:
                row += 1
                x = origin
            if row < BOARD_ROWS:
                raw.append((w, x, row, cw, chs))
            x += cw + CHIP_GAP_X
        result = (raw, min(max(row + 1, 1), BOARD_ROWS), ch, fvi, fzh)

    raw, rows, chip_h, fvi, fzh = result
    block_h = rows * chip_h + max(0, rows - 1) * CHIP_GAP_Y
    y_start = y0 + max(0, ((y1 - y0) - block_h) // 2)
    index = {id(w): (x, y_start + row * (chip_h + CHIP_GAP_Y), cw, ch) for w, x, row, cw, ch in raw}
    slots = []
    for w in words:
        if id(w) in index:
            x, y, cw, ch = index[id(w)]
            slots.append((w, x, y, cw, ch))
    return slots, fvi, fzh


def _board_texture():
    key = (W, BOARD_H)
    cached = _cache.get(("board_tex", key))
    if cached is not None:
        return cached
    w, h = W, BOARD_H
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    fx0, fy0, fx1, fy1 = BOARD_INSET, 0, W - BOARD_INSET - 1, h - 1
    d.rounded_rectangle([fx0, fy0, fx1, fy1], 10, fill=(132, 82, 40))
    px = im.load()
    rng = random.Random(9)
    for y in range(fy0, fy1 + 1):
        for x in range(fx0, fx1 + 1):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            n = rng.randint(-12, 12) + int(8 * math.sin(x * 0.15 + y * 0.04) + 5 * math.sin(x * 0.07))
            px[x, y] = (max(0, min(255, r + n)), max(0, min(255, g + n // 2)), max(0, min(255, b + n // 3)), a)
    d.rounded_rectangle([fx0 + 2, fy0 + 2, fx1 - 2, fy1 - 2], 8, outline=(86, 52, 24), width=2)
    ix0, iy0, ix1, iy1 = fx0 + WOOD, fy0 + WOOD, fx1 - WOOD, fy1 - WOOD
    d.rounded_rectangle([ix0, iy0, ix1, iy1], 6, fill=(32, 78, 48))
    for y in range(iy0, iy1 + 1):
        for x in range(ix0, ix1 + 1):
            r, g, b, a = px[x, y]
            n = rng.randint(-7, 7) + int(2 * math.sin(x * 0.23) + 1.5 * math.sin(y * 0.31))
            if rng.random() < 0.02:
                n += rng.randint(6, 14)  # 细粉笔灰，保持不透明
            px[x, y] = (max(0, min(255, r + n // 2)), max(0, min(255, g + n)), max(0, min(255, b + n // 2)), 255)
    # 几道很淡的粉笔擦痕（直接改不透明像素，避免把黑板抠透）
    for _ in range(5):
        y = rng.randint(iy0 + 6, iy1 - 6)
        xs = rng.randint(ix0 + 4, max(ix0 + 4, ix1 - 120))
        xe = min(ix1 - 4, xs + rng.randint(50, 180))
        k = rng.uniform(0.05, 0.09)
        for x in range(xs, xe):
            yy = y + int(1.2 * math.sin((x - xs) * 0.28))
            if iy0 < yy < iy1:
                r, g, b, a = px[x, yy]
                px[x, yy] = (
                    int(r * (1 - k) + 210 * k),
                    int(g * (1 - k) + 220 * k),
                    int(b * (1 - k) + 190 * k),
                    255,
                )
    # 内沿一圈浅阴影，让木框更有厚度
    d.rounded_rectangle([ix0, iy0, ix1, iy1], 6, outline=(18, 42, 28), width=2)
    _cache[("board_tex", key)] = im
    return im


def _mini_card_layer(word, w, h, fvi, fzh):
    """黑板小卡：和大词汇卡同一套奶油金底、红词、深色释义。"""
    radius = max(12, min(22, int(h * 0.12)))
    bw = 3 if h < 100 else 4
    L = _round_gradient((w, h), (255, 250, 243), (251, 228, 214), radius, border=(224, 176, 79), bw=bw)
    d = ImageDraw.Draw(L)
    vn, zh = (word.get("word") or ""), _zh_short(word.get("meaning"))
    homo = (word.get("homophone") or word.get("谐音") or "").strip()
    pad_x = max(14, int(h * 0.10))
    gap = max(10, int(h * 0.08))
    sep = max(10, int(h * 0.18))
    if homo:
        main_y, homo_y = int(h * 0.36), int(h * 0.75)
    else:
        main_y, homo_y = h / 2, None
    x = pad_x
    if vn:
        d.text((x, main_y), vn, font=fvi, fill=(214, 34, 33), anchor="lm")
        x += _tb(d, vn, fvi)[0] + gap
    if vn and zh:
        d.line([(x, main_y - sep), (x, main_y + sep)], fill=(122, 85, 78, 140), width=2)
        x += gap
    if zh:
        d.text((x, main_y), zh, font=fzh, fill=(42, 28, 26), anchor="lm")
    if homo and homo_y is not None:
        d.text((pad_x, homo_y), f"谐音：{homo}", font=_homo_font(meaning_size=fzh.size), fill=(122, 70, 28), anchor="lm")
    return L


def _draw_chip(layer, x, y, w, h, word, fvi, fzh, alpha=1.0):
    if alpha <= 0:
        return
    ov = Image.new("RGBA", layer.size, (0, 0, 0, 0))
    # 轻阴影，让小卡从黑板上稍微浮起来
    sd = ImageDraw.Draw(ov)
    sd.rounded_rectangle([x + 2, y + 3, x + w + 1, y + h + 2], 12, fill=(20, 16, 10, int(70 * alpha)))
    card = _mini_card_layer(word, w, h, fvi, fzh)
    if alpha < 1:
        card.putalpha(card.getchannel("A").point(lambda v, a=alpha: int(v * a)))
    ov.alpha_composite(card, (x, y))
    layer.alpha_composite(ov)


def board_layer(state, t):
    L = _board_texture().copy()
    x0, y0, x1, y1, lab_w, flab = _board_metrics()
    lx, ly = x0, BOARD_H / 2
    ov = Image.new("RGBA", L.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    d.text((lx + 1, ly + 1), "今日单词", font=flab, fill=(20, 30, 20, 90), anchor="lm")
    d.text((lx, ly), "今日单词", font=flab, fill=(236, 232, 214, 255), anchor="lm")
    L.alpha_composite(ov)
    all_words = state.get("words") or []
    visible = [w for w in all_words if word_phase(w, t)[0] in ("fly", "landed")]
    if not visible:
        return L
    slots, fvi, fzh = layout_chips(visible, plan=all_words, cartoon=True)
    for w, x, y, cw, ch in slots:
        ph, local = word_phase(w, t)
        if ph == "landed":
            a = 1.0
        else:
            k = ease_inout(local / float(w.get("fly", CARD_FLY)))
            a = max(0.0, (k - 0.93) / 0.07)
        _draw_chip(L, x, y, cw, ch, w, fvi, fzh, a)
    return L


def _cartoon_c_board_layer(state, t):
    """透明文字与真实可动画单词卡，叠在画好的绿色木框黑板上。"""
    L = Image.new("RGBA", (W, BOARD_H), (0, 0, 0, 0))
    d = ImageDraw.Draw(L)
    # 「今日单词」固定标题已经印在9:16背景图中；这里只叠加本集动态单词卡，避免文字重复。
    all_words = state.get("words") or []
    visible = [w for w in all_words if word_phase(w, t)[0] in ("fly", "landed")]
    if not visible:
        return L
    slots, fvi, fzh = layout_chips(visible, plan=all_words, cartoon=True)
    for w, x, y, cw, ch in slots:
        phase, local = word_phase(w, t)
        alpha = 1.0 if phase == "landed" else max(0.0, (ease_inout(local / float(w.get("fly", CARD_FLY))) - 0.93) / 0.07)
        _draw_chip(L, x, y, cw, ch, w, fvi, fzh, alpha)
    return L


def _cartoon_c_chrome(im, state, t):
    """只叠加可变的节目文字、黑板词卡和输入栏；中间聊天由原渲染器真正绘制。"""
    d = ImageDraw.Draw(im)
    # 越南国旗、节目名称、口号、插画、黑板固定标题均烘焙在背景PNG，禁止重复渲染。
    # 今天单词以程序化卡片显示，卡背图本身不写任何固定教材内容。
    im.alpha_composite(_cartoon_c_board_layer(state, t), (0, CARTOON_C_BOARD_TOP))
    # 动态输入栏保持小、贴底，不复写聊天区域。
    y0 = INPUT_BAR_TOP
    d.rounded_rectangle([20, y0 + 13, W - 20, H - 13], radius=30, fill=(255, 251, 244, 247), outline=(209, 185, 146, 220), width=3)
    bar_mid = y0 + 55
    d.ellipse([40, bar_mid-28, 96, bar_mid+28], outline=(64, 87, 76), width=4)
    d.text((68, bar_mid), "◖", font=F(33,False), fill=(64, 87, 76), anchor="mm")
    d.rounded_rectangle([118, bar_mid-36, 851, bar_mid+36], radius=19, fill=(255, 255, 255), outline=(228, 220, 200), width=2)
    d.text((487, bar_mid), "按住 说话", font=F(34,False), fill=(148, 143, 133), anchor="mm")
    d.ellipse([866, bar_mid-29, 924, bar_mid+29], outline=(64, 87, 76), width=4)
    d.text((895, bar_mid), "☺", font=F(37,False), fill=(64, 87, 76), anchor="mm")
    d.ellipse([956, bar_mid-29, 1014, bar_mid+29], outline=(64, 87, 76), width=4)
    d.text((985, bar_mid), "+", font=F(46,False), fill=(64, 87, 76), anchor="mm")


def slot_rect(word, state, t):
    """目标筹码在整幅画面中的矩形 (x, y, w, h)。"""
    all_words = state.get("words") or []
    slots, _, _ = layout_chips(all_words, plan=all_words, cartoon=_cartoon_c_enabled(state))
    for w, x, y, cw, ch in slots:
        if w is word:
            return x, (CARTOON_C_BOARD_TOP if _cartoon_c_enabled(state) else TOP) + y, cw, ch
    return None


def draw_vocab_card(im, state, t):
    """New word: above the chalkboard -> scale down -> settle in exact blackboard slot.
    Never draw over the chat message area or show an opaque full-screen mask.
    """
    words = state.get("words") or []
    for w in words:
        ph, local = word_phase(w, t)
        if ph not in ("card", "fly"):
            continue
        rect = slot_rect(w, state, t)
        if not rect:
            continue
        ex, ey, ew, eh = rect
        all_words = state.get("words") or []
        _, fvi, fzh = layout_chips(all_words, plan=all_words, cartoon=_cartoon_c_enabled(state))
        start_y = (CARTOON_C_BOARD_TOP if _cartoon_c_enabled(state) else TOP) - 20
        # Start slightly ABOVE and to the RIGHT of the board label, then home to the exact slot.
        # Avoid obscuring the heading "今日单词" while the new word enters the stage.
        start_center_x = int(W * 0.69)
        if ph == "card":
            p = ease_inout(min(1.0, local / max(0.1, CARD_POP)))
            scale = 1.42 + 0.10 * p
            k = 0.0
        else:
            k = ease_inout(local / max(0.01, float(w.get("fly", CARD_FLY))))
            scale = 1.52 - 0.52 * k
        y = start_y * (1-k) + ey * k
        cw, ch = max(1,int(ew*scale)), max(1,int(eh*scale))
        # Use the SAME chip style for flying and landed phases, so text never morphs.
        mini = _mini_card_layer(w, ew, eh, fvi, fzh)
        layer = mini.resize((cw, ch), Image.Resampling.LANCZOS)
        center_x = start_center_x * (1-k) + (ex + ew/2) * k
        x = int(center_x - cw/2)
        # Avoid covering group title: floating card lives near top of board on right side.
        # Source y ranges from TOP-44 to the board's slot position.
        alpha = 1.0 if ph == "fly" else max(0.0, min(1.0, local / CARD_POP))
        if ph == "fly":
            alpha = 1.0 if k < 0.93 else max(0.0, (1-k)/0.07)
        if alpha <= 0:
            continue
        if alpha < 1:
            layer.putalpha(layer.getchannel("A").point(lambda a,alpha=alpha: int(a*alpha)))
        # Ensure no opaque dark backdrop blocks the chat or board.
        im.alpha_composite(layer, (int(x), int(y)))


# ---------- 界面外壳 ----------
def chrome(im, state, t=0):
    if _cartoon_c_enabled(state):
        return _cartoon_c_chrome(im, state, t)
    d = ImageDraw.Draw(im)
    # 顶部：横幅（替换假状态栏）+ 微信群顶栏 + 黑板单词栏
    im.alpha_composite(banner_layer(state), (0, 0))
    y0 = BANNER_H
    d.rectangle([0, y0, W, TOP], fill=(245, 245, 245))
    d.line([(0, TOP - 1), (W, TOP - 1)], fill=(222, 222, 224), width=3)
    d.line([(64, y0 + 52), (42, y0 + 74), (64, y0 + 96)], fill=(20, 20, 20), width=5)  # 返回
    ep = _episode(state)
    group = GROUP_NAME
    d.text((W // 2, y0 + 48), group, font=F(42), fill=(16, 16, 16), anchor="mm")
    d.text((W // 2, y0 + 96), "中国学员 · 越南老师 · 一起学越南语", font=F(24, False), fill=(145, 146, 151), anchor="mm")
    for j in range(3):
        d.ellipse([W - 112 + j * 24, y0 + 64, W - 100 + j * 24, y0 + 76], fill=(20, 20, 20))
    im.alpha_composite(board_layer(state, t), (0, TOP))
    # 输入栏贴近视频底边，只留底部必要安全区；原来1710起的一整块空白已收回给聊天消息。
    bar_center = INPUT_BAR_TOP + 54
    d.rectangle([0, INPUT_BAR_TOP, W, H], fill=(247, 247, 247))
    d.line([(0, INPUT_BAR_TOP), (W, INPUT_BAR_TOP)], fill=(220, 220, 220), width=2)
    d.ellipse([28, bar_center - 33, 94, bar_center + 33], outline=(30, 30, 30), width=4)
    for r in (10, 20, 30):
        d.arc([61 - r, bar_center - r, 61 + r, bar_center + r], -50, 50, fill=(30, 30, 30), width=4)
    d.rounded_rectangle([116, bar_center - 42, 844, bar_center + 42], 16, fill="white")
    d.text((480, bar_center), "按住 说话", font=F(34, False), fill=(174, 174, 174), anchor="mm")
    d.ellipse([872, bar_center - 33, 938, bar_center + 33], outline=(30, 30, 30), width=4)
    d.ellipse([888, bar_center - 10, 896, bar_center - 2], fill=(30, 30, 30))
    d.ellipse([912, bar_center - 10, 920, bar_center - 2], fill=(30, 30, 30))
    d.arc([887, bar_center - 10, 925, bar_center + 25], 20, 160, fill=(30, 30, 30), width=4)
    d.ellipse([970, bar_center - 33, 1036, bar_center + 33], outline=(30, 30, 30), width=4)
    d.line([(987, bar_center), (1019, bar_center)], fill=(30, 30, 30), width=4)
    d.line([(1003, bar_center - 16), (1003, bar_center + 16)], fill=(30, 30, 30), width=4)


# ---------- 音效画面反应 ----------
_EF = {}
def emoji(ch, size):
    k = (ch, size)
    if k not in _EF:
        im = Image.new("RGBA", (136, 128)); ImageDraw.Draw(im).text((0, 0), ch, font=ImageFont.truetype(EMOJI, 109), embedded_color=True)
        _EF[k] = im.crop(im.getbbox()).resize((size, size))
    return _EF[k]

def fx_laugh(im, dt, dur, seed):
    rnd = random.Random(seed); d = ImageDraw.Draw(im)
    for i in range(7):
        x0 = rnd.randint(80, W - 300); y0 = rnd.randint(900, 1500); delay = i * 0.12; p = (dt - delay) / (dur - delay)
        if not (0 <= p <= 1): continue
        y = y0 - 500 * p; a = int(255 * min(1, (1 - p) * 3)); sz = rnd.choice([60, 76, 90])
        col = rnd.choice([(255, 90, 90), (255, 160, 0), (240, 80, 200), (60, 160, 255)])
        if i % 3 == 0:
            e = emoji("😂", sz + 30).copy(); e.putalpha(e.getchannel("A").point(lambda v: v * a // 255)); im.alpha_composite(e, (x0, int(y)))
        else:
            L = Image.new("RGBA", (400, 140)); ImageDraw.Draw(L).text((10, 10), "哈哈哈", font=F(sz), fill=col + (a,), stroke_width=6, stroke_fill=(255, 255, 255, a))
            L = L.rotate(rnd.randint(-15, 15), expand=True); im.alpha_composite(L, (x0, int(y)))

def draw_crow(d, x, y, flap, s=1.0):
    k = s; body = (25, 25, 30)
    d.ellipse([x - 60 * k, y - 28 * k, x + 50 * k, y + 28 * k], fill=body)                 # 身体
    d.ellipse([x + 30 * k, y - 40 * k, x + 80 * k, y + 6 * k], fill=body)                  # 头
    d.polygon([(x + 78 * k, y - 22 * k), (x + 112 * k, y - 14 * k), (x + 78 * k, y - 6 * k)], fill=(250, 190, 40))  # 嘴
    d.ellipse([x + 56 * k, y - 30 * k, x + 66 * k, y - 20 * k], fill="white"); d.ellipse([x + 59 * k, y - 27 * k, x + 64 * k, y - 22 * k], fill="black")
    d.polygon([(x - 58 * k, y), (x - 110 * k, y - 20 * k), (x - 104 * k, y + 22 * k)], fill=body)  # 尾
    wy = -90 * k if flap else 60 * k
    d.polygon([(x - 30 * k, y - 6 * k), (x + 20 * k, y - 6 * k), (x - 20 * k, y + wy)], fill=(45, 45, 55))  # 翅膀

def fx_crow(im, dt, dur):
    p = dt / dur; x = -150 + (W + 300) * p; y = 620 + 40 * math.sin(p * 9); d = ImageDraw.Draw(im)
    draw_crow(d, x, y, int(dt * 8) % 2 == 0, 1.2)
    for j in range(1, 4):
        d.text((x - 140 - j * 60, y + 10 * math.sin(j + p * 9)), "·", font=F(70), fill=(80, 80, 80), anchor="mm")
    if 0.15 < p < 0.85: d.text((x + 10, y + 70), "嘎~ 嘎~", font=F(40), fill=(60, 60, 60), anchor="mm")
    a = int(255 * min(1, dt / 0.3, (dur - dt) / 0.3))
    L = Image.new("RGBA", (W, 200)); ImageDraw.Draw(L).text((W // 2, 100), "空气突然安静……", font=F(64), fill=(90, 90, 110, a), anchor="mm", stroke_width=6, stroke_fill=(255, 255, 255, a))
    im.alpha_composite(L, (0, 760))

def star(d, cx, cy, r, col):
    pts = [(cx + (r if i % 2 == 0 else r * .4) * math.cos(i * math.pi / 5 - math.pi / 2), cy + (r if i % 2 == 0 else r * .4) * math.sin(i * math.pi / 5 - math.pi / 2)) for i in range(10)]
    d.polygon(pts, fill=col)

def fx_sparkle(im, dt, dur):
    p = dt / dur; a = int(255 * min(1, dt / 0.15, (dur - dt) / 0.3)); L = Image.new("RGBA", (W, 600)); d = ImageDraw.Draw(L)
    for i in range(10):
        ang = i * math.pi / 5 + p; r = 140 + 220 * ease(p * 1.5)
        star(d, W / 2 + r * math.cos(ang), 300 + r * .7 * math.sin(ang), 26 + 10 * (i % 3), (255, 200 + (i % 3) * 20, 40, a))
    sc = 1 + 0.25 * math.sin(min(p * 4, 1) * math.pi)
    d.text((W / 2, 300), "叮咚！", font=F(int(120 * sc)), fill=(255, 150, 0, a), anchor="mm", stroke_width=10, stroke_fill=(255, 255, 255, a))
    im.alpha_composite(L, (0, 260))

def _end_vocab_rows(state):
    rows = []
    recap = state.get("words") or []
    if recap:
        for w in recap:
            homo = (w.get("homophone") or w.get("谐音") or "").strip()
            rows.append((w.get("word") or "", w.get("meaning") or "", homo))
    else:
        for vn, zh in state.get("board") or []:
            rows.append((vn, zh, ""))
    return [r for r in rows if r[0] or r[1]]


def _end_cast(state, cap=6):
    """本集有台词的主要人物。按 JSON 里的发言轮次（连续同角色气泡合并）计数，
    降序排列，并列按首次出场。最多 cap 人。不用拆句后的气泡数，以免把人排错。"""
    shots = state.get("shots") or []
    chars = state.get("chars") or {}
    turns = []
    for s in shots:
        name = s.get("name")
        if not name:
            continue
        if not turns or turns[-1] != name:
            turns.append(name)
    counts, first, order = {}, {}, []
    for i, name in enumerate(turns):
        if name not in first:
            first[name] = i
            order.append(name)
        counts[name] = counts.get(name, 0) + 1
    names = sorted(order, key=lambda n: (-counts[n], first[n]))[:cap]
    out = []
    for n in names:
        c = chars.get(n) or {"name": n, "color": (80, 80, 80)}
        out.append((n, c.get("display_name") or n, c))
    return out


def _end_smile_avatar(char, name, size, ring, ring_col):
    """九宫格 01微笑，圆形裁切，统一细色圈（不用每人一条高饱和角色色）。"""
    path = _resolve_avatar_path(char, "普通微笑") or _resolve_avatar_path(char, "微笑")
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((0, 0, size - 1, size - 1), fill=ring_col)
    inner = size - 2 * ring
    if inner < 8:
        return im
    if path:
        face = _prepare_face(path, inner)
        masked = Image.new("RGBA", (inner, inner), (0, 0, 0, 0))
        masked.paste(face, (0, 0))
        masked.putalpha(_circle_mask(inner))
        im.alpha_composite(masked, (ring, ring))
    else:
        d.ellipse((ring, ring, ring + inner - 1, ring + inner - 1), fill=(220, 214, 204))
        label = (char.get("avatar") or (name[:1] if name else "?"))
        d.text((size / 2, size / 2), label, font=F(int(size * 0.36)), fill=(90, 84, 76), anchor="mm")
    return im


def endcard(state, dt=1.0):
    """独立全屏片尾页（也作主页封面缩略图）：暗舞台聚光，无红幕。
    上：简标题+口号；中：今日单词（本集全部词汇）；下：出演人物不同表情拼贴。
    关键信息落在中央 3:4 安全区。"""
    import sys
    from pathlib import Path
    root = str(Path(__file__).resolve().parent.parent)
    if root not in sys.path:
        sys.path.insert(0, root)
    from stage_recap import render_stage_recap, cfg_from_state
    return render_stage_recap(cfg_from_state(state))


# ---------- 入口 ----------
_cache = {}
def items_at(state, t):
    """Clean chat: vocabulary now enters the blackboard instead of duplicate giant recap cards.
    Shot captions still live in the script for archival, but are not re-inserted into chat.
    """
    items = [dict(kind="time", t0=-10, key="time")]
    for shot in state["shots"]:
        if shot["t0"] <= t:
            items.append(dict(kind="msg", shot=shot, t0=shot["t0"], key=("m", shot["n"])))
        elif shot["t0"] - 0.4 <= t:
            items.append(dict(kind="typing", shot=shot, t0=shot["t0"] - 0.4, key=("t", shot["n"])))
    return sorted(items, key=lambda item: item["t0"])


def _endcard_t0(state):
    ad = state.get("audio_dur") or state["shots"][-1]["t1"]
    last = state["shots"][-1]["t1"]
    # 尾巴够长放尾巴里；不够则提前切到独立片尾页（不再叠在聊天上）
    return last if ad - last >= 3 else ad - 3


def draw_frame(state):
    t = state["t"]
    # 片尾：整页替换，不绘制、不透出聊天界面
    if (not state.get("no_endcard")) and t >= _endcard_t0(state) and (state.get("words") or state.get("board")):
        im = endcard(state, t - _endcard_t0(state))
        if len(_cache) > 60:
            _cache.clear()
        return im.convert("RGB")
    im = _cartoon_c_background() if _cartoon_c_enabled(state) else Image.new("RGBA", (W, H), BG)
    items = items_at(state, t)
    # 打字提示出现时不推动旧消息的“弹入”节奏：它也当作一条消息
    for it, y, h, k in layout_stack(items, t, lambda it, idx=0: measure(it, idx, state), BOTTOM, CARTOON_C_CHAT_TOP if _cartoon_c_enabled(state) else CHAT_TOP, 30):
        kind = it["kind"]
        if kind == "time":
            clock = chat_clock(state, t)
            lay = _cache.setdefault(("time", clock), time_layer(clock))
        elif kind == "cap": lay = _cache.setdefault(it["key"], cap_layer(it))
        elif kind == "typing": lay = typing_layer(state, it, t)
        else:
            s = it["shot"]; live = s["t0"] <= t <= s["t1"] + 0.3
            if live: lay = msg_layer(state, it, h, t)
            else: lay = _cache.get(it["key"]) or _cache.setdefault(it["key"], msg_layer(state, it, h, t))
        side = "right" if kind in ("msg", "typing") and it["shot"]["name"] == self_name(state) else ("center" if kind in ("cap", "time") else "left")
        pop(im, lay, (0, y), k if kind != "time" else 1, side)
    chrome(im, state, t)
    shake = 0
    for e in state.get("fx", []):
        dt = t - e["t"]
        if not (0 <= dt < e["dur"]): continue
        if e["type"] == "shake": shake = max(shake, 22 * (1 - dt / e["dur"]))
        elif e["type"] == "impact": shake = max(shake, 18 * (1 - dt / e["dur"]))
        elif e["type"] == "whoosh": shake = max(shake, 8 * (1 - abs(0.5 - dt / e["dur"]) * 2))
        elif e["type"] == "laugh": fx_laugh(im, dt, e["dur"], int(e["t"] * 10))
        elif e["type"] == "crow": fx_crow(im, dt, e["dur"])
        elif e["type"] in ("sparkle", "ding"):
            # Vocabulary is already taught by the calm animated blackboard chip.
            # Keep sound effects in audio mix, but avoid giant "叮咚" visual masking the board.
            pass
    draw_vocab_card(im, state, t)
    if shake:
        ox, oy = int(shake * math.sin(t * 90)), int(shake * 0.6 * math.cos(t * 70))
        sh = Image.new("RGBA", (W, H), BG); sh.alpha_composite(im, (ox, oy)); im = sh
    if len(_cache) > 60: _cache.clear()
    return im.convert("RGB")
