import unittest
from styles.chat_final import self_name, chat_clock, vocab_card_layer
from run_episode import guess_stem

class ChatConfigTests(unittest.TestCase):
    def test_new_cast_right_bubble(self):
        state = {"chars": {"唐哥": {}, "阿强": {}}, "episode": {"episode_code": "Z003"}}
        self.assertEqual(self_name(state), "唐哥")
    def test_custom_right_bubble(self):
        state = {"chars": {"唐哥": {}, "苏姐": {}}, "episode": {"self_name": "苏姐"}}
        self.assertEqual(self_name(state), "苏姐")
    def test_no_fake_right_bubble(self):
        state = {"chars": {"阿强": {}, "大鹏": {}}, "episode": {}}
        self.assertIsNone(self_name(state))
    def test_old_cast_compatibility(self):
        self.assertEqual(self_name({"chars": {"阿呆": {}}, "episode": {}}), "阿呆")
    def test_episode_stable_clock(self):
        state={"chars": {}, "episode": {"episode_code": "Z003"}}
        self.assertEqual(chat_clock(state, 0), chat_clock(state, 12))
        self.assertNotEqual(chat_clock(state, 0), chat_clock(state, 65))
    def test_explicit_clock(self):
        state = {"chars": {}, "episode": {"chat_start_time": "19:32"}}
        self.assertEqual(chat_clock(state, 0), "19:32")
        self.assertEqual(chat_clock(state, 61), "19:33")
    def test_invalid_clock(self):
        with self.assertRaises(ValueError):
            chat_clock({"episode": {"chat_start_time": "25:90"}})
    def test_z_episodes_named_correctly(self):
        self.assertEqual(guess_stem("/tmp/Z003_render.json", None), "Z003")
    def test_no_improvised_homophone(self):
        # Card rendering must not infer a made-up Chinese pronunciation when homophone is empty.
        from styles.chat_final import _fonts_for_chip_h
        self.assertTrue(callable(_fonts_for_chip_h))
        import inspect
        src=inspect.getsource(vocab_card_layer)
        self.assertIn('word.get("homophone")',src)
        self.assertIn('if has_homo:',src)

if __name__ == "__main__": unittest.main()
