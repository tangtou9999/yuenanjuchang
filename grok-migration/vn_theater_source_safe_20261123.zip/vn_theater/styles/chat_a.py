"""聊天风格A：群聊 App 风（浅灰底、白色气泡在左、主角在右绿色）"""
from PIL import Image, ImageDraw
from .chat_common import *
MAIN = "阿呆"; TOP, BOTTOM = 230, 1760
FN, FT, FNAME = F(46, False), F(30, True), F(28, False)
MAXW = 700; LH = 64

def _avatar(d, x, y, c, r=52):
    d.ellipse([x, y, x+2*r, y+2*r], fill=c["color"]); d.text((x+r, y+r), c["avatar"], font=F(48), fill="white", anchor="mm")

def _measure(st):
    def m(it, idx):
        if it["kind"] == "cap": return 120
        lines = wrap(it["shot"]["line"], FN, MAXW); return 50 + len(lines)*LH + 40
    return m

def _msg_layer(st, it, h):
    s = it["shot"]; c = st["chars"][s["name"]]; me = s["name"] == MAIN
    L = Image.new("RGBA", (W, h)); d = ImageDraw.Draw(L)
    lines = wrap(s["line"], FN, MAXW); bw = max(tw("".join(t for t, _ in ln), FN) for ln in lines) + 56
    bh = len(lines)*LH + 32
    if me:
        _avatar(d, W-140, 0, c); x1 = W-160; x0 = x1-bw
        d.text((x1, 6), f"{s['name']}", font=FNAME, fill=(120,120,120), anchor="ra")
        d.rounded_rectangle([x0, 44, x1, 44+bh], 22, fill=(149, 236, 105)); d.polygon([(x1, 70), (x1+16, 80), (x1, 92)], fill=(149,236,105))
        draw_rich(d, x0+28, 56, lines, FN, LH, (20,20,20), (200, 30, 30), hl=(255, 236, 120))
    else:
        _avatar(d, 36, 0, c); x0 = 160
        d.text((x0, 6), f"{s['name']} · {c['role']}", font=FNAME, fill=c["color"])
        d.rounded_rectangle([x0, 44, x0+bw, 44+bh], 22, fill="white"); d.polygon([(x0, 70), (x0-16, 80), (x0, 92)], fill="white")
        draw_rich(d, x0+28, 56, lines, FN, LH, (20,20,20), (200, 30, 30), hl=(255, 236, 120))
    return L

def _cap_layer(it):
    L = Image.new("RGBA", (W, 120)); d = ImageDraw.Draw(L); f = F(48); text = f"📌 今日单词  {it['text']}"
    text = f"今日单词  {it['text']}"; w = tw(text, f) + 120
    d.rounded_rectangle([(W-w)//2, 10, (W+w)//2, 110], 50, fill=(255, 244, 214), outline=(240, 170, 40), width=4)
    d.text((W//2, 60), text, font=f, fill=(190, 90, 0), anchor="mm"); return L

def draw_frame(state):
    im = Image.new("RGBA", (W, H), (237, 237, 237)); d = ImageDraw.Draw(im)
    for it, y, h, k in layout_stack(visible(state), state["t"], _measure(state), BOTTOM, TOP, 26):
        if it["kind"] == "cap": pop(im, _cap_layer(it), (0, y), k, "center")
        else: pop(im, _msg_layer(state, it, h), (0, y), k, "right" if it["shot"]["name"] == MAIN else "left")
    d.rectangle([0, 0, W, 200], fill=(237, 237, 237)); d.line([(0, 200), (W, 200)], fill=(210,210,210), width=2)
    d.text((60, 140), "‹", font=F(70, False), fill=(30,30,30), anchor="lm")
    d.text((W//2, 140), f"越南语自习室({len(state['chars'])})", font=F(46), fill=(20,20,20), anchor="mm")
    d.text((W-60, 140), "···", font=F(50), fill=(30,30,30), anchor="rm")
    d.text((W//2, 70), state["title"].split("：")[0], font=F(28, False), fill=(130,130,130), anchor="mm")
    d.rectangle([0, 1780, W, H], fill=(246,246,246)); d.line([(0,1780),(W,1780)], fill=(210,210,210), width=2)
    d.rounded_rectangle([110, 1810, 870, 1890], 14, fill="white"); d.ellipse([30, 1820, 90, 1880], outline=(60,60,60), width=4)
    d.ellipse([900, 1820, 960, 1880], outline=(60,60,60), width=4); d.ellipse([985, 1820, 1045, 1880], outline=(60,60,60), width=4)
    return im.convert("RGB")
