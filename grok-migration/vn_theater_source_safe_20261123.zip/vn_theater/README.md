# 越南语趣味自习室 · 批量渲染模板

每集只需要两样东西：**脚本 txt**（和 EP01 同样格式）+ **人声音频 mp3**。拍桌、乌鸦、叮咚等音效和背景音乐由程序按特效表自动混入，不必先用剪辑软件做好。

## 用法
```bash
python3 render.py EP02_script.txt EP02_audio.mp3 out/EP02.mp4            # 整集
python3 render.py EP02_script.txt EP02_audio.mp3 out/EP02_sample.mp4 --start 0 --dur 15   # 样片
```
输出：竖屏 1080x1920、30fps、H.264 + AAC。人声保持原响度；音效约 -12 dB 对齐画面特效；BGM 默认约 -15 dB（曲目先对齐到 −16 LUFS）循环铺底，说话时轻度闪避，空隙里大约比人声低 14–16 dB。整集 3 分钟约 4–5 分钟渲染完（纯 CPU）。

## 脚本里会自动读取的内容
- 标题：第一个《…》→ 顶部标题栏
- `### 【镜头 #N】 00:00.000 --> 00:07.936` → 镜头时间（镜头重叠时，在下一个镜头开始处切）
- `角色与声纹**：05·大鹏(自信男) … X:0.00, Y:0.05` → 说话人、人设、座位
- `台词**：「…」` → 底部字幕（越南语词自动标黄加下划线，长句按标点分页）
- `机位与动作` 里含越南语的 `【…】` → 弹出大字幕
- `黑板上写着今日单词：đi = 去，đồ ngốc = 傻瓜` → 黑板内容

## characters.json
每个角色的专属颜色 `color`，可选 `seat: [X, Y]` 覆盖座位、`avatar` 覆盖头像字。新角色没写的会自动配色。

## 画面效果
手绘教室背景（黑板/窗户/原木桌）、说话人高亮+大名牌、其他人缩小半透明、缓慢推拉镜头（推向说话人）、镜头间 0.25 秒交叉淡化。

## 风格（styles/）
- `styles/common.py`：公共绘图函数，入口 `draw_frame(state, THEME)`
- `styles/style_a.py` 暖色手绘教室（默认） / `style_b.py` 夜间霓虹综艺 / `style_c.py` 清新课本风，各自只定义 THEME 和 `draw_frame(state)`
- 选风格：`--style style_b`；只出一张预览图：`--still 51.5`（输出 png）
- 新风格：复制一个 style_x.py 改 THEME 颜色即可

## 最终风格 chat_final（群聊界面）
```bash
python3 render.py EP02_script.txt EP02_audio.mp3 out/EP02.mp4 --style chat_final
```
第一次运行会自动生成两个文件（同名放在脚本旁边，之后复用，可手动改）：
- `EP02_script.align.json`：逐字时间（faster-whisper small 模型，CPU 约 1 分钟）+ 音量曲线。需要 `.venv`（已装好）。也可单独跑：`.venv/bin/python align.py EP02_script.txt EP02_audio.mp3 EP02_script.align.json`。对不上的句子自动按字数平均分配时间。
- `EP02_script.effects.json`：画面特效表（shake 震屏 / laugh 哈哈哈+😂 / crow 乌鸦飞过 / sparkle 叮咚）。从脚本的音效清单自动生成：清单秒数和台词对不上，所以按描述内容匹配到对应那句台词。想改时间或加删特效，直接改这个 json，删掉它会重新生成：`python3 make_effects.py EP02_script.txt`。
- 注意：特效会同时出画面和声音。音效文件和音量在 `assets/sfx/sfx.json`（shake→拍桌、crow→乌鸦、sparkle/ding→叮咚、laugh→短促 pop、impact→撞击、whoosh→嗖、vocab→单词卡弹出叮咚、chalk→单词落入黑板的轻粉笔声）。BGM 在 `assets/bgm/bgm.json`，默认曲目 `comic_mischief`；某集要换歌或改音量，写一个旁边的 `EP02_script.mix.json`：`{"bgm": "baltic_levity", "bgm_volume_db": -15}`，或加 `--bgm` / `--bgm-vol` / `--no-bgm` / `--no-sfx`。许可证见各目录的 `LICENSES.md`。

画面内容：灰底群聊、白色气泡（右侧主角阿呆绿色，`styles/chat_final.py` 里 `MAIN` 可改）、方圆角自绘头像、正在说的那句逐字变黑（卡拉OK）、越南语黄色荧光+下方中文小注（词表在 `styles/chat_common.py` 的 `GLOSS`，新词要加进去）、说话时头像随音量跳动、新消息前 0.4 秒“正在输入…”、【…】显示成“划重点”卡片、最后 3 秒单词卡（音频尾巴够 3 秒就放在尾巴里）。

## 越南语词义（全自动，不用手改）
每次渲染自动运行 `glossary.py`：从台词和【…】里找出所有越南语词组，按优先级取中文意思：
1. 脚本里自己写的：`đi = 去`、`đi(去)`、`傻瓜(đồ ngốc)` 这类写法（标题、黑板、字幕、台词都会找）
2. 系列词库 `glossary.json`（每集自动累积，下一集直接复用；想改某个意思就改这里，source 改成 "manual" 后不会被覆盖）
3. 离线机器翻译（Argos Translate，越→英→中，最多 4 个字），词库里标 `"source": "mt"`
结果写到 `out/EP01_words.txt`（词 / 意思 / 来源），渲染前可以先看一眼。机器翻译不一定准，建议重点检查来源是 mt 的词。
单独运行：`.venv/bin/python glossary.py EP02_script.txt`

## 顶部横幅与单词卡（chat_final）
顶部不再画假手机状态栏，改为 `assets/banner/banner.png`（1080×约280）加标题文字：默认「越南语」白字 +「趣味大剧场」黄字，红胶囊副标题，右下角本集钩子。关键文字放在画面顶部约 120px 以下，避开抖音遮挡。
微信顶栏下方有一条深绿色木框黑板（粉笔白字，左侧写「今日单词」）。重点单词第一次出现时，弹出约 1.5 秒的「今日单词」大卡片（缩放淡入，并播放 ding 音效），随后约 0.6 秒以 ease-in-out 缩小飞入黑板下一空位，变成「đi 去」这样的小筹码，从左到右最多排两行，一直留到片尾。落入黑板时有一声轻粉笔声。气泡里原有的逐词中文小注仍保留。片尾单词卡也是同一套红金风格。
每集在脚本旁写 `EP01_script.mix.json`，可改集数、钩子、副标题和单词列表（`word` / `meaning` / `example_vi` / `example_zh`，可选 `homophone`（谐音）、`time` / `dur` / `fly`；默认取对齐结果里该词首次出现的时间，停留 1.5 秒再飞入 0.6 秒）。谐音只在本集配置里显式填写时才出现在大卡片和黑板小卡下面；没填就省略那一行，不从 `glossary.json` 猜测。

## 从语音 App 导入新一集

每一集从语音 App 下来都是同一套 JSON（`project_title`、`global_scene`、`sfx_spotting_list_seconds`、`millisecond_timeline`）加人声音频。用仓库里的 `import_voiceapp.py` 一次转成 `render.py` 能吃的脚本：

```bash
.venv/bin/python import_voiceapp.py incoming/EP04_render.json incoming/EP04_audio.mp3 \
    --outdir /workspace/ep04_sample --add-characters --align \
    --banner assets/banner/banner_05_stage.png

python3 render.py /workspace/ep04_sample/EP04_script.txt /workspace/ep04_sample/EP04_audio.mp3 \
    /workspace/ep04_sample/ep04_sample_15s.mp4 --style chat_final --start 0 --dur 15 --skip-glossary
```

脚本台词保持原文；镜头时间以 JSON 的 `start_ms`/`end_ms` 为主，`--align` 会用 whisper 逐字对齐并核对漂移，过长的一句会按标点拆成多条气泡。音效按 `action` 描述映射到 `assets/sfx` 里已有的 CC0 文件（没有的效果会跳过或用最接近的替代，不会自动下载不明版权的素材）。黑板单词只收用户原文里已经写明的词和谐音（例如 `姓赵（Xin chào）`、`Xin chào = 你好（谐音：姓赵）`），绝不自动编谐音。新角色若还没有头像，会在 `characters.json` 里补一个色块（加 `--add-characters`，请先备份）。

## 15 人固定名单与一集命令

从下一集开始，说话人必须对照 `roster15.json` 的固定编号+姓名（01唐哥 … 13肖雨晴，别名「肖老师」→ 13肖雨晴 … 15小美）。禁止沿用旧 12 人编号。`import_voiceapp.py` 会按姓名或「13·肖雨晴(…)」解析；编号与姓名冲突、或姓名不在名单里时，会把警告写入导入报告并以退出码 2 中止，**不会猜测替换，也不会开始渲染**。

一集从 MP3+JSON 到成片+封面（输出到新目录，不覆盖已有文件，也不改 EP01–EP04）：

```bash
.venv/bin/python run_episode.py incoming/EP05_render.json incoming/EP05_audio.mp3
.venv/bin/python run_episode.py incoming/EP05_render.json incoming/EP05_audio.mp3 --outdir /workspace/episodes/EP05
.venv/bin/python run_episode.py in.json in.mp3 --still 1.0 --no-align   # 只出静帧
```

目录已存在且非空时会自动改名。不要对 EP01–EP04 的既有目录使用本命令覆盖。

## 每集封面

`make_cover.py` 根据该集的 `mix.json`（和可选的 `*_render.json`）生成 1080×1920 封面；标题、人物、词汇卡都落在画面中间 1080×1440 里，方便小红书 3:4 裁切。谐音只用来自 mix 里写明的 `homophone`。

```bash
python3 make_cover.py /workspace/ep04_sample/EP04_script.mix.json \
  --json incoming/EP04_render.json -o /workspace/cover_check/EP04_cover.png
```

可选在 mix.json 里加 `cover` 覆盖自动推断：`theme`（stage / fresh / hot / night）、`hero`、`reactors`、`headline`、`highlight`。不写 theme 时，若 banner 文件名带 stage/fresh/hot/night 则用对应色，否则按集数轮换。
