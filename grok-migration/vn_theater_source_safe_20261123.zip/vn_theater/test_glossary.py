import glossary
for w in ["xin chào", "cảm ơn", "ăn cơm"]:
    zh, en = glossary.mt(w); print(f"{w} -> {en} -> {zh}"); assert zh and len(zh) <= 4
print("OK")
