"""风格A：暖色手绘教室（默认）"""
from .common import draw_frame as _df
THEME = dict(name="a", wall=[(250,232,200),(210,182,140)], window=(176,222,245), frame=(255,255,255),
  board_frame=(122,84,52), board=(38,74,56), board_head=(255,245,200), board_text=(255,255,255),
  table=[(160,110,66),(196,144,92),(176,126,78)], seat_label=(60,40,30), card_fill="char", card_radius=36, card_text=(255,255,255),
  title_bg=(20,24,40,235), accent=(255,196,0), title_text=(255,255,255), sub_bg=(0,0,0,170), sub_text=(255,255,255),
  sub_stroke=(0,0,0), vn=(255,214,0), cap_bg=(255,64,96), cap_text=(255,240,0), cap_stroke=(120,0,30), zoom=0.10)
def draw_frame(state): return _df(state, THEME)
