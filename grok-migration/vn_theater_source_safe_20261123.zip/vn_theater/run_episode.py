#!/usr/bin/env python3
"""一集流水线：语音 App 的 MP3+JSON → 导入（含 15 人名单校验）→ 对齐 → 成片 + 封面。

输出到一个新的分集目录，不覆盖已有文件，也不改 EP01–EP04 既有成果。
全片默认在片尾（回顾卡之后）硬切 1.0 秒静止封面，方便在抖音/快手里选封面帧；另存独立封面 PNG。

用法:
  .venv/bin/python run_episode.py incoming/EP05_render.json incoming/EP05_audio.mp3
  .venv/bin/python run_episode.py in.json in.mp3 --outdir /workspace/episodes/EP05
  .venv/bin/python run_episode.py in.json in.mp3 --still 1.0 --no-align   # 只出一张静帧

人物对不上名单时，导入阶段会写报告并以退出码 2 中止，不会开始渲染。
"""
from __future__ import annotations

import argparse, json, os, re, subprocess, sys, time
from datetime import datetime, timezone, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
# 默认成片目录放在仓库外面，避免和程序、EP01 缓存混在一起
DEFAULT_ROOT = os.path.abspath(os.path.join(HERE, "..", "episodes"))


def py() -> str:
    venv = os.path.join(HERE, ".venv", "bin", "python")
    return venv if os.path.isfile(venv) else sys.executable


def guess_stem(json_path: str, episode: int | None) -> str:
    base = os.path.basename(json_path)
    m = re.search(r"((?:EP|R)\d+)", base, re.I)
    if m:
        s = m.group(1).upper()
        return s if s.startswith("EP") else s
    if episode is not None:
        return f"EP{episode:02d}"
    m = re.search(r"EP0*(\d+)", open(json_path, encoding="utf-8").read(), re.I)
    if m:
        return f"EP{int(m.group(1)):02d}"
    return "EP"

# 禁止把新结果写进这些已有成果目录
PROTECTED = {
    os.path.abspath("/workspace/ep04_sample"),
    os.path.abspath("/workspace/cover_check"),
    os.path.abspath("/workspace/vn_theater"),
    os.path.abspath(HERE),
}



def write_stub_align(script_path: str, align_path: str):
    """--no-align 时写一份按镜头时间均分的占位对齐，避免 render.py 在缺 align.json 时自动跑 whisper。"""
    sys.path.insert(0, HERE)
    from render import parse
    _, shots = parse(script_path)
    lines = []
    for s in shots:
        text = s.get("line") or ""
        t0, t1 = float(s["t0"]), float(s["t1"])
        dur = max(0.2, t1 - t0)
        chars = []
        if text:
            step = dur / max(len(text), 1)
            for i, ch in enumerate(text):
                chars.append([ch, round(t0 + i * step, 3), round(t0 + (i + 1) * step, 3)])
        lines.append({"n": s["n"], "chars": chars, "match": 1.0})
    with open(align_path, "w", encoding="utf-8") as f:
        json.dump({"lines": lines, "rms": []}, f, ensure_ascii=False)
        f.write("\n")


def unique_outdir(requested: str | None, stem: str, overwrite: bool = False) -> str:
    saigon = timezone(timedelta(hours=7))
    stamp = datetime.now(saigon).strftime("%Y%m%d_%H%M%S")
    if requested:
        path = os.path.abspath(requested)
    else:
        path = os.path.join(DEFAULT_ROOT, f"{stem}_{stamp}")
    if os.path.abspath(path) in PROTECTED or os.path.abspath(path) == os.path.abspath(HERE):
        raise SystemExit(f"拒绝写入受保护目录: {path}（EP01–EP04 与程序目录不得覆盖）")
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
        return path
    if overwrite:
        return path
    # 目录已存在：如果是空的可以用；否则换时间戳后缀，绝不覆盖
    try:
        nonempty = any(os.scandir(path))
    except FileNotFoundError:
        nonempty = False
    if not nonempty:
        return path
    alt = f"{path.rstrip(os.sep)}_{stamp}"
    n = 2
    while os.path.exists(alt):
        alt = f"{path.rstrip(os.sep)}_{stamp}_{n}"
        n += 1
    os.makedirs(alt, exist_ok=True)
    print(f"目录已存在，改写到新目录: {alt}")
    return alt



def probe_duration(path: str) -> float:
    out = subprocess.check_output(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
        text=True,
    ).strip()
    return float(out)


def probe_audio(path: str) -> tuple[int, int]:
    out = subprocess.check_output(
        ["ffprobe", "-v", "error", "-select_streams", "a:0",
         "-show_entries", "stream=sample_rate,channels", "-of", "csv=p=0", path],
        text=True,
    ).strip()
    if not out:
        return 44100, 2
    parts = [x for x in out.split(",") if x]
    rate = int(float(parts[0])) if parts else 44100
    ch = int(float(parts[1])) if len(parts) > 1 else 2
    return rate, ch


def append_cover_hold(video: str, cover_png: str, out: str, hold: float = 1.0, fps: int = 30) -> float:
    """在成片末尾硬切接上 hold 秒静止封面（无叠化），音轨用静音。返回封面段起点（秒）。"""
    if hold <= 0:
        raise ValueError("hold must be positive")
    start = probe_duration(video)
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    if os.path.abspath(out) == os.path.abspath(video):
        raise SystemExit("append_cover_hold 拒绝覆盖原成片，请另给输出路径")
    # 片尾拼接也强制 iPhone 友好编码：Main@L4.0 / yuv420p / avc1 / AAC 48k 立体声 / faststart
    filt = (
        f"[0:v]fps={fps},scale=1080:1920:flags=lanczos,format=yuv420p,setsar=1,setpts=PTS-STARTPTS[v0];"
        f"[1:v]fps={fps},scale=1080:1920:flags=lanczos,format=yuv420p,setsar=1,setpts=PTS-STARTPTS[v1];"
        f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo,asetpts=PTS-STARTPTS[a0];"
        f"[2:a]aformat=sample_rates=48000:channel_layouts=stereo,asetpts=PTS-STARTPTS[a1];"
        f"[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]"
    )
    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-i", video,
        "-loop", "1", "-t", f"{hold:.3f}", "-i", cover_png,
        "-f", "lavfi", "-t", f"{hold:.3f}", "-i", "anullsrc=r=48000:cl=stereo",
        "-filter_complex", filt,
        "-map", "[v]", "-map", "[a]",
        "-c:v", "libx264", "-preset", "medium", "-crf", "20",
        "-profile:v", "main", "-level:v", "4.0", "-pix_fmt", "yuv420p", "-tag:v", "avc1",
        "-c:a", "aac", "-ar", "48000", "-ac", "2", "-b:a", "192k",
        "-map_metadata", "-1", "-map_chapters", "-1", "-fflags", "+bitexact",
        "-movflags", "+faststart",
        out,
    ]
    rc = run(cmd)
    if rc != 0:
        raise SystemExit(f"拼接片尾封面失败（退出码 {rc}）")
    return start


def run(cmd: list[str], cwd=None) -> int:
    print("+", " ".join(cmd))
    return subprocess.call(cmd, cwd=cwd)


def main():
    ap = argparse.ArgumentParser(description="MP3+JSON → 导入 → 对齐 → 成片/静帧 + 封面（新目录，不覆盖）")
    ap.add_argument("json", help="语音 App 的 EP*_render.json")
    ap.add_argument("audio", help="对应人声音频 mp3/wav")
    ap.add_argument("--outdir", default=None, help="输出目录（已存在且非空时自动改名，绝不覆盖）")
    ap.add_argument("--stem", default=None)
    ap.add_argument("--episode", type=int, default=None)
    ap.add_argument("--banner", default="assets/banner/banner_05_stage.png")
    ap.add_argument("--style", default="chat_final")
    ap.add_argument("--no-align", action="store_true", help="跳过 whisper 对齐（自测静帧可用）")
    ap.add_argument("--still", type=float, default=None, help="只渲染该秒的一张 PNG，不出成片")
    ap.add_argument("--start", type=float, default=0)
    ap.add_argument("--dur", type=float, default=None, help="只渲一段成片（秒）；默认为全长")
    ap.add_argument("--roster", default=None)
    ap.add_argument("--cover-hold", type=float, default=1.0, dest="cover_hold",
                    help="片尾静止封面秒数，默认 1.0（30 帧）；设为 0 则跳过")
    ap.add_argument("--no-cover-hold", action="store_true", help="不在片尾接静止封面")
    ap.add_argument("--no-endcard", action="store_true", help="成片不追加回顾/封面页")
    ap.add_argument("--no-cover", action="store_true", help="不生成封面 PNG")
    ap.add_argument("--skip-import", action="store_true", help="复用已有脚本/音频/对齐，只重渲（不覆盖 EP01–EP04）")
    ap.add_argument("--overwrite", action="store_true", help="允许覆盖 --outdir 里已有成片和封面")
    args = ap.parse_args()

    json_path = os.path.abspath(args.json)
    audio_path = os.path.abspath(args.audio)
    if not os.path.isfile(json_path):
        raise SystemExit(f"找不到 JSON: {json_path}")
    if not os.path.isfile(audio_path):
        raise SystemExit(f"找不到音频: {audio_path}")

    stem = args.stem or guess_stem(json_path, args.episode)
    outdir = unique_outdir(args.outdir, stem, overwrite=args.overwrite)
    exe = py()

    import_cmd = [
        exe, os.path.join(HERE, "import_voiceapp.py"),
        json_path, audio_path,
        "--outdir", outdir, "--stem", stem,
    ]
    if args.episode is not None:
        import_cmd += ["--episode", str(args.episode)]
    if args.banner:
        import_cmd += ["--banner", args.banner]
    if args.roster:
        import_cmd += ["--roster", args.roster]
    if not args.no_align:
        import_cmd.append("--align")
    # 默认不加 --add-characters，避免改写 characters.json

    if args.skip_import:
        print("跳过导入，复用:", outdir)
    else:
        rc = run(import_cmd, cwd=HERE)
        if rc != 0:
            print(f"导入失败（退出码 {rc}），已中止，未渲染。请看目录里的 import_report。")
            sys.exit(rc)

    script = os.path.join(outdir, f"{stem}_script.txt")
    audio = os.path.join(outdir, f"{stem}_audio{os.path.splitext(audio_path)[1] or '.mp3'}")
    mix = os.path.join(outdir, f"{stem}_script.mix.json")
    if not os.path.isfile(script) or not os.path.isfile(audio):
        raise SystemExit(f"导入后未找到脚本或音频: {script} / {audio}")

    if args.no_align:
        alp = os.path.join(outdir, f"{stem}_script.align.json")
        if not os.path.exists(alp):
            write_stub_align(script, alp)
            print("已写占位对齐（--no-align，未跑 whisper）:", alp)

    if args.still is not None:
        still_path = os.path.join(outdir, f"{stem}_still_{args.still:g}s.png")
        render_cmd = [
            exe, os.path.join(HERE, "render.py"),
            script, audio, still_path,
            "--style", args.style, "--skip-glossary",
            "--still", str(args.still),
        ]
    else:
        hold = 0.0 if args.no_cover_hold else float(args.cover_hold or 0)
        out_main = os.path.join(outdir, f"{stem}_main.mp4") if hold > 0 else os.path.join(outdir, f"{stem}.mp4")
        out_mp4 = os.path.join(outdir, f"{stem}.mp4")
        render_cmd = [
            exe, os.path.join(HERE, "render.py"),
            script, audio, out_main,
            "--style", args.style, "--skip-glossary",
            "--start", str(args.start),
        ]
        if args.dur is not None:
            render_cmd += ["--dur", str(args.dur)]
    if args.no_endcard:
        render_cmd.append("--no-endcard")

    rc = run(render_cmd, cwd=HERE)
    if rc != 0:
        print(f"渲染失败（退出码 {rc}）")
        sys.exit(rc)

    cover_path = os.path.join(outdir, f"{stem}_cover.png")
    if not args.no_cover:
        cover_cmd = [
            exe, os.path.join(HERE, "make_cover.py"),
            mix, "--json", json_path, "-o", cover_path,
        ]
        rc = run(cover_cmd, cwd=HERE)
        if rc != 0:
            print(f"封面生成失败（退出码 {rc}）")
            sys.exit(rc)
    elif os.path.exists(cover_path):
        pass

    cover_start = None
    if args.still is None:
        hold = 0.0 if args.no_cover_hold else float(args.cover_hold or 0)
        if hold > 0:
            cover_start = append_cover_hold(out_main, cover_path, out_mp4, hold=hold, fps=30)
            info_path = os.path.join(outdir, f"{stem}_cover_hold.txt")
            with open(info_path, "w", encoding="utf-8") as f:
                f.write(f"cover_start_sec={cover_start:.3f}\n")
                f.write(f"cover_hold_sec={hold:.3f}\n")
                f.write(f"cover_end_sec={cover_start + hold:.3f}\n")
            print(f"片尾封面起点: {cover_start:.3f}s（硬切静止 {hold:.3f}s，无叠化，音轨静音）")
            print("  记录:", info_path)

    print("完成。输出目录:", outdir)
    print("  脚本:", script)
    if args.still is not None:
        print("  静帧:", still_path)
    else:
        print("  成片:", out_mp4)
        if cover_start is not None:
            print(f"  片尾封面起点: {cover_start:.3f}s")
    if not args.no_cover:
        print("  封面 PNG:", cover_path)


if __name__ == "__main__":
    main()
