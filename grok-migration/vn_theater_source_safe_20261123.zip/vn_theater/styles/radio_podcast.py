"""西贡深夜圆桌电台 / 吃瓜播客

独立新风格。不改 chat_final.py。只用现有 15 人九宫格头像 + MP3 + JSON。
13 号画面显示「肖老师」。谐音行仅在源 JSON 存在 homophone 字段时显示，绝不编造。
"""
from __future__ import annotations

import json
import math
import os
import subprocess
from functools import lru_cache

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
W, H = 1080, 1920
FB = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"

BRAND = "越南语趣味大剧场"
SLOGAN = "每天一分钟学习越南语"
SHOW = "西贡深夜圆桌电台"

GOLD = (212, 168, 72)
GOLD2 = (255, 214, 120)
GOLD_DIM = (140, 108, 48)
LED_VI = (120, 255, 200)
LED_ZH = (255, 236, 190)
LED_HOOK = (255, 196, 90)
WAVE = (80, 255, 200)
WAVE2 = (255, 210, 90)

# 九宫格真实顺序 01–09
EMO_FILE = {
    "微笑": "1_普通微笑.png", "普通微笑": "1_普通微笑.png",
    "大笑": "2_大笑.png",
    "坏笑": "3_坏笑.png",
    "疑惑": "4_懵.png", "懵": "4_懵.png",
    "震惊": "5_震惊.png",
    "生气": "6_生气.png",
    "尴尬": "7_害羞.png", "害羞": "7_害羞.png",
    "翻白眼": "8_无语.png", "无语": "8_无语.png",
    "委屈": "9_委屈.png",
}
EMO_BY_ID = {
    1: "1_普通微笑.png", 2: "2_大笑.png", 3: "3_坏笑.png",
    4: "4_懵.png", 5: "5_震惊.png", 6: "6_生气.png",
    7: "7_害羞.png", 8: "8_无语.png", 9: "9_委屈.png",
}
REACT_L = "2_大笑.png"     # 左侧围观：02大笑
REACT_R = "8_无语.png"     # 右侧围观：08翻白眼

TRANS = 0.25
BASE_D = 248
CX, LX, RX, SEAT_Y = 540, 210, 870, 500

_BG = None
_WAV = None  # (samples, sr)
_VOCAB = None  # official fields from source JSON (homophone only if key exists)
_FONT = {}


def font(size, bold=True):
    key = (size, bold)
    if key not in _FONT:
        path = FB if bold else FR
        _FONT[key] = ImageFont.truetype(path, size)
    return _FONT[key]


def ease(u):
    u = 0.0 if u < 0 else 1.0 if u > 1 else u
    return u * u * (3.0 - 2.0 * u)


def text_size(draw, text, fnt):
    b = draw.textbbox((0, 0), text, font=fnt)
    return b[2] - b[0], b[3] - b[1]


def paste_c(dst, src, x, y, alpha=1.0):
    if src is None or alpha <= 0:
        return
    if src.mode != "RGBA":
        src = src.convert("RGBA")
    if alpha < 0.999:
        a = src.split()[3].point(lambda p: int(p * alpha))
        src = src.copy()
        src.putalpha(a)
    dst.alpha_composite(src, (int(x - src.width / 2), int(y - src.height / 2)))


def glow_text(im, xy, text, fnt, fill, glow, radius=8, anchor="lt"):
    """LED 发光字：先在独立层模糊再叠实字。"""
    if not text:
        return
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.text(xy, text, font=fnt, fill=glow + (255,), anchor=anchor)
    layer = layer.filter(ImageFilter.GaussianBlur(radius))
    im.alpha_composite(layer)
    ImageDraw.Draw(im).text(xy, text, font=fnt, fill=fill + (255,), anchor=anchor)


# ── 源 JSON 词表：只信 vocab_summary 字段，不把 hook 改写成谐音 ──
def _find_source_json():
    cands = [
        os.path.join(ROOT, "incoming", "EP05_render.json"),
        os.path.join("/workspace/vn_theater/incoming", "EP05_render.json"),
    ]
    for p in cands:
        if os.path.isfile(p):
            return p
    return None


def official_vocab():
    global _VOCAB
    if _VOCAB is not None:
        return _VOCAB
    rows = []
    p = _find_source_json()
    if p:
        data = json.load(open(p, encoding="utf-8"))
        for v in data.get("vocab_summary") or []:
            if not isinstance(v, dict):
                continue
            hook = (v.get("hook") or "").strip()
            # 谐音行：仅当源 JSON 真有 homophone 字段且非空
            homo = None
            if "homophone" in v and str(v.get("homophone") or "").strip():
                homo = str(v.get("homophone")).strip()
            rows.append({
                "vi": (v.get("vi") or "").strip(),
                "zh": (v.get("zh") or "").strip(),
                "hook": hook,
                "homophone": homo,
            })
    _VOCAB = rows
    return rows


def lookup_vocab(word):
    w = (word or "").strip().lower()
    for r in official_vocab():
        if r["vi"].lower() == w:
            return r
    return None


# ── 静态背景（只画一次） ──
def _rr(d, box, r, **kw):
    d.rounded_rectangle(box, radius=r, **kw)


def build_background():
    im = Image.new("RGB", (W, H))
    px = im.load()
    for y in range(H):
        t = y / (H - 1)
        # 暗紫黑纵向渐变，中段略亮一点给灯台
        mid = 0.38
        if t < mid:
            u = t / mid
            r = int(16 + 10 * u)
            g = int(6 + 4 * u)
            b = int(26 + 8 * u)
        else:
            u = (t - mid) / (1 - mid)
            r = int(26 - 16 * u)
            g = int(10 - 6 * u)
            b = int(34 - 20 * u)
        for x in range(W):
            # 顶部麦位柔光、两侧暗角
            cx = 1 - min(1.0, abs(x - W / 2) / (W / 2))
            lift = 18 * math.exp(-((y - 480) / 260) ** 2) * (0.35 + 0.65 * cx)
            px[x, y] = (
                min(255, int(r + lift * 1.1)),
                min(255, int(g + lift * 0.5)),
                min(255, int(b + lift * 0.9)),
            )
    # 细密暗网格，电台机房感
    d = ImageDraw.Draw(im, "RGBA")
    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    for x in range(0, W, 40):
        gd.line((x, 0, x, H), fill=(180, 140, 60, 14))
    for y in range(0, H, 40):
        gd.line((0, y, W, y), fill=(180, 140, 60, 14))
    im = Image.alpha_composite(im.convert("RGBA"), grid)

    d = ImageDraw.Draw(im, "RGBA")
    # 顶栏金线
    d.rectangle((0, 0, W, 8), fill=GOLD + (255,))
    d.rectangle((0, 8, W, 12), fill=(80, 50, 20, 255))
    d.rectangle((0, H - 8, W, H), fill=GOLD + (255,))

    # 品牌
    glow_text(im, (W // 2, 70), BRAND, font(52), GOLD2, (180, 120, 40), 7, "mt")
    glow_text(im, (W // 2, 132), SLOGAN, font(30, False), (220, 200, 160), (80, 50, 20), 4, "mt")
    d.line((180, 168, 900, 168), fill=GOLD + (120,), width=1)

    # ON AIR 徽章 + 节目名
    badge = (70, 186, 250, 236)
    _rr(d, badge, 8, fill=(140, 18, 28, 255), outline=GOLD + (220,), width=2)
    d.text((160, 211), "ON AIR", font=font(24), fill=(255, 230, 230, 255), anchor="mm")
    d.text((W // 2, 211), SHOW, font=font(30), fill=GOLD2 + (255,), anchor="mm")
    d.text((940, 211), "SAIGON FM", font=font(20, False), fill=GOLD + (200,), anchor="mm")

    # 三麦位底托（凹槽）
    for x in (LX, CX, RX):
        _seat_well(im, x, SEAT_Y, 300 if x == CX else 240)

    # 波形槽
    _rr(d, (80, 710, 1000, 830), 18, fill=(8, 6, 14, 230), outline=GOLD + (140,), width=2)

    # 中央 LED 调音台面板（静态框 + 两侧旋钮推子）
    panel = (90, 860, 990, 1400)
    _rr(d, (panel[0] - 8, panel[1] - 8, panel[2] + 8, panel[3] + 8), 28,
        fill=(28, 18, 12, 255), outline=GOLD + (255,), width=4)
    _rr(d, panel, 22, fill=(6, 14, 12, 255), outline=GOLD_DIM + (200,), width=2)
    # 内屏玻璃
    _rr(d, (120, 900, 960, 1288), 16, fill=(4, 10, 9, 255), outline=(40, 80, 60, 180), width=2)
    # 扫描线（静态）
    scan = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(scan)
    for y in range(904, 1284, 4):
        sd.line((124, y, 956, y), fill=(40, 180, 120, 18))
    im.alpha_composite(scan)

    # 面板四角螺丝
    for sx, sy in ((108, 878), (972, 878), (108, 1382), (972, 1382)):
        d.ellipse((sx - 8, sy - 8, sx + 8, sy + 8), fill=(60, 42, 18, 255), outline=GOLD + (255,))
        d.ellipse((sx - 3, sy - 3, sx + 3, sy + 3), fill=GOLD + (255,))

    # 两侧拟物旋钮 + 推子（调音台）
    _mixer_side(im, 36, 920)
    _mixer_side(im, 1044, 920)

    # 底部字幕槽框
    _rr(d, (60, 1455, 1020, 1830), 22, fill=(10, 6, 16, 210), outline=GOLD + (90,), width=2)

    # 角落节目铭牌
    d.text((W // 2, 1878), "EP · 吃瓜播客  ROUNDTABLE", font=font(20, False),
           fill=GOLD_DIM + (180,), anchor="mm")
    return im.convert("RGBA")


def _seat_well(im, x, y, d):
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    dr = ImageDraw.Draw(layer)
    r = d // 2 + 18
    dr.ellipse((x - r, y - r, x + r, y + r), fill=(0, 0, 0, 90))
    # 细金圈底
    dr.ellipse((x - r + 10, y - r + 10, x + r - 10, y + r - 10), outline=GOLD + (60,), width=3)
    # 小咪头支架
    dr.rectangle((x - 6, y + r - 8, x + 6, y + r + 36), fill=GOLD_DIM + (200,))
    dr.ellipse((x - 16, y + r + 28, x + 16, y + r + 50), fill=(40, 28, 16, 255), outline=GOLD + (180,))
    im.alpha_composite(layer.filter(ImageFilter.GaussianBlur(1)))


def _mixer_side(im, cx, top):
    d = ImageDraw.Draw(im, "RGBA")
    for i, yy in enumerate((top, top + 70, top + 140)):
        d.ellipse((cx - 22, yy - 22, cx + 22, yy + 22), outline=GOLD + (200,), width=2, fill=(24, 16, 10, 255))
        ang = 40 + i * 50
        rad = math.radians(ang)
        d.line((cx, yy, cx + 14 * math.cos(rad), yy + 14 * math.sin(rad)), fill=GOLD2 + (255,), width=3)
    # 推子槽
    fx = cx
    d.rounded_rectangle((fx - 8, top + 190, fx + 8, top + 430), 4, fill=(8, 6, 10, 255), outline=GOLD + (140,))
    for k, yy in enumerate((top + 230, top + 300, top + 370)):
        col = GOLD if k == 1 else GOLD_DIM
        d.rounded_rectangle((fx - 16, yy - 8, fx + 16, yy + 8), 3, fill=col + (255,))


def background():
    global _BG
    if _BG is None:
        _BG = build_background()
    return _BG.copy()


# ── 头像 ──
def resolve_tile(emotion):
    """expression_id / 标签 → 九宫格文件名。"""
    if not emotion:
        return EMO_FILE["微笑"]
    s = str(emotion).strip()
    digits = ""
    rest = s
    if s and s[0].isdigit():
        i = 0
        while i < len(s) and s[i].isdigit():
            digits += s[i]
            i += 1
        rest = s[i:].lstrip("·._- ")
    if rest in EMO_FILE:
        return EMO_FILE[rest]
    for k, fn in EMO_FILE.items():
        if k and k in rest:
            return fn
    if digits:
        n = int(digits)
        if n in EMO_BY_ID:
            return EMO_BY_ID[n]
    return EMO_FILE["微笑"]


def avatar_path(name, filename):
    folder = os.path.join(ROOT, "assets", "avatars", name)
    p = os.path.join(folder, filename)
    return p if os.path.isfile(p) else None


@lru_cache(maxsize=256)
def circle_avatar(name, filename, diameter, dim=1.0):
    path = avatar_path(name, filename)
    d = max(8, int(diameter))
    im = Image.new("RGBA", (d, d), (0, 0, 0, 0))
    if not path:
        dr = ImageDraw.Draw(im)
        dr.ellipse((0, 0, d - 1, d - 1), fill=(40, 30, 50, 255), outline=GOLD + (200,), width=2)
        return im
    src = Image.open(path).convert("RGBA")
    src = src.resize((d, d), Image.Resampling.LANCZOS)
    mask = Image.new("L", (d, d), 0)
    ImageDraw.Draw(mask).ellipse((1, 1, d - 2, d - 2), fill=255)
    out = Image.new("RGBA", (d, d), (0, 0, 0, 0))
    out.paste(src, (0, 0))
    out.putalpha(mask)
    if dim < 0.999:
        # 变暗但不改变透明边缘
        rgb = out.convert("RGB")
        rgb = rgb.point(lambda p: int(p * dim))
        a = out.split()[3]
        out = rgb.convert("RGBA")
        out.putalpha(a)
    return out


@lru_cache(maxsize=32)
def gold_ring_plate(diameter, strength_q):
    """金色发光环。strength_q 为 0..8 量化，避免每帧重建。"""
    s = max(0.0, min(1.0, strength_q / 8.0))
    if s <= 0.01:
        return None
    pad = 70
    side = int(diameter + pad * 2)
    layer = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx = cy = side / 2
    r = diameter / 2
    # 背后柔光盘
    d.ellipse((cx - r - 36, cy - r - 36, cx + r + 36, cy + r + 36),
              fill=(255, 200, 80, int(70 * s)))
    for k, w, a in ((42, 26, 90), (26, 16, 150), (14, 8, 210)):
        col = (255, 214, 100, int(a * s))
        d.ellipse((cx - r - k, cy - r - k, cx + r + k, cy + r + k), outline=col, width=w)
    glow = layer.filter(ImageFilter.GaussianBlur(10))
    # 实边金环（不模糊，保证清晰可见）
    crisp = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    dc = ImageDraw.Draw(crisp)
    dc.ellipse((cx - r - 5, cy - r - 5, cx + r + 5, cy + r + 5),
               outline=(255, 224, 120, int(255 * s)), width=8)
    dc.ellipse((cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1),
               outline=(255, 246, 200, int(220 * s)), width=3)
    glow.alpha_composite(crisp)
    return glow


# ── 音频波形 ──
def load_wave(path):
    global _WAV
    if _WAV is not None and _WAV[2] == path:
        return _WAV[0], _WAV[1]
    if not path or not os.path.isfile(path):
        _WAV = (np.zeros(16000, np.float32), 16000, path)
        return _WAV[0], _WAV[1]
    raw = subprocess.check_output(
        ["ffmpeg", "-v", "error", "-i", path, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
        stderr=subprocess.DEVNULL,
    )
    samples = np.frombuffer(raw, dtype=np.float32)
    _WAV = (samples, 16000, path)
    return samples, 16000


def draw_waveform(im, samples, sr, t):
    """从真实 MP3 取样，画荧光跳动波形（showwaves 等效）。"""
    box = (100, 722, 980, 818)
    x0, y0, x1, y1 = box
    mid = (y0 + y1) / 2
    hmax = (y1 - y0) / 2 - 6
    n_bars = 72
    win = 0.70
    i1 = int(min(len(samples), max(0, t * sr)))
    i0 = int(max(0, i1 - win * sr))
    chunk = samples[i0:i1] if i1 > i0 else np.zeros(n_bars, np.float32)
    if len(chunk) < n_bars:
        chunk = np.pad(chunk, (n_bars - len(chunk), 0))
    hop = max(1, len(chunk) // n_bars)
    bars = []
    for i in range(n_bars):
        sl = chunk[i * hop:(i + 1) * hop]
        rms = float(np.sqrt(np.mean(sl * sl))) if len(sl) else 0.0
        peak = float(np.max(np.abs(sl))) if len(sl) else 0.0
        bars.append(0.65 * rms + 0.35 * peak)
    # 轻压缩，让日常说话也能看见跳动
    peak = max(bars) if bars else 0
    scale = 1.0 / max(0.08, min(0.45, peak * 1.6 + 0.02))
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    bw = (x1 - x0) / n_bars
    for i, v in enumerate(bars):
        h = max(3.0, min(hmax, v * scale * hmax))
        x = x0 + i * bw + 2
        # 金 + 青双色，中间更亮
        u = i / max(1, n_bars - 1)
        col = (
            int(WAVE[0] * (1 - u) + WAVE2[0] * u),
            int(WAVE[1] * (1 - u) + WAVE2[1] * u),
            int(WAVE[2] * (1 - u) + WAVE2[2] * u),
            230,
        )
        d.rectangle((x, mid - h, x + bw - 4, mid + h), fill=col)
    glow = layer.filter(ImageFilter.GaussianBlur(4))
    im.alpha_composite(glow)
    im.alpha_composite(layer)


# ── 说话人座位 & 过渡 ──
def speaker_runs(shots):
    runs = []
    for s in shots or []:
        name = s.get("name")
        t0 = float(s.get("t0") or 0)
        t1 = float(s["end"] if s.get("end") is not None else s.get("t1") or t0)
        if not runs or runs[-1]["name"] != name:
            runs.append({"name": name, "t0": t0, "t1": t1})
        else:
            runs[-1]["t1"] = t1
    return runs


def first_order(shots):
    order, i = {}, 0
    for s in shots or []:
        n = s.get("name")
        if n and n not in order:
            order[n] = i
            i += 1
    return order


def neighbors_of(runs, idx):
    cur = runs[idx]["name"]
    others = []
    if idx > 0:
        others.append(runs[idx - 1]["name"])
    if idx + 1 < len(runs) and runs[idx + 1]["name"] not in others:
        others.append(runs[idx + 1]["name"])
    for r in runs:
        if r["name"] != cur and r["name"] not in others:
            others.append(r["name"])
        if len(others) >= 2:
            break
    return cur, others[:2]


def layout_of(cur, others, order):
    sides = [n for n in others if n and n != cur]
    sides.sort(key=lambda n: order.get(n, 99))
    L = sides[0] if sides else None
    R = sides[1] if len(sides) > 1 else None
    lay = {}
    if L:
        lay[L] = dict(x=LX, scale=1.0, glow=0.0, dim=0.42, react="L")
    if cur:
        lay[cur] = dict(x=CX, scale=1.3, glow=1.0, dim=1.0, react=None)
    if R:
        lay[R] = dict(x=RX, scale=1.0, glow=0.0, dim=0.42, react="R")
    return lay


def lerp(a, b, e):
    return a + (b - a) * e


def seats_at(shots, t):
    runs = speaker_runs(shots)
    order = first_order(shots)
    if not runs:
        return {}, None, 0.0
    idx = 0
    for i, r in enumerate(runs):
        if t >= r["t0"]:
            idx = i
        else:
            break
    cur, others = neighbors_of(runs, idx)
    new = layout_of(cur, others, order)
    t_sw = runs[idx]["t0"]
    if idx == 0 or t - t_sw >= TRANS:
        return new, cur, 1.0
    e = ease((t - t_sw) / TRANS)
    prev_cur, prev_oth = neighbors_of(runs, idx - 1)
    old = layout_of(prev_cur, prev_oth, order)
    out = {}
    names = set(old) | set(new)
    for n in names:
        if n in old and n in new:
            o, k = old[n], new[n]
            out[n] = dict(
                x=lerp(o["x"], k["x"], e),
                scale=lerp(o["scale"], k["scale"], e),
                glow=lerp(o["glow"], k["glow"], e),
                dim=lerp(o["dim"], k["dim"], e),
                react=k["react"] if e >= 0.5 else o["react"],
                alpha=1.0,
                expr_blend=e if (o["react"] is None) != (k["react"] is None) else 1.0,
                prev_react=o["react"],
            )
        elif n in new:
            k = new[n]
            out[n] = dict(x=k["x"], scale=k["scale"], glow=k["glow"], dim=k["dim"],
                          react=k["react"], alpha=e, expr_blend=1.0, prev_react=None)
        else:
            o = old[n]
            out[n] = dict(x=o["x"], scale=o["scale"], glow=o["glow"], dim=o["dim"],
                          react=o["react"], alpha=1.0 - e, expr_blend=0.0, prev_react=None)
    return out, cur, e


def display_of(chars, name):
    c = (chars or {}).get(name) or {}
    return c.get("display_name") or name


def draw_seats(im, state, t):
    shots = state.get("shots") or []
    shot = state.get("shot") or {}
    chars = state.get("chars") or {}
    speaker_fn = resolve_tile(shot.get("emotion"))
    lay, cur, _ = seats_at(shots, t)
    # 先画暗的、后画亮的（说话人在上）
    items = sorted(lay.items(), key=lambda kv: (kv[1]["glow"], kv[1]["scale"]))
    for name, p in items:
        d = BASE_D * p["scale"]
        alpha = p.get("alpha", 1.0)
        react = p["react"]
        fn = speaker_fn if react is None else (REACT_L if react == "L" else REACT_R)
        # 过渡中表情交叉淡化
        av = circle_avatar(name, fn, int(d), p["dim"])
        pb = p.get("expr_blend", 1.0)
        prev_r = p.get("prev_react", None)
        if 0.0 < pb < 1.0:
            fn0 = speaker_fn if prev_r is None else (REACT_L if prev_r == "L" else REACT_R)
            av0 = circle_avatar(name, fn0, int(d), p["dim"])
            # 叠两张
            mix = Image.new("RGBA", av.size, (0, 0, 0, 0))
            a0 = av0.copy()
            a0.putalpha(a0.split()[3].point(lambda v: int(v * (1 - pb))))
            a1 = av.copy()
            a1.putalpha(a1.split()[3].point(lambda v: int(v * pb)))
            mix.alpha_composite(a0)
            mix.alpha_composite(a1)
            av = mix
        # 金环
        if p["glow"] > 0.02:
            ring = gold_ring_plate(int(d), int(round(p["glow"] * 8)))
            if ring is not None:
                paste_c(im, ring, p["x"], SEAT_Y, alpha)
        paste_c(im, av, p["x"], SEAT_Y, alpha)
        # 名牌固定在波形槽上方，避免居中放大后压住声波
        label = display_of(chars, name)
        col = GOLD2 if p["glow"] > 0.55 else (150, 130, 100)
        tag = Image.new("RGBA", (280, 54), (0, 0, 0, 0))
        td = ImageDraw.Draw(tag)
        td.rounded_rectangle((10, 4, 270, 48), 12,
                             fill=(16, 10, 8, int(210 * (0.55 + 0.45 * p["glow"]))),
                             outline=col + (int(220 * (0.4 + 0.6 * p["glow"])),), width=2)
        td.text((140, 26), label, font=font(26), fill=col + (255,), anchor="mm")
        paste_c(im, tag, p["x"], 678, alpha)


# ── LED 词卡 ──
def active_word(state, t):
    words = state.get("words") or []
    cur = None
    for w in words:
        tw = w.get("t")
        if tw is None:
            continue
        if t + 0.05 >= float(tw):
            cur = w
    return cur


def draw_led(im, state, t):
    w = active_word(state, t)
    d = ImageDraw.Draw(im)
    cx = W // 2
    if not w:
        glow_text(im, (cx, 1040), "收听中", font(64), (180, 200, 190), (20, 60, 40), 8, "mm")
        glow_text(im, (cx, 1130), "SAIGON MIDNIGHT RADIO", font(28, False),
                  GOLD, (60, 40, 10), 5, "mm")
        return
    src = lookup_vocab(w.get("word") or w.get("vi") or "")
    vi = (src["vi"] if src else None) or w.get("word") or ""
    zh = (src["zh"] if src else None) or w.get("meaning") or ""
    hook = (src["hook"] if src else "") or ""
    homo = src["homophone"] if src else None
    # 越南语大字（按宽度自适应）
    for sz in (96, 84, 72, 64, 56):
        f = font(sz)
        tw, _ = text_size(d, vi, f)
        if tw <= 780:
            break
    glow_text(im, (cx, 1000), vi, f, LED_VI, (20, 90, 60), 10, "mm")
    # 中文义
    for sz in (48, 42, 36, 32):
        fz = font(sz)
        tw, _ = text_size(d, zh, fz)
        if tw <= 800:
            break
    glow_text(im, (cx, 1100), zh, fz, LED_ZH, (80, 60, 20), 6, "mm")
    y = 1180
    # 汉越词 hook：仅展示 hook 原文（含「汉越词：…」），不另造谐音
    if hook.startswith("汉越词"):
        glow_text(im, (cx, y), hook, font(36), LED_HOOK, (90, 50, 10), 5, "mm")
        y += 64
    elif hook:
        # 非汉越词提示（如使用场景）用更小字，避免被当成谐音
        glow_text(im, (cx, y), hook, font(30, False), (180, 200, 180), (20, 40, 30), 4, "mm")
        y += 56
    # 谐音字段：源 JSON 没有则整行隐藏
    if homo:
        glow_text(im, (cx, y), "谐音  " + homo, font(32), (255, 170, 80), (80, 30, 0), 5, "mm")


# ── 字幕：换行 + 0.25s 淡入上滑，禁止跳动滚动 ──
def wrap_line(text, fnt, max_w):
    if not text:
        return []
    d = ImageDraw.Draw(Image.new("RGB", (8, 8)))
    lines, buf = [], ""
    punct = set("！？。，、；：,.!?;:…」』）)]")
    for ch in text:
        trial = buf + ch
        tw, _ = text_size(d, trial, fnt)
        if tw <= max_w or not buf:
            buf = trial
        else:
            lines.append(buf)
            buf = ch
    if buf:
        lines.append(buf)
    # 行末孤零标点并回上一行
    out = []
    for ln in lines:
        if out and ln.strip() and all(c in punct or c.isspace() for c in ln) and len(ln.strip()) <= 2:
            out[-1] += ln
        else:
            out.append(ln)
    return out


def current_shot_at(shots, t):
    cur = None
    for s in shots or []:
        t0 = float(s.get("t0") or 0)
        t1 = float(s["end"] if s.get("end") is not None else s.get("t1") or t0)
        if t0 <= t < t1:
            cur = s
        elif cur is None and t < t0:
            break
    return cur


def draw_subtitle(im, state, t):
    shots = state.get("shots") or []
    shot = state.get("shot") or current_shot_at(shots, t) or {}
    line = (shot.get("line") or "").strip()
    if not line:
        return
    t0 = float(shot.get("t0") or 0)
    e = ease((t - t0) / TRANS) if t >= t0 else 1.0
    # 上滑 18px + 淡入
    dy = int((1.0 - e) * 18)
    alpha = e
    fnt = font(40)
    # 过长则略缩小
    lines = wrap_line(line, fnt, 900)
    if len(lines) > 4:
        fnt = font(34)
        lines = wrap_line(line, fnt, 900)
    if len(lines) > 5:
        lines = lines[:5]
        lines[-1] = lines[-1].rstrip() + "…"
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    chars = state.get("chars") or {}
    name = display_of(chars, shot.get("name"))
    y0 = 1508 + dy
    d.text((W // 2, y0), name, font=font(26), fill=GOLD2 + (int(255 * alpha),), anchor="mt")
    y = y0 + 46
    lh = 56 if fnt.size >= 40 else 48
    for ln in lines:
        d.text((W // 2, y), ln, font=fnt, fill=(245, 240, 230, int(255 * alpha)), anchor="mt")
        y += lh
    im.alpha_composite(layer)


def draw_frame(state):
    t = float(state.get("t") or 0)
    im = background()
    # 波形
    audio = state.get("audio")
    try:
        samples, sr = load_wave(audio)
        draw_waveform(im, samples, sr, t)
    except Exception:
        pass
    draw_seats(im, state, t)
    draw_led(im, state, t)
    draw_subtitle(im, state, t)
    return im.convert("RGB")
