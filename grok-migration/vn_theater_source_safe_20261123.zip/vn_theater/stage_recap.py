#!/usr/bin/env python3
"""片尾/封面页：暗舞台聚光，无红幕。
上：简标题 + 口号；中：今日单词（本集全部词汇）；下：出演人物表情拼贴。
1080x1920，关键内容落在中间 3:4 安全区（上下各 240px）。
"""
from __future__ import annotations

import math
import os
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

HERE = Path(__file__).resolve().parent
W, H = 1080, 1920
SAFE_TOP, SAFE_BOT = 240, 1680
AVATAR_ROOT = HERE / "assets" / "avatars"
ROSTER_PATH = HERE / "roster15.json"
FB = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"

BG0, BG1 = (16, 12, 36), (52, 20, 50)
SPOT = (255, 214, 70)
GOLD = (224, 176, 79)
TITLE_W, TITLE_Y = (255, 255, 255), (255, 205, 33)
STROKE = (18, 12, 28)
CREAM = (255, 250, 243)
INK = (42, 28, 26)
MUTE = (122, 85, 78)
VI_COL = (156, 72, 28)
RING_ORANGE = (232, 112, 52)
RING_GOLD = (232, 176, 64)
RING_BLUES = [
    (70, 140, 214),
    (48, 168, 196),
    (92, 116, 214),
    (40, 148, 172),
    (110, 150, 230),
]
HOMO_GAP = 12

# 02–08，文件名用九宫格中文标签
POOL = ["大笑", "坏笑", "懵", "震惊", "生气", "害羞", "无语"]
POOL_FALLBACK = ["普通微笑", "委屈"]  # 仅当人数超过 7 时才用
ID_TO_EMO = {
    "2": "大笑", "02": "大笑",
    "3": "坏笑", "03": "坏笑",
    "4": "懵", "04": "懵",
    "5": "震惊", "05": "震惊",
    "6": "生气", "06": "生气",
    "7": "害羞", "07": "害羞",
    "8": "无语", "08": "无语",
    "1": "普通微笑", "01": "普通微笑",
    "9": "委屈", "09": "委屈",
}
LABEL_TO_EMO = {
    "大笑": "大笑", "笑": "大笑",
    "坏笑": "坏笑",
    "疑惑": "懵", "懵": "懵",
    "震惊": "震惊", "惊讶": "震惊", "吃惊": "震惊",
    "生气": "生气",
    "尴尬": "害羞", "害羞": "害羞",
    "翻白眼": "无语", "无语": "无语",
    "微笑": "普通微笑", "普通微笑": "普通微笑",
    "委屈": "委屈",
}


def F(sz, bold=True):
    return ImageFont.truetype(FB if bold else FR, int(sz), index=2)


def _tb(d, text, font, anchor="lt"):
    if not text:
        return (0, 0, 0, 0)
    return d.textbbox((0, 0), text, font=font, anchor=anchor)


def _tw(d, text, font, anchor="lt"):
    b = _tb(d, text, font, anchor)
    return b[2] - b[0], b[3] - b[1]


def stroke_text(base, xy, text, font, fill, stroke, sw, anchor="lt"):
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.text(xy, text, font=font, fill=stroke + ((stroke[3],) if len(stroke) == 4 else (255,)),
           anchor=anchor, stroke_width=sw, stroke_fill=stroke + ((stroke[3],) if len(stroke) == 4 else (255,)))
    d.text(xy, text, font=font, fill=fill + ((fill[3],) if len(fill) == 4 else (255,)), anchor=anchor)
    base.alpha_composite(layer)


def canon_emotion(raw) -> str | None:
    """把 JSON/脚本里的表情收成文件名标签；不在 02–08 的返回其规范名或 None。"""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    m = re.match(r"^0?([1-9])[:：._\-]?([一-鿿A-Za-z]*)$", s)
    if m:
        eid, lab = m.group(1), m.group(2)
        if lab and lab in LABEL_TO_EMO:
            return LABEL_TO_EMO[lab]
        return ID_TO_EMO.get(eid) or ID_TO_EMO.get(eid.zfill(2))
    if s in LABEL_TO_EMO:
        return LABEL_TO_EMO[s]
    if s in ID_TO_EMO:
        return ID_TO_EMO[s]
    return None


def assign_emotions(cast: list[dict]) -> list[dict]:
    """每人一张不同的 02–08 表情；优先用该角色在 JSON/脚本里真正用过的。"""
    taken = set()
    out = []
    for p in cast:
        used = []
        for raw in p.get("used") or []:
            e = canon_emotion(raw)
            if e in POOL and e not in used:
                used.append(e)
        pick = next((e for e in used if e not in taken), None)
        if pick is None:
            pick = next((e for e in POOL if e not in taken), None)
        if pick is None:
            pick = next((e for e in POOL_FALLBACK if e not in taken), POOL[len(taken) % len(POOL)])
        q = dict(p)
        q["emotion"] = pick
        out.append(q)
        taken.add(pick)
    return out


def load_display_names():
    out = {}
    if not ROSTER_PATH.exists():
        return out
    import json
    data = json.loads(ROSTER_PATH.read_text(encoding="utf-8"))
    for p in data.get("roster") or []:
        name = (p.get("name") or "").strip()
        disp = (p.get("display_name") or name).strip() or name
        folder = (p.get("avatar_folder") or name).strip()
        if name:
            out[name] = dict(display=disp, folder=folder)
        for a in p.get("aliases") or []:
            if a:
                out[str(a).strip()] = dict(display=disp, folder=folder or name)
    return out


def collect_cast_from_shots(shots, chars=None) -> list[dict]:
    """只收有台词的角色；按发言轮次再按镜头数排序。"""
    chars = chars or {}
    roster = load_display_names()
    turns, shots_n, first, used, order = {}, {}, {}, {}, []
    prev = None
    for i, s in enumerate(shots or []):
        name = (s.get("name") or "").strip()
        if not name:
            continue
        if name not in first:
            first[name] = i
            order.append(name)
            used[name] = []
            turns[name] = 0
            shots_n[name] = 0
        shots_n[name] += 1
        if prev != name:
            turns[name] += 1
            prev = name
        emo = s.get("emotion") or s.get("expression") or s.get("expression_id") or ""
        if emo:
            used[name].append(emo)
    names = sorted(order, key=lambda n: (-turns[n], -shots_n[n], first[n]))
    out = []
    for n in names:
        rec = roster.get(n) or {}
        c = chars.get(n) or {}
        disp = c.get("display_name") or rec.get("display") or n
        folder = rec.get("folder") or n
        out.append(dict(name=n, display_name=disp, folder=folder, used=used[n],
                        turns=turns[n], shots=shots_n[n]))
    return assign_emotions(out)


def collect_cast_from_json(data) -> list[dict]:
    tl = data.get("millisecond_timeline") or []
    shots = []
    for sh in tl:
        name = (sh.get("character_name") or "").strip()
        if not name:
            sp = sh.get("speaker") or ""
            m = re.search(r"\d+·([^(（]+)", sp)
            name = (m.group(1) if m else sp).strip()
            name = re.sub(r"（.*$|\(.*$", "", name).strip()
        shots.append(dict(
            name=name,
            emotion=sh.get("expression_label") or sh.get("expression") or sh.get("expression_id") or "",
        ))
    return collect_cast_from_shots(shots)


def _avatar_path(folder, emotion):
    folder = AVATAR_ROOT / (folder or "")
    if not folder.is_dir():
        return None
    if emotion:
        for fn in os.listdir(folder):
            m = re.match(r"^(\d+)_(.+)\.(png|jpg)$", fn, re.I)
            if m and m.group(2) == emotion:
                return folder / fn
    for emo in ("震惊", "大笑", "普通微笑"):
        for fn in os.listdir(folder):
            if fn.endswith(".png") and f"_{emo}." in fn:
                return folder / fn
    pngs = sorted(folder.glob("[0-9]_*.png")) or sorted(folder.glob("*.png"))
    pngs = [p for p in pngs if p.name != "grid_original.png"]
    return pngs[0] if pngs else None


def _subject_alpha(face_rgb: Image.Image) -> Image.Image:
    """抠掉九宫格浅灰摄影底。只用顶部/浅灰角取样，避免下巴或衣服污染背景色。"""
    a = np.array(face_rgb)
    h, w, _ = a.shape
    typ = np.array([186.0, 182.0, 188.0], dtype=np.float32)
    samples = [a[:12, :].reshape(-1, 3)]
    for block in (a[:14, :14], a[:14, -14:], a[-14:, :14], a[-14:, -14:]):
        med = np.median(block.reshape(-1, 3), axis=0).astype(np.float32)
        if np.linalg.norm(med - typ) < 45:
            samples.append(block.reshape(-1, 3))
    bg = np.median(np.concatenate(samples, 0), axis=0).astype(np.float32)
    pix = a.astype(np.float32)
    dev = np.linalg.norm(pix - bg, axis=2)
    # 低饱和且接近灰底的也视为背景
    mx, mn = pix.max(axis=2), pix.min(axis=2)
    grayish = ((mx - mn) < 22) & (np.linalg.norm(pix - typ, axis=2) < 48)
    alpha = np.clip((dev - 16) / 14.0, 0, 1)
    alpha = np.where(grayish & (dev < 40), alpha * 0.15, alpha)
    alpha = (alpha * 255).astype(np.uint8)
    # 削掉画布边，防止方框露出来
    alpha[:4, :] = 0
    alpha[-4:, :] = 0
    alpha[:, :4] = 0
    alpha[:, -4:] = 0
    return Image.fromarray(alpha, "L")


def pop_avatar(folder, emotion, diameter, ring_color, pop=True):
    """圆形头像 + 色环；头发可从圆顶冒出，不带浅灰方底。"""
    path = _avatar_path(folder, emotion)
    color = tuple(ring_color[:3])
    pad = int(diameter * 0.22)
    S = diameter + pad * 2
    ring = max(8, int(diameter * 0.07))
    cx = S // 2
    cy = int(S * 0.58) if pop else S // 2
    r = diameter // 2
    inner = r - ring

    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sh = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse([cx - r + 8, cy - r + 18, cx + r + 8, cy + r + 22], fill=(0, 0, 0, 120))
    out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(16)))
    d = ImageDraw.Draw(out)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (255,))

    if not path:
        d.ellipse([cx - inner, cy - inner, cx + inner, cy + inner], fill=color)
        ch = (folder or "?")[0]
        d.text((cx, cy), ch, font=F(max(24, inner)), fill="white", anchor="mm")
        return out, (cx, cy, r)

    face = Image.open(path).convert("RGB")
    face_side = int(inner * 2 * 1.06)
    face = face.resize((face_side, face_side), Image.Resampling.LANCZOS)
    sub = _subject_alpha(face)
    face_rgba = face.convert("RGBA")
    face_rgba.putalpha(sub)
    fx = cx - face_side // 2
    fy = cy - inner - int(inner * 0.16)

    disc = Image.new("L", (S, S), 0)
    ImageDraw.Draw(disc).ellipse([cx - inner, cy - inner, cx + inner, cy + inner], fill=255)
    disc = disc.filter(ImageFilter.GaussianBlur(1.2))
    in_face = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    in_face.paste(face.convert("RGBA"), (fx, fy))
    in_face.putalpha(disc)
    out.alpha_composite(in_face)

    if pop:
        cap = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        cap.paste(face_rgba, (fx, fy))
        # 溢出区用头顶椭圆光环，不用矩形，避免浅灰方块漏出
        cap_m = Image.new("L", (S, S), 0)
        ImageDraw.Draw(cap_m).ellipse(
            [cx - int(inner * 1.02), cy - int(inner * 1.35),
             cx + int(inner * 1.02), cy + int(inner * 0.15)],
            fill=255,
        )
        # 只保留圆顶以上（略伸进环内）
        wipe = Image.new("L", (S, S), 0)
        ImageDraw.Draw(wipe).rectangle(
            [0, 0, S, cy - inner + ring + 2],
            fill=255,
        )
        cap_m = ImageChops.multiply(cap_m, wipe)
        cap.putalpha(ImageChops.multiply(cap.split()[-1], cap_m))
        out.alpha_composite(cap)

    ring_l = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring_l)
    rd.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color + (255,), width=ring)
    if pop:
        wipe = Image.new("L", (S, S), 255)
        ImageDraw.Draw(wipe).rectangle(
            [cx - int(inner * 0.7), 0, cx + int(inner * 0.7), cy - inner + ring // 2],
            fill=0,
        )
        ring_l.putalpha(ImageChops.multiply(ring_l.split()[-1], wipe))
    out.alpha_composite(ring_l)
    return out, (cx, cy, r)


def paint_stage():
    """暗夜舞台 + 顶部聚光，无幕布、无红饰。"""
    yy = np.linspace(0.0, 1.0, H, dtype=np.float64)[:, None]
    xx = np.linspace(0.0, 1.0, W, dtype=np.float64)[None, :]
    k = np.clip(yy * 0.85 + xx * 0.15, 0, 1)[..., None]
    c0 = np.array(BG0, dtype=np.float64)
    c1 = np.array(BG1, dtype=np.float64)
    rgb = c0 * (1 - k) + c1 * k
    dither = ((np.arange(H, dtype=np.float64) * 0.381966) % 1.0) - 0.5
    rgb = rgb + dither[:, None, None]
    arr = np.clip(np.round(rgb), 0, 255).astype(np.uint8)
    im = Image.fromarray(arr, "RGB").convert("RGBA")

    # 聚光锥
    spot = np.zeros((H, W, 4), dtype=np.float32)
    sr, sg, sb = SPOT
    cx, top, bot_y = W / 2.0, -80.0, H * 0.82
    ys = np.arange(H, dtype=np.float64)
    xs = np.arange(W, dtype=np.float64)
    t = np.clip((ys - top) / (bot_y - top), 0, 1)
    half = 50.0 + (560.0 - 50.0) * t
    fade = (1 - t) * 0.58
    grid_x = xs[None, :]
    edge = np.abs(grid_x - cx) / np.maximum(half[:, None], 1)
    a = 255.0 * fade[:, None] * np.clip(1 - edge ** 1.6, 0, 1)
    a = np.clip(a, 0, 255)
    spot[..., 0] = sr
    spot[..., 1] = sg
    spot[..., 2] = sb
    spot[..., 3] = a
    # 顶部更亮的一盏柔光
    yy2, xx2 = np.ogrid[:H, :W]
    glow = np.exp(-((xx2 - W / 2) ** 2) / (2 * 260 ** 2) - ((yy2 - 280) ** 2) / (2 * 320 ** 2))
    g = Image.fromarray(np.clip(spot, 0, 255).astype(np.uint8), "RGBA")
    glow_im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ga = (glow * 70).astype(np.uint8)
    glow_im.paste(Image.fromarray(np.dstack([np.full_like(ga, 255), np.full_like(ga, 230), np.full_like(ga, 150), ga])), (0, 0))
    im = Image.alpha_composite(im, g)
    im = Image.alpha_composite(im, glow_im)

    # 四角暗角
    vig = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    vd = ImageDraw.Draw(vig)
    vd.rectangle([0, 0, W, H], fill=(0, 0, 0, 0))
    # 用渐变环近似：上下更暗一点（安全区外可更深）
    band = np.zeros((H, W), dtype=np.float32)
    for y in range(H):
        if y < SAFE_TOP:
            band[y] = 0.22 * (1 - y / SAFE_TOP)
        elif y > SAFE_BOT:
            band[y] = 0.28 * ((y - SAFE_BOT) / max(1, H - SAFE_BOT))
    side = np.clip((np.abs(np.linspace(-1, 1, W)) - 0.72) / 0.28, 0, 1) ** 2 * 0.18
    alpha = np.clip((band + side[None, :]) * 255, 0, 160).astype(np.uint8)
    vig = Image.fromarray(np.dstack([np.zeros((H, W, 3), dtype=np.uint8), alpha]), "RGBA")
    im = Image.alpha_composite(im, vig)

    # 几点碎星（不靠红幕）
    d = ImageDraw.Draw(im)
    stars = [(90, 200), (150, 310), (980, 220), (1020, 340), (70, 1700), (1000, 1720), (940, 280)]
    for i, (sx, sy) in enumerate(stars):
        r = 7 if i % 3 else 10
        _star(d, sx, sy, r, (255, 230, 140, 180))
    return im


def _star(d, x, y, r, fill):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.4
        pts.append((x + rad * math.cos(ang), y + rad * math.sin(ang)))
    d.polygon(pts, fill=fill)


def _draw_title(im, title_left, title_right, slogan, badge, y):
    """简标题：越南语（金）+ 趣味大剧场（白）+ 小集数徽章 + 口号。返回下沿 y。"""
    d = ImageDraw.Draw(im)
    ftitle = F(62)
    fl = title_left or "越南语"
    fr = title_right or "趣味大剧场"
    wl, hl = _tw(d, fl, ftitle)
    wr, hr = _tw(d, fr, ftitle)
    gap = 6
    badge_w = 0
    fb = F(28)
    if badge:
        bw, bh = _tw(d, badge, fb)
        badge_w = bw + 40 + 16
    total = wl + gap + wr + badge_w
    x = (W - total) / 2
    stroke_text(im, (x, y), fl, ftitle, TITLE_Y, STROKE, 4, anchor="lt")
    stroke_text(im, (x + wl + gap, y), fr, ftitle, TITLE_W, STROKE, 4, anchor="lt")
    title_bottom = y + max(hl, hr)
    if badge:
        bx1 = x + wl + gap + wr + 16
        by1 = y + 8
        bx2 = bx1 + bw + 40
        by2 = by1 + bh + 16
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([bx1, by1 + 5, bx2, by2 + 5], 14, fill=(90, 64, 22, 255))
        d.rounded_rectangle([bx1, by1, bx2, by2], 14, fill=(255, 224, 124, 255))
        d.text(((bx1 + bx2) / 2, (by1 + by2) / 2 - 1), badge, font=fb, fill=(63, 41, 24), anchor="mm")
        title_bottom = max(title_bottom, by2)
    y2 = title_bottom + 16
    if slogan:
        fs = F(28, False)
        # 不用红胶囊，一行浅金字
        stroke_text(im, (W / 2, y2), slogan, fs, (255, 228, 170), (20, 12, 28), 2, anchor="mt")
        sb = ImageDraw.Draw(im).textbbox((W / 2, y2), slogan, font=fs, anchor="mt")
        y2 = sb[3] + 8
        # 短金线
        d = ImageDraw.Draw(im)
        d.line((W / 2 - 40, y2 + 6, W / 2 + 40, y2 + 6), fill=GOLD + (255,), width=2)
        y2 += 16
    return y2


def _vocab_card(words, max_w=960):
    """今日单词：全部词汇。vi = zh；谐音仅当 JSON 有。无重叠。"""
    words = [w for w in (words or []) if (w.get("word") or w.get("meaning"))]
    if not words:
        return None
    n = len(words)
    cols = 1 if n <= 3 else 2
    probe = ImageDraw.Draw(Image.new("RGB", (8, 8)))

    if cols == 1:
        vi_sz, zh_sz, ho_sz, pad, head = (52, 44, 26, 28, 54) if n <= 2 else (46, 38, 24, 24, 50)
    else:
        vi_sz, zh_sz, ho_sz, pad, head = 40, 34, 22, 22, 50

    def fonts(vs, zs, hs):
        return F(vs), F(zs), F(hs, False), F(22)

    def measure_item(w, fvi, fzh, fho):
        vn = (w.get("word") or "").strip()
        zh = (w.get("meaning") or "").strip()
        homo = (w.get("homophone") or w.get("谐音") or "").strip()
        line = f"{vn}  =  {zh}" if vn and zh else (vn or zh)
        lb = probe.textbbox((0, 0), line, font=fvi, anchor="lt") if vn else probe.textbbox((0, 0), line, font=fzh, anchor="lt")
        # 用 vi 字号画整行时，中文也用略小字，宽度分开算
        vn_w, vn_h = _tw(probe, vn, fvi) if vn else (0, 0)
        eq_w, eq_h = _tw(probe, " = ", fzh)
        zh_w, zh_h = _tw(probe, zh, fzh) if zh else (0, 0)
        line_w = vn_w + eq_w + zh_w
        line_h = max(vn_h or 0, eq_h, zh_h or 0)
        ho_w, ho_h = (0, 0)
        ho_text = ""
        if homo:
            ho_text = "谐音  " + homo
            ho_w, ho_h = _tw(probe, ho_text, fho)
        h = 10 + line_h
        if homo:
            h += HOMO_GAP + ho_h
        h += 10
        return dict(vn=vn, zh=zh, homo=homo, ho_text=ho_text, line_w=line_w, line_h=line_h,
                    vn_w=vn_w, vn_h=vn_h, eq_w=eq_w, zh_w=zh_w, zh_h=zh_h, ho_w=ho_w, ho_h=ho_h, h=h)

    # 缩字号直到列宽装得下
    col_w = (max_w - pad * 2 - (20 if cols == 2 else 0)) / cols
    while True:
        fvi, fzh, fho, flab = fonts(vi_sz, zh_sz, ho_sz)
        specs = [measure_item(w, fvi, fzh, fho) for w in words]
        if all(s["line_w"] <= col_w - 8 and (not s["homo"] or s["ho_w"] <= col_w - 8) for s in specs) or vi_sz <= 28:
            break
        vi_sz -= 2
        zh_sz = max(24, zh_sz - 2)
        ho_sz = max(18, ho_sz - 1)

    fvi, fzh, fho, flab = fonts(vi_sz, zh_sz, ho_sz)
    specs = [measure_item(w, fvi, fzh, fho) for w in words]

    # 行高：按视觉行（每列同一行取最大）
    rows = [specs[i:i + cols] for i in range(0, n, cols)]
    row_hs = [max(s["h"] for s in row) for row in rows]
    lab = "今日单词"
    lw, lh = _tw(probe, lab, flab)
    head_h = max(head, lh + 22)
    cw = max_w
    ch = pad + head_h + sum(row_hs) + pad + 10
    L = Image.new("RGBA", (cw, ch + 8), (0, 0, 0, 0))
    sh = Image.new("RGBA", (cw, ch + 8), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([8, 12, cw - 2, ch + 2], 28, fill=(0, 0, 0, 110))
    L.alpha_composite(sh.filter(ImageFilter.GaussianBlur(10)))
    d = ImageDraw.Draw(L)
    d.rounded_rectangle([0, 0, cw - 8, ch - 6], 28, fill=CREAM + (255,), outline=GOLD + (255,), width=5)

    # 金标签（不用大红）
    d.rounded_rectangle([24, 18, 24 + lw + 32, 18 + lh + 14], 16, fill=GOLD + (255,))
    d.text((24 + (lw + 32) / 2, 18 + (lh + 14) / 2 - 1), lab, font=flab, fill=(63, 41, 24), anchor="mm")

    y = 18 + max(lh + 14, 36) + 8
    overlaps = []
    for ri, row in enumerate(rows):
        rh = row_hs[ri]
        for ci, s in enumerate(row):
            x0 = pad + int(ci * (col_w + (20 if cols == 2 else 0)))
            word_top = y + 10
            # 画 vi = zh，垂直按字形框对齐
            vn, zh = s["vn"], s["zh"]
            line_h = s["line_h"]
            vn_y = word_top + (line_h - s["vn_h"]) / 2 if vn else word_top
            if vn:
                d.text((x0, vn_y), vn, font=fvi, fill=VI_COL + (255,), anchor="lt")
                vn_bb = d.textbbox((x0, vn_y), vn, font=fvi, anchor="lt")
            else:
                vn_bb = (x0, word_top, x0, word_top + line_h)
            eq_x = x0 + s["vn_w"]
            eq_y = word_top + (line_h - _tw(d, " = ", fzh)[1]) / 2
            d.text((eq_x, eq_y), " = ", font=fzh, fill=MUTE + (255,), anchor="lt")
            zh_x = eq_x + s["eq_w"]
            zh_y = word_top + (line_h - s["zh_h"]) / 2 if zh else word_top
            if zh:
                d.text((zh_x, zh_y), zh, font=fzh, fill=INK + (255,), anchor="lt")
            if s["homo"]:
                ho_y = vn_bb[3] + HOMO_GAP
                # 小金「谐音」屑标 + 文字
                tag, tagf = "谐音", F(18)
                tw, th = _tw(d, tag, tagf)
                tag_h = th + 8
                d.rounded_rectangle([x0, ho_y, x0 + tw + 16, ho_y + tag_h], 7, fill=GOLD + (255,))
                d.text((x0 + (tw + 16) / 2, ho_y + tag_h / 2 - 1), tag, font=tagf, fill=(63, 41, 24), anchor="mm")
                hx = x0 + tw + 22
                d.text((hx, ho_y + tag_h / 2), s["homo"], font=fho, fill=(122, 70, 28, 255), anchor="lm")
                ho_bb = d.textbbox((hx, ho_y + tag_h / 2), s["homo"], font=fho, anchor="lm")
                # 谐音标签顶必须在越南语底 + 间隙之下
                if ho_y < vn_bb[3] + HOMO_GAP - 0.5:
                    overlaps.append((s["vn"], vn_bb[3], ho_y))
                if ho_bb[1] < vn_bb[3]:
                    overlaps.append((s["vn"], "glyph", vn_bb, ho_bb))
        if ri < len(rows) - 1:
            ly = y + rh
            d.line((pad, ly, cw - 16 - pad, ly), fill=(220, 200, 170, 180), width=1)
        y += rh
    if overlaps:
        raise RuntimeError(f"vocab overlap: {overlaps}")
    return L


def _collage_slots(n, box):
    """在 box=(x0,y0,x1,y1) 里返回 [(cx,cy,d,ring,z), ...]，cx/cy 为圆心。z 小先画。"""
    x0, y0, x1, y1 = box
    bw, bh = x1 - x0, y1 - y0
    # 以宽 1000、高 700 的参考布局，再按实际框缩放平移
    ref_w, ref_h = 1000.0, 700.0

    def R(cx, cy, d, ring, z):
        return (cx, cy, d, ring, z)

    if n <= 0:
        raw = []
    elif n == 1:
        raw = [R(500, 360, 560, RING_ORANGE, 1)]
    elif n == 2:
        raw = [
            R(350, 360, 440, RING_ORANGE, 1),
            R(680, 360, 420, RING_GOLD, 2),
        ]
    elif n == 3:
        raw = [
            R(680, 360, 500, RING_ORANGE, 1),
            R(280, 250, 320, RING_GOLD, 2),
            R(260, 500, 280, RING_BLUES[0], 3),
        ]
    elif n == 4:
        raw = [
            R(700, 370, 500, RING_ORANGE, 1),
            R(300, 240, 320, RING_GOLD, 2),
            R(240, 500, 270, RING_BLUES[0], 3),
            R(500, 520, 250, RING_BLUES[1], 4),
        ]
    elif n == 5:
        raw = [
            R(700, 380, 500, RING_ORANGE, 1),
            R(300, 250, 330, RING_GOLD, 2),
            R(200, 520, 260, RING_BLUES[0], 3),
            R(480, 530, 240, RING_BLUES[1], 4),
            R(920, 220, 230, RING_BLUES[2], 0),
        ]
    elif n == 6:
        raw = [
            R(640, 430, 560, RING_ORANGE, 2),   # hero
            R(270, 320, 390, RING_GOLD, 1),     # hero2
            R(150, 620, 280, RING_BLUES[0], 3),
            R(460, 650, 270, RING_BLUES[1], 4),
            R(930, 250, 260, RING_BLUES[2], 0),
            R(940, 620, 260, RING_BLUES[3], 3),
        ]
    elif n == 7:
        raw = [
            R(650, 390, 460, RING_ORANGE, 2),
            R(300, 250, 310, RING_GOLD, 1),
            R(170, 500, 230, RING_BLUES[0], 3),
            R(430, 540, 220, RING_BLUES[1], 4),
            R(900, 200, 210, RING_BLUES[2], 0),
            R(920, 500, 210, RING_BLUES[3], 3),
            R(720, 140, 200, RING_BLUES[4], 0),
        ]
    else:
        # 8+：两大 + 其余环绕
        raw = [
            R(640, 400, 430, RING_ORANGE, 2),
            R(300, 260, 300, RING_GOLD, 1),
            R(160, 500, 210, RING_BLUES[0], 3),
            R(420, 540, 200, RING_BLUES[1], 4),
            R(900, 200, 200, RING_BLUES[2], 0),
            R(920, 500, 200, RING_BLUES[3], 3),
            R(700, 140, 190, RING_BLUES[4], 0),
            R(120, 220, 190, RING_BLUES[0], 0),
        ]
        # extra around if needed
        extras = [
            R(520, 140, 180, RING_BLUES[1], 0),
            R(800, 560, 180, RING_BLUES[2], 3),
        ]
        raw = raw + extras
        raw = raw[:n]

    # 缩放到 box，并保证圆不越界（留 8px）
    xs = [c[0] - c[2] / 2 for c in raw] + [c[0] + c[2] / 2 for c in raw]
    ys = [c[1] - c[2] / 2 for c in raw] + [c[1] + c[2] / 2 for c in raw]
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    rw, rh = max(maxx - minx, 1), max(maxy - miny, 1)
    pad = 8
    scale = min((bw - 2 * pad) / rw, (bh - 2 * pad) / rh)
    # 水平居中，垂直靠下，让脸部拼贴填满单词卡下方的安全区
    ox = x0 + pad + (bw - 2 * pad - rw * scale) / 2 - minx * scale
    oy = y1 - pad - maxy * scale
    out = []
    for cx, cy, d, ring, z in raw:
        out.append((ox + cx * scale, oy + cy * scale, d * scale, ring, z))
    return out


def _paste_avatar(im, img, circle, box_origin=None):
    """把 pop_avatar 画布贴到圆心 (cx,cy)。img 伴随 (cx_local, cy_local, r)。"""
    layer, (lcx, lcy, r) = img
    cx, cy, d = circle
    x = int(round(cx - lcx))
    y = int(round(cy - lcy))
    im.alpha_composite(layer, (x, y))
    return im


def render_stage_recap(cfg):
    """绘制整页。cfg: title_parts, subtitle, episode_code, episode, words, cast。"""
    im = paint_stage()
    parts = cfg.get("title_parts") or cfg.get("parts") or ["越南语", "趣味大剧场"]
    if isinstance(parts, str):
        parts = ["越南语", parts.replace("越南语", "", 1)] if parts.startswith("越南语") else [parts, ""]
    left = (parts[0] if parts else "越南语") or "越南语"
    right = "".join(parts[1:]) if len(parts) > 1 else "趣味大剧场"
    if not right:
        right = "趣味大剧场"
    slogan = cfg.get("subtitle") or "每天一分钟学习越南语"
    code = (cfg.get("episode_code") or "").strip()
    ep = cfg.get("episode")
    if code and not re.match(r"^EP\d+$", code, re.I):
        badge = code
    elif ep is not None:
        try:
            badge = f"第{int(ep):02d}集"
        except (TypeError, ValueError):
            badge = code or ""
    else:
        badge = code or ""

    y = SAFE_TOP + 18
    y = _draw_title(im, left, right, slogan, badge, y)
    y += 10

    words = cfg.get("words") or []
    # normalize
    norm = []
    for w in words:
        if isinstance(w, (list, tuple)):
            vn, zh = (w[0] if len(w) > 0 else ""), (w[1] if len(w) > 1 else "")
            ho = w[2] if len(w) > 2 else ""
            norm.append(dict(word=vn, meaning=zh, homophone=ho))
        else:
            norm.append(w)
    card = _vocab_card(norm, max_w=960)
    if card:
        cx = (W - card.width) // 2
        im.alpha_composite(card, (cx, int(y)))
        card_bottom = int(y) + card.height - 4
    else:
        card_bottom = int(y)

    cast = list(cfg.get("cast") or [])
    # ensure emotions assigned
    if cast and not all(c.get("emotion") for c in cast):
        cast = assign_emotions(cast)

    collage_top = card_bottom + 4
    collage_bot = SAFE_BOT - 8
    if collage_bot - collage_top < 280 and cast:
        # 极端情况：把拼贴稍微侵入卡片下沿之后（仍在安全区内）
        collage_top = min(collage_top, SAFE_BOT - 320)

    if cast and collage_bot > collage_top + 80:
        slots = _collage_slots(len(cast), (20, collage_top, W - 20, collage_bot))
        # 按 z 从小到大画（背景先）
        order = sorted(range(len(cast)), key=lambda i: slots[i][4] if i < len(slots) else 99)
        for i in order:
            person = cast[i]
            cx, cy, d, ring, z = slots[i]
            folder = person.get("folder") or person.get("name")
            emo = person.get("emotion") or "震惊"
            av, local = pop_avatar(folder, emo, int(round(d)), ring, pop=True)
            _paste_avatar(im, (av, local), (cx, cy, d))

    return im.convert("RGB")


def cfg_from_state(state):
    """供 chat_final.endcard 调用。"""
    ep = {}
    if callable(getattr(state.get("_episode"), "__call__", None)):
        pass
    mix = state.get("mix") or {}
    episode = state.get("episode") or {}
    parts = episode.get("title_parts") or mix.get("banner_title") or ["越南语", "趣味大剧场"]
    words = []
    recap = state.get("words") or []
    if recap:
        for w in recap:
            words.append(dict(
                word=w.get("word") or "",
                meaning=w.get("meaning") or "",
                homophone=(w.get("homophone") or w.get("谐音") or "").strip(),
            ))
    else:
        for vn, zh in state.get("board") or []:
            words.append(dict(word=vn, meaning=zh, homophone=""))
    cast = collect_cast_from_shots(state.get("shots") or [], state.get("chars") or {})
    return dict(
        title_parts=parts,
        subtitle=episode.get("subtitle") or mix.get("banner_subtitle") or "每天一分钟学习越南语",
        episode_code=(episode.get("episode_code") or mix.get("episode_code") or "").strip(),
        episode=episode.get("number") or mix.get("episode"),
        words=words,
        cast=cast,
    )
