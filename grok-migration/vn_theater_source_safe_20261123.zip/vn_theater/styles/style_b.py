"""风格B：夜间霓虹综艺风"""
from .common import draw_frame as _df
THEME = dict(name="b", wall=[(30,20,60),(10,10,30)], window=(60,40,120), frame=(0,229,255),
  board_frame=(255,0,170), board=(15,15,35), board_head=(0,229,255), board_text=(255,255,255),
  table=[(40,30,80),(70,50,130),(110,80,180)], seat_label=(220,220,255), card_fill=(20,16,45), card_radius=20, card_text=(255,255,255),
  title_bg=(255,0,170,235), accent=(0,229,255), title_text=(255,255,255), sub_bg=(10,0,30,200), sub_text=(255,255,255),
  sub_stroke=(80,0,120), vn=(0,255,200), cap_bg=(0,200,255), cap_text=(255,255,255), cap_stroke=(0,40,120), zoom=0.14)
def draw_frame(state): return _df(state, THEME)
