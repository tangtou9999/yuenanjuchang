import unittest
from PIL import Image
from styles.chat_final import (
    GROUP_NAME, BRAND_IMAGE, _shot_homophones, _homophone,
    word_phase, avatar, _board_metrics, banner_layer, chrome
)
from import_voiceapp import extract_group, write_mix
import tempfile, json, os

class RedesignTests(unittest.TestCase):
    def test_exact_group_name(self):
        self.assertEqual(GROUP_NAME, '越南语学习交流群')
        self.assertEqual(extract_group({'global_scene':'手机竖屏《肖雨晴的越南语学习群(15)》'}),'越南语学习交流群')
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d,'mix.json')
            write_mix(p, {'episode_code':'EP05'}, [], '肖雨晴的越南语学习群(15)', 5, None)
            with open(p,encoding='utf8') as fp:
                data=json.load(fp)
            self.assertEqual(data['group'],'越南语学习交流群')

    def test_pronunciation_not_translation(self):
        st={'words':[{'word':'giao hàng','meaning':'送货', 'homophone':'绕行'},
                     {'word':'đẹp quá','meaning':'太漂亮','homophone':''}]}
        m=_shot_homophones(st)
        self.assertEqual(_homophone('giao hàng',m),'绕行')
        self.assertEqual(_homophone('đẹp quá',m),'')
        self.assertNotIn('太漂亮',m.values())

    def test_avatar_actual_face_growth(self):
        c={'name':'坦克','color':(70,100,170),'avatar':'坦'}
        small=avatar(c,pulse=0,emotion='震惊')
        big=avatar(c,pulse=1,emotion='震惊')
        self.assertEqual(small.size,big.size)  # fixed layout box
        center=small.width//2
        self.assertNotEqual(small.tobytes(),big.tobytes()) # actual face zoom

    def test_board_animation_has_three_stages(self):
        w={'t':3,'dur':0.60,'fly':1.15}
        self.assertEqual(word_phase(w,3.1)[0],'card')
        self.assertEqual(word_phase(w,3.9)[0],'fly')
        self.assertEqual(word_phase(w,4.9)[0],'landed')

    def test_banner_is_actual_asset(self):
        self.assertTrue(os.path.isfile(BRAND_IMAGE))
        img=banner_layer({'episode':{'episode_code':'EP05'}})
        self.assertEqual(img.size,(1080,280))

if __name__ == '__main__':
    unittest.main()
