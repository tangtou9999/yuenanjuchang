"""聊天风格C：笔记本横线纸，手绘感圆角气泡 + 彩色名字标签；越南语黄色荧光笔 + 下方中文小注"""
import random
from PIL import Image, ImageDraw
from .chat_common import *
TOP, BOTTOM = 250, 1840
FN = F(48, False); LH = 66; GH = 34; GF = F(26); MAXW = 820

def _paper():
    im = Image.new("RGBA", (W, H), (252, 249, 238)); d = ImageDraw.Draw(im)
    for y in range(260, H, 66): d.line([(0, y), (W, y)], fill=(190, 215, 235), width=2)
    d.line([(90, 0), (90, H)], fill=(240, 150, 150), width=3)
    for y in range(120, H, 180): d.ellipse([22, y, 54, y+32], fill=(225, 220, 205))
    return im
_P = None

def _measure(st):
    def m(it, idx):
        if it["kind"] == "cap": return 130
        lines = wrap(it["shot"]["line"], FN, MAXW); return 60 + line_h(lines, LH, GH) + 44
    return m

def _wobble(d, box, col, outline, seed):
    rnd = random.Random(seed); x0, y0, x1, y1 = box
    d.rounded_rectangle([x0+3, y0+5, x1+3, y1+5], 34, fill=(0, 0, 0, 25))
    d.rounded_rectangle(box, 34, fill=col)
    for j in range(2):
        o = [rnd.randint(-3, 3) for _ in range(4)]
        d.rounded_rectangle([x0+o[0], y0+o[1], x1+o[2], y1+o[3]], 36, outline=outline, width=3)

def _layer(st, it, h):
    s = it["shot"]; c = st["chars"][s["name"]]; L = Image.new("RGBA", (W, h)); d = ImageDraw.Draw(L)
    lines = wrap(s["line"], FN, MAXW); bw = max(tw("".join(t for t, _ in ln), FN) for ln in lines) + 60
    x0 = 120; d.ellipse([x0, 0, x0+56, 56], fill=c["color"], outline=(60, 60, 60), width=3)
    d.text((x0+28, 28), c["avatar"], font=F(30), fill="white", anchor="mm")
    tag = f"{s['name']}"; tw_ = tw(tag, F(30)) + 36
    d.rounded_rectangle([x0+68, 6, x0+68+tw_, 52], 23, fill=c["color"]); d.text((x0+86, 29), tag, font=F(30), fill="white", anchor="lm")
    d.text((x0+82+tw_, 29), c["role"], font=F(24, False), fill=(140, 130, 110), anchor="lm")
    bh = line_h(lines, LH, GH) + 30
    _wobble(d, [x0, 64, x0+bw, 64+bh], (255, 255, 255, 235), tuple(int(v*0.8) for v in c["color"]), s["n"])
    draw_rich(d, x0+30, 76, lines, FN, LH, (50, 50, 60), (40, 40, 40), hl=(255, 232, 80), gloss_font=GF, gloss_col=(200, 90, 40), gloss_h=GH)
    return L

def _cap(it):
    L = Image.new("RGBA", (W, 130)); d = ImageDraw.Draw(L); f = F(56); t = f"★ 划重点  {it['text']}"; w = tw(t, f) + 100
    x0 = (W - w)//2; d.polygon([(x0, 14), (x0+w, 8), (x0+w-6, 118), (x0+6, 124)], fill=(255, 226, 120), outline=(200, 140, 30))
    d.rectangle([W//2-60, 0, W//2+60, 26], fill=(200, 220, 240, 200))  # 胶带
    d.text((W//2, 68), t, font=f, fill=(120, 60, 0), anchor="mm"); return L

def draw_frame(state):
    global _P
    if _P is None: _P = _paper()
    im = _P.copy()
    for it, y, h, k in layout_stack(visible(state), state["t"], _measure(state), BOTTOM, TOP, 28):
        pop(im, _cap(it) if it["kind"] == "cap" else _layer(state, it, h), (0, y), k, "center" if it["kind"] == "cap" else "left")
    d = ImageDraw.Draw(im); d.rectangle([0, 0, W, 230], fill=(252, 249, 238)); d.line([(0, 232), (W, 232)], fill=(90, 150, 130), width=4)
    tt = state["title"].split("：", 1)
    d.text((W//2, 70), tt[0], font=F(44), fill=(90, 150, 130), anchor="mm")
    if len(tt) > 1:
        f = F(38); 
        while tw(tt[1], f) > W-80: f = F(f.size-2)
        d.text((W//2, 150), tt[1], font=f, fill=(60, 60, 70), anchor="mm")
    return im.convert("RGB")
