#!/usr/bin/env python3
"""从脚本的音效清单自动生成画面特效表 <script>.effects.json（可手动改）。
音效清单的秒数和台词对不上，所以按描述内容匹配到对应台词，时间取该句开头（可用音频响度峰值微调）。"""
import sys, re, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render import parse

RULES = [
    ("乌鸦|尴尬", "crow", 3.0),
    ("叮咚|知识点", "sparkle", 1.5),
    (r"叮(?!咚)|铃声|铃铛", "ding", 1.2),
    ("拍桌|拍案", "shake", 0.6),
    ("笑|起哄", "laugh", 2.2),
    ("撞击|摔|碰", "impact", 0.6),
    (r"嗖|飘过|whoosh|呼啸", "whoosh", 0.8),
]

def bigrams(s): s = re.sub(r"[^\u4e00-\u9fff]", "", s); return {s[i:i+2] for i in range(len(s)-1)}

def main(script, out=None, align=None):
    txt = open(script, encoding="utf-8").read(); title, shots = parse(script)
    blocks = dict((int(n), b) for n, b in re.findall(r"### 【镜头 #(\d+)】(.*?)(?=### 【镜头|\Z)", txt, re.S))
    rms = json.load(open(align))["rms"] if align and os.path.exists(align) else None
    names = {s["name"] for s in shots}; fx = []
    sfx_all = [float(x) for x in re.findall(r"\d+\. 【第 ([\d.]+) 秒", txt)]
    scale = shots[-1]["t0"] / max(max(sfx_all), 1)  # 清单时间轴被压缩了，按比例估一个先验位置
    last_n = 0
    for m in re.finditer(r"\d+\. 【第 ([\d.]+) 秒[^】]*】 ➔ 动作/音效：([^|]+)", txt):
        tsfx, desc = float(m.group(1)), m.group(2).strip()
        best, bs = None, -1
        for s in shots:
            if s["n"] < last_n: continue
            hay = blocks.get(s["n"], "") ; sc = 0
            sc += sum(3 for nm in names if nm in desc and nm == s["name"])
            sc += sum(2 for v in re.findall(r"[a-zA-Zà-ỹđĐ][a-zà-ỹđ ]*[a-zà-ỹđ]", desc) if v.strip() in s["line"])
            sc += len(bigrams(desc) & bigrams(hay))
            sc += sum(5 for c in s["caps"] if c.split("=")[0].strip() and c.split("=")[0].strip() in desc)
            sc -= abs(tsfx * scale - s["t0"]) / 8
            if sc > bs: best, bs = s, sc
        if "开场" in desc: continue
        last_n = best["n"]; t = best["t0"]
        if rms:  # 在句首 ±0.6s 内找响度最大的点作为冲击点
            a, b = int(max(t - 0.6, 0) * 30), int((t + 0.6) * 30); seg = rms[a:b]
            if seg: t = round((a + seg.index(max(seg))) / 30, 2)
        types = [ty for kw, ty, d in RULES if re.search(kw, desc)] or ["sparkle"]
        if "sparkle" in types and "ding" in types:  # 叮咚 已由 sparkle 覆盖，避免叠两次叮
            types = [ty for ty in types if ty != "ding"]
        if "crow" in types and "whoosh" in types:  # 乌鸦飞过 不必再加 whoosh
            types = [ty for ty in types if ty != "whoosh"]
        if "开场" in desc: continue
        for ty in types:
            fx.append(dict(type=ty, t=t, dur=dict((r[1], r[2]) for r in RULES)[ty], shot=best["n"], desc=desc, script_sfx_time=tsfx))
    fx.sort(key=lambda e: e["t"])
    out = out or os.path.splitext(script)[0] + ".effects.json"
    json.dump(dict(_说明="type: shake/laugh/crow/sparkle/ding/impact/whoosh；t=开始秒，dur=持续秒；可随意增删改", effects=fx), open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for e in fx: print(f"{e['t']:7.2f}s  #{e['shot']:<2} {e['type']:<8} ← {e['desc']} (清单写 {e['script_sfx_time']}s)")
    print("写入", out)

if __name__ == "__main__":
    a = sys.argv[1:]; main(a[0], align=os.path.splitext(a[0])[0] + ".align.json")
