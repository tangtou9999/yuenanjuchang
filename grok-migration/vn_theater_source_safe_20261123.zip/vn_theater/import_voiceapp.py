#!/usr/bin/env python3
"""把语音 App 导出的 EP 渲染 JSON + 人声音频，转成 render.py / chat_final 所需的脚本、mix、特效表和对齐结果。

用法:
  .venv/bin/python import_voiceapp.py incoming/EP04_render.json incoming/EP04_audio.mp3 \\
      --outdir /workspace/ep04_sample --add-characters --align

以后每一集从语音 App 下来，都是同一套字段：
  project_title, global_scene,
  sfx_spotting_list_seconds: [{sec, action, search}],
  millisecond_timeline: [{shot_index, start_ms, end_ms, speaker, voice_id,
                          camera_instruction, character_action, emotion_tone, dialogue_text, ...}]

本工具会：
  - 写成 ### 【镜头 #N】 格式的脚本（台词保持原文，一字不改）
  - 用 start_ms/end_ms 作为镜头主时间；若提供 --align，会用 whisper 核对并在整体漂移时平移
  - 把过长的一句按标点拆成多条气泡，时间戳来自对齐结果
  - 写出 <stem>_script.mix.json（标题、群名、黑板单词）和 <stem>_script.effects.json
  - 谐音只收录用户文案里已经写明的（「谐音：姓赵」「姓赵（Xin chào）」这类），绝不自动编
"""
from __future__ import annotations

import argparse, json, os, re, shutil, sys, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

SPEAKER_RE = re.compile(
    r"^(?:(\d+)[·.•])?\s*([^\s(（]+?)\s*(?:[(（]([^)）]+)[)）])?\s*$"
)

# 语音 App 的 action 描述 → 本仓库 CC0 音效类型。没有锣，敲锣用 impact 代替。
SFX_RULES = [
    (r"乌鸦", "crow"),
    (r"拍桌|拍案|拍桌子|喷茶", "shake"),
    (r"哄堂|爆笑|哈哈|狂笑|大笑|起哄|刷屏爆笑", "laugh"),
    (r"敲锣|锣|急眼敲", "impact"),          # 库里没有锣，用撞击代替
    (r"叮咚|知识点|单词卡", "ding"),
    (r"气泡|啵声|消息声|弹出啵", "pop"),      # 只有声音，没有「哈哈哈」画面
    (r"撞击|摔|碰", "impact"),
    (r"嗖|whoosh|呼啸", "whoosh"),
]

# 中文里更像「意思」而不是「谐音玩笑」的词，用于 Chinese（Vietnamese）归类
MEANING_ZH = {
    "你好", "您好", "谢谢", "再见", "没关系", "走", "去", "走吧", "傻瓜",
    "打招呼", "问候", "感谢", "告辞",
}

NEW_CHAR_COLORS = {
    "苏姐": "#16A085",
    "老刘": "#2980B9",
    "贾总": "#8B5A2B",
    "辛迪": "#2C3E50",
    "肖老师": "#E74C8B",
}


def fmt_ts(sec: float) -> str:
    sec = max(0.0, float(sec))
    m = int(sec // 60)
    s = sec - 60 * m
    return f"{m:02d}:{s:06.3f}"


def parse_speaker(raw: str):
    """拆出编号、姓名、角色说明。没有编号时 num 为 None，不再默认成 01（避免和 15 人表冲突）。"""
    raw = (raw or "").strip()
    m = SPEAKER_RE.match(raw)
    if not m:
        return None, raw or "", "群成员"
    num = m.group(1)
    if num:
        num = f"{int(num):02d}"
    name = (m.group(2) or "").strip()
    role = (m.group(3) or "群成员").strip() or "群成员"
    return num, name, role


def load_roster(path: str | None = None) -> dict:
    path = path or os.path.join(HERE, "roster15.json")
    data = json.load(open(path, encoding="utf-8"))
    people = list(data.get("roster") or [])
    by_id, by_label = {}, {}
    for p in people:
        pid = f"{int(p['id']):02d}"
        p = dict(p, id=pid, aliases=list(p.get("aliases") or []))
        if pid in by_id:
            raise ValueError(f"roster15.json 编号重复: {pid}")
        by_id[pid] = p
        labels = [p["name"], *p["aliases"]]
        for lab in labels:
            if not lab:
                continue
            if lab in by_label and by_label[lab]["id"] != pid:
                raise ValueError(f"roster15.json 姓名/别名冲突: {lab}")
            by_label[lab] = p
    return {"path": os.path.abspath(path), "people": people, "by_id": by_id, "by_label": by_label}


def format_person(p: dict) -> str:
    return f"{p['id']}·{p['name']}"


def resolve_speaker(raw: str, roster: dict, role_fallback: str = "群成员"):
    """按 15 人表把说话人解析成官方编号+规范名。冲突或名单外姓名返回错误，绝不猜测替换。

    返回 (result, error)。成功时 result 为
      {id, name, role, raw, alias_used, avatar_folder, color}
    失败时 error 为给人看的说明。
    """
    raw_s = (raw or "").strip()
    if not raw_s:
        return None, "说话人为空，无法对照 15 人名单。"
    num, name, role = parse_speaker(raw_s)
    if not role or role == "群成员":
        role = role_fallback or "群成员"
    by_id = roster["by_id"]
    by_label = roster["by_label"]
    id_entry = by_id.get(num) if num else None
    name_entry = by_label.get(name) if name else None

    if name and not name_entry:
        hint = f"，同时编号 {num} 在 15 人表中是「{format_person(id_entry)}」" if id_entry else ""
        return None, (
            f"姓名「{name}」不在最新 15 人名单中（亦非已登记别名）{hint}。"
            f"拒绝猜测替换。原文：「{raw_s}」。"
        )
    if num and not id_entry:
        hint = f"；姓名「{name}」在表中是 {format_person(name_entry)}" if name_entry else ""
        return None, (
            f"编号 {num} 不是最新 15 人名单中的 01–15{hint}。"
            f"拒绝按旧 12 人编号解释。原文：「{raw_s}」。"
        )
    if id_entry and name_entry and id_entry["id"] != name_entry["id"]:
        return None, (
            f"编号与姓名不一致：原文「{raw_s}」，但 15 人表中编号 {id_entry['id']} 是「{id_entry['name']}」，"
            f"「{name}」对应 {format_person(name_entry)}。拒绝猜测，请改 JSON 后再导入。"
        )
    person = name_entry or id_entry
    if not person:
        return None, f"无法解析说话人「{raw_s}」。请写成「13·肖雨晴」或名单中的姓名/别名（如 肖老师）。"
    alias_used = bool(name and name != person["name"] and name in (person.get("aliases") or []))
    # 仅有编号、没有姓名时，按名单补全规范名（这是查表，不是换人）
    return {
        "id": person["id"],
        "name": person["name"],
        "role": role or "群成员",
        "raw": raw_s,
        "alias_used": name if alias_used else "",
        "avatar_folder": person.get("avatar_folder") or person["name"],
        "color": person.get("color") or "",
        "id_only": bool(num and not name),
    }, None



# 九宫格官方顺序（与头像文件 01–09 一一对应；文件名用近义：微笑→普通微笑、疑惑→懵、尴尬→害羞、翻白眼→无语）
EXPRESSION_ORDER = [
    ("01", "微笑"), ("02", "大笑"), ("03", "坏笑"), ("04", "疑惑"), ("05", "震惊"),
    ("06", "生气"), ("07", "尴尬"), ("08", "翻白眼"), ("09", "委屈"),
]
EXPRESSION_FILE = {
    "微笑": "普通微笑", "普通微笑": "普通微笑",
    "大笑": "大笑", "坏笑": "坏笑",
    "疑惑": "懵", "懵": "懵",
    "震惊": "震惊", "惊讶": "震惊", "吃惊": "震惊",
    "生气": "生气",
    "尴尬": "害羞", "害羞": "害羞",
    "翻白眼": "无语", "无语": "无语",
    "委屈": "委屈",
}


def _pad2(val):
    if val is None or val == "":
        return None
    s = str(val).strip()
    m = re.match(r"^(\d+)$", s)
    if not m:
        # "05震惊" / "05:震惊"
        m = re.match(r"^(\d{1,2})", s)
        if not m:
            return None
    n = int(m.group(1))
    if 1 <= n <= 9:
        return f"{n:02d}"
    return None


def expression_table(data: dict | None = None) -> dict:
    """id → 官方标签。优先用 JSON 的 expression_map_order，否则用默认 15 人九宫格顺序。"""
    table = {i: lab for i, lab in EXPRESSION_ORDER}
    raw = (data or {}).get("expression_map_order") if data else None
    if raw:
        for item in raw:
            if isinstance(item, str):
                m = re.match(r"^\s*(\d{1,2})\s*[:：]\s*(.+?)\s*$", item)
                if m:
                    table[f"{int(m.group(1)):02d}"] = m.group(2).strip()
            elif isinstance(item, dict):
                eid = _pad2(item.get("id") or item.get("expression_id"))
                lab = (item.get("label") or item.get("name") or "").strip()
                if eid and lab:
                    table[eid] = lab
    return table


def resolve_expression(shot: dict, data: dict | None, notes: list[str] | None = None):
    """对照官方九宫格选表情。编号与标签不一致时，信任能对上九宫格的标签并记下，不猜。"""
    table = expression_table(data)
    label_to_id = {}
    for eid, lab in table.items():
        label_to_id[lab] = eid
        # 文件近义也可反查
        for k, v in EXPRESSION_FILE.items():
            if v == EXPRESSION_FILE.get(lab, lab) or k == lab:
                label_to_id.setdefault(k, eid)
    eid = _pad2(shot.get("expression_id") or shot.get("expressionId"))
    label = (shot.get("expression_label") or shot.get("expression") or "").strip()
    n = shot.get("shot_index") or "?"
    chosen_id, chosen_label, note = None, None, ""
    if label and label in label_to_id:
        chosen_id = label_to_id[label]
        chosen_label = table[chosen_id]
        if eid and eid != chosen_id:
            note = (
                f"镜头 #{n}: 表情编号 {eid} 对应「{table.get(eid, '?')}」，"
                f"但标签是「{label}」（={chosen_id}{chosen_label}）。已按标签选用，未按编号。"
            )
    elif eid and eid in table:
        chosen_id, chosen_label = eid, table[eid]
        if label and label != chosen_label:
            note = (
                f"镜头 #{n}: 表情标签「{label}」无法对照九宫格，已按编号 {eid}「{chosen_label}」选用。"
            )
    else:
        if label or eid:
            note = f"镜头 #{n}: 无法解析表情 expression_id={eid!s} label={label!r}，将回退默认表情。"
        return None, None, note
    if note and notes is not None:
        notes.append(note)
    return chosen_id, chosen_label, note


def resolve_shot_speaker(shot: dict, roster: dict):
    """15-cast-v1.x：优先 character_id + character_name，再与 speaker 字段交叉核对。"""
    cid = shot.get("character_id") or shot.get("characterId")
    cname = (shot.get("character_name") or shot.get("characterName") or "").strip()
    speaker = (shot.get("speaker") or "").strip()
    role_fb = (shot.get("gender") or "群成员").strip() or "群成员"
    rec, err = None, None
    raw = ""
    if cid or cname:
        cid_n = _pad2(cid) if cid not in (None, "") else None
        if cid_n and cname:
            raw = f"{cid_n}·{cname}"
        elif cname:
            raw = cname
        elif cid_n:
            raw = cid_n
        rec, err = resolve_speaker(raw, roster, role_fallback=role_fb)
        if err:
            return rec, err
        if speaker:
            rec2, err2 = resolve_speaker(speaker, roster, role_fallback=role_fb)
            if rec2 and rec2["id"] != rec["id"]:
                return None, (
                    f"character_id/name 解析为 {rec['id']}·{rec['name']}，"
                    f"但 speaker「{speaker}」解析为 {rec2['id']}·{rec2['name']}。拒绝猜测。"
                )
        return rec, None
    return resolve_speaker(speaker, roster, role_fallback=role_fb)


def seat_for(i: int, n: int):
    """没有教室坐标时，按出场顺序给一个稳定的占位坐标（chat_final 不用座位，只为通过 parse）。"""
    if n <= 1:
        return 0.0, 0.05
    x = -0.8 + 1.6 * (i / max(n - 1, 1))
    y = 0.05 + 0.08 * (i % 3)
    return round(x, 2), round(y, 2)


def map_sfx_action(action: str) -> list[str]:
    types = []
    for pat, typ in SFX_RULES:
        if re.search(pat, action or ""):
            if typ not in types:
                types.append(typ)
    return types


def collect_text(data: dict) -> str:
    parts = [data.get("project_title") or "", data.get("global_scene") or ""]
    for s in data.get("millisecond_timeline") or []:
        for k in ("dialogue_text", "camera_instruction", "character_action",
                  "emotion_tone", "visual_render_prompt"):
            v = s.get(k)
            if v:
                parts.append(str(v))
    for e in data.get("sfx_spotting_list_seconds") or []:
        parts.append(str(e.get("action") or ""))
    for v in data.get("vocab_summary") or []:
        if isinstance(v, dict):
            parts.append(" ".join(str(v.get(k) or "") for k in ("vi", "zh", "hook", "homophone", "谐音")))
    return "\n".join(parts)


def _upsert_word(store: dict, vn: str, meaning: str = "", homo: str = ""):
    vn = re.sub(r"\s+", " ", (vn or "").strip())
    if not vn or not re.search(r"[A-Za-zÀ-ỹĐđ]", vn):
        return
    key = vn.lower()
    item = store.setdefault(key, {"word": vn, "meaning": "", "homophone": ""})
    # 保留更「标准」的大小写（有声调/原样优先）
    if any(ch in vn for ch in "àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀ-Ỹ"):
        item["word"] = vn
    meaning, homo = (meaning or "").strip(), (homo or "").strip()
    if meaning and not item["meaning"]:
        item["meaning"] = meaning.split("、")[0].split("，")[0]
    if homo and not item["homophone"]:
        # 去掉「不是」这类否定
        homo = re.sub(r"^不是", "", homo).strip()
        if homo:
            item["homophone"] = homo


def _homophone_from_hook(hook: str) -> str:
    """只把 JSON 里已写明的「谐音：… / 汉越词：…」当作谐音，不把使用说明当成谐音，也不自动编。"""
    hook = (hook or "").strip()
    if not hook:
        return ""
    m = re.match(r"^(?:谐音|汉越词)\s*[：:]\s*(.+)$", hook)
    return (m.group(1).strip() if m else "")


def extract_words_from_text(data: dict) -> dict:
    """只从用户原文里收单词。不编谐音。返回 key=小写越南语。"""
    text = collect_text(data)
    store = {}

    # 1) Xin chào = 你好（谐音：姓赵）
    for m in re.finditer(
        r"([A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ'’\s]*?)\s*[=＝]\s*"
        r"([\u4e00-\u9fff]+(?:[、，][\u4e00-\u9fff]+)*)"
        r"(?:\s*[（(]谐音[：:]\s*([^)）]+)[)）])?",
        text,
    ):
        _upsert_word(store, m.group(1), m.group(2), m.group(3) or "")

    # 2) 你好是 Xin chào（不是姓赵）/ 谢谢是 Cảm ơn（不是干嘛）
    for m in re.finditer(
        r"([\u4e00-\u9fff]{1,8})\s*是\s*"
        r"([A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ'’\s]*?)"
        r"\s*[（(]\s*(?:不是)?\s*([^)）]+)[)）]",
        text,
    ):
        zh, vn, maybe = m.group(1), m.group(2), m.group(3)
        _upsert_word(store, vn, zh, maybe)

    # 3) 谐音：姓赵  紧挨在越南语附近时（【Xin chào = 你好（谐音：姓赵）】已由 1 覆盖）
    #    单独「谐音空勺」跟 Không sao 在同一句
    for m in re.finditer(
        r"([A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ'’\s]{0,24}?)\s*(?:叫|是)?\s*"
        r"(?:，|,|……|\.{2,})?\s*谐音\s*[：:]?\s*([\u4e00-\u9fff]{1,8})",
        text,
    ):
        _upsert_word(store, m.group(1), "", m.group(2))

    # 4) Chinese（Vietnamese）：姓赵（Xin chào）/ 干嘛（Cảm ơn）/ Cảm ơn（谢谢）
    for m in re.finditer(
        r"([\u4e00-\u9fff]{1,8})\s*[（(]\s*"
        r"([A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ'’\s]*?)\s*[)）]",
        text,
    ):
        zh, vn = m.group(1).strip(), m.group(2).strip()
        if zh in MEANING_ZH:
            _upsert_word(store, vn, zh, "")
        else:
            # 默认当作用户自己写的谐音（姓赵、干嘛、大便、空勺）
            _upsert_word(store, vn, "", zh)

    # 稳定顺序：按在全文首次出现的越南语
    text_l = text.lower()
    words = list(store.values())
    words.sort(key=lambda w: (text_l.find(w["word"].lower()) if w["word"].lower() in text_l else 10**9))
    # 没有意思也没有谐音的孤词丢掉（避免误伤）
    out = []
    for w in words:
        if w.get("meaning") or w.get("homophone"):
            out.append(w)
    return out


def extract_words(data: dict) -> list[dict]:
    """黑板单词：有 vocab_summary 时以它为准；谐音只采用 JSON 已写明的「谐音/汉越词」或正文里的显式写法。"""
    summary = data.get("vocab_summary") or []
    text_words = extract_words_from_text(data)
    text_by = {w["word"].lower(): w for w in text_words}
    if not summary:
        return text_words
    out = []
    seen = set()
    for item in summary:
        if not isinstance(item, dict):
            continue
        vi = item.get("vi") or item.get("word") or item.get("vn") or ""
        zh = item.get("zh") or item.get("meaning") or ""
        hook = item.get("hook") or ""
        # 谐音只采用 JSON 已写的 homophone/谐音字段；不从 hook 或正文推断，也不编造
        homo = ""
        if "homophone" in item or "谐音" in item:
            homo = (item.get("homophone") or item.get("谐音") or "").strip()
        key = re.sub(r"\s+", " ", vi.strip()).lower()
        tw = text_by.get(key)
        store = {}
        _upsert_word(store, vi, zh, homo)
        if not store:
            continue
        w = next(iter(store.values()))
        out.append(w)
        seen.add(w["word"].lower())
    return out


def extract_group(data: dict) -> str:
    scene = data.get("global_scene") or ""
    m = re.search(r"《([^》]+)》", scene)
    if m:
        return m.group(1).strip()
    return "越南语自习室"


def extract_hook(data: dict, words: list[dict]) -> str:
    title = data.get("project_title") or ""
    # 标题里「姓赵(Xin chào)」这类
    m = re.search(r"([\u4e00-\u9fff]{1,6})\s*[(（]\s*([A-Za-zÀ-ỹĐđ][^)）]+)[)）]", title)
    if m:
        return f"“{m.group(1)}”不是招呼？"
    if words:
        w = words[0]
        if w.get("homophone"):
            return f"“{w['homophone']}”不是{w.get('meaning') or w['word']}？"
        if w.get("meaning"):
            return f"{w['word']}＝{w['meaning']}"
    return title[:16] if title else ""


def split_dialogue(text: str) -> list[str]:
    """按句末标点拆成多条气泡；短碎片并回上一句。原文一字不改，只切开。"""
    text = text or ""
    if not text:
        return []
    parts = re.split(r"(?<=[！？。!?])", text)
    parts = [p for p in parts if p != ""]
    # 还原拆分后可能留下的前导空白（原文里标点后若没有空格则不会有）
    merged = []
    for p in parts:
        if merged and len(re.sub(r"\s+", "", p)) < 4:
            merged[-1] = merged[-1] + p
        elif merged and len(re.sub(r"\s+", "", merged[-1])) < 4:
            merged[-1] = merged[-1] + p
        else:
            merged.append(p)
    if not merged:
        return [text]
    # 再拼回应等于原文
    if "".join(merged) != text:
        # 保守：拆不开就整句保留
        return [text]
    return merged


def build_shots(data: dict, roster: dict) -> tuple[list[dict], list[str], list[str]]:
    timeline = list(data.get("millisecond_timeline") or [])
    timeline.sort(key=lambda s: (s.get("start_ms") is None, s.get("start_ms") or 0, s.get("shot_index") or 0))
    n = len(timeline)
    shots = []
    seen = {}
    order = []
    errors = []
    resolved = []
    expr_notes = []
    for s in timeline:
        rec, err = resolve_shot_speaker(s, roster)
        if err:
            n = s.get("shot_index") or "?"
            errors.append(f"镜头 #{n}: {err}")
            resolved.append(None)
            continue
        resolved.append(rec)
        name = rec["name"]
        if name not in seen:
            seen[name] = len(order)
            order.append(name)
    for i, s in enumerate(timeline):
        rec = resolved[i]
        t0 = (s.get("start_ms") if s.get("start_ms") is not None else int(float(s.get("start_sec") or 0) * 1000)) / 1000.0
        t1 = (s.get("end_ms") if s.get("end_ms") is not None else int(float(s.get("end_sec") or t0) * 1000)) / 1000.0
        if t1 <= t0:
            t1 = t0 + 0.4
        if rec is None:
            shots.append(dict(
                n=int(s.get("shot_index") or (i + 1)),
                t0=t0, t1=t1,
                num="??", name="（未解析）", role="",
                voice_id=s.get("voice_id") or "",
                x=0.0, y=0.05,
                line=s.get("dialogue_text") or "",
                emotion=s.get("emotion_tone") or "",
                action=s.get("character_action") or "",
                camera=s.get("camera_instruction") or "",
                src=s, resolve_error=True,
            ))
            continue
        name = rec["name"]
        x, y = seat_for(seen.get(name, i), max(len(order), 1))
        line = s.get("dialogue_text") or ""
        eid, elab, enote = resolve_expression(s, data, expr_notes)
        shots.append(dict(
            n=int(s.get("shot_index") or (i + 1)),
            t0=t0, t1=t1,
            num=rec["id"], name=name, role=rec["role"],
            voice_id=s.get("voice_id") or "",
            x=x, y=y,
            line=line,
            emotion=elab or "",
            expression_id=eid or "",
            expression=elab or "",
            tone=s.get("emotion_tone") or "",
            action=s.get("character_action") or "",
            camera=s.get("camera_instruction") or "",
            src=s,
            alias_used=rec.get("alias_used") or "",
            avatar_folder=rec.get("avatar_folder") or name,
        ))
    return shots, errors, expr_notes


def write_script(path: str, data: dict, shots: list[dict], words: list[dict], group: str):
    title = data.get("project_title") or "越南语趣味大剧场"
    scene = data.get("global_scene") or ""
    board = "，".join(
        f"{w['word']} = {w['meaning'] or w.get('homophone') or ''}".strip(" =")
        for w in words
    )
    sfx_lines = []
    for i, e in enumerate(data.get("sfx_spotting_list_seconds") or [], 1):
        sec = float(e.get("sec") or 0)
        sfx_lines.append(
            f"{i}. 【第 {sec:.1f} 秒 ({fmt_ts(sec)})】 ➔ 动作/音效：{e.get('action') or ''}  |  🔎 搜索词：「{e.get('search') or ''}」"
        )
    chunks = [
        f"# 《{title}》配音脚本（由 import_voiceapp.py 从语音 App JSON 转入，台词保持原文）",
        f"- 全局场景：{scene}" + (f"，黑板上写着今日单词：{board}" if board else ""),
        "",
        "# 音效打点清单（来自 sfx_spotting_list_seconds）",
        *sfx_lines,
        "",
        "---",
        "",
    ]
    for s in shots:
        chunks.append(f"### 【镜头 #{s['n']}】 {fmt_ts(s['t0'])} --> {fmt_ts(s['t1'])} ({int(round(s['t0']*1000))}ms - {int(round(s['t1']*1000))}ms)")
        voice = f"声纹: {s['voice_id']} | " if s.get("voice_id") else ""
        expr = ""
        if s.get("expression_id") or s.get("expression"):
            expr = f"表情:{s.get('expression_id') or ''}{s.get('expression') or ''} | "
        chunks.append(f"- **角色与声纹**：{s['num']}·{s['name']}({s['role']}) ({voice}{expr}教室坐标 X:{s['x']:.2f}, Y:{s['y']:.2f})")
        cam = s.get("camera") or "群聊气泡"
        act = s.get("action") or "发语音"
        tone = s.get("tone") or ""
        chunks.append(f"- **机位与动作**：{cam} | {act}" + (f"（语气：{tone}）" if tone else ""))
        chunks.append(f"- **台词**：「{s['line']}」")
        chunks.append("")
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(chunks).rstrip() + "\n")


def write_mix(path: str, data: dict, words: list[dict], group: str, episode: int, banner: str | None):
    hook = extract_hook(data, words)
    mix_words = []
    for w in words:
        item = {
            "word": w["word"],
            "meaning": w.get("meaning") or "",
        }
        if w.get("homophone"):
            item["homophone"] = w["homophone"]
        mix_words.append(item)
    mix = {
        "episode": episode,
        "episode_code": (data.get("episode_code") or "").strip() or None,
        "hook": hook,
        "group": group,
        "banner_title": ["越南语", "趣味大剧场"],
        "banner_subtitle": "每天一分钟学习越南语",
        "words": mix_words,
    }
    if not mix["episode_code"]:
        mix.pop("episode_code")
    if banner:
        mix["banner"] = banner
    with open(path, "w", encoding="utf-8") as f:
        json.dump(mix, f, ensure_ascii=False, indent=2)
        f.write("\n")


def write_effects(path: str, data: dict, notes: list[str]) -> list[dict]:
    fx = []
    dur_of = {"crow": 3.0, "shake": 0.6, "laugh": 2.2, "impact": 0.6,
              "ding": 1.2, "sparkle": 1.5, "pop": 0.5, "whoosh": 0.8}
    for e in data.get("sfx_spotting_list_seconds") or []:
        sec = float(e.get("sec") or 0)
        action = e.get("action") or ""
        types = map_sfx_action(action)
        if not types:
            notes.append(f"SFX @ {sec:.1f}s「{action}」没有对应库内音效，已跳过")
            continue
        if "敲锣" in action or "锣" in action:
            notes.append(f"SFX @ {sec:.1f}s 敲锣：库里没有锣，用 impact（撞击）代替")
        if "菜市场" in action or "背景音" in action:
            notes.append(f"SFX @ {sec:.1f}s「{action}」：库里没有环境背景音，只保留已映射的音效")
        for typ in types:
            fx.append(dict(type=typ, t=round(sec, 3), dur=dur_of.get(typ, 0.6),
                           desc=action, script_sfx_time=sec))
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"effects": fx}, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return fx


def write_gloss(path: str, words: list[dict]):
    g = {}
    for w in words:
        if w.get("meaning"):
            g[w["word"].lower()] = w["meaning"]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(g, f, ensure_ascii=False, indent=2)
        f.write("\n")


def add_characters(names: list[str], notes: list[str], do_write: bool):
    path = os.path.join(HERE, "characters.json")
    cfg = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {}
    added = []
    for name in names:
        if name in cfg:
            continue
        color = NEW_CHAR_COLORS.get(name)
        if not color:
            # 稳定但不碰撞的色相
            h = (sum(map(ord, name)) % 360) / 360.0
            import colorsys
            rgb = tuple(int(v * 255) for v in colorsys.hsv_to_rgb(h, 0.55, 0.82))
            color = f"#{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"
        if do_write:
            cfg[name] = {"color": color}
        added.append((name, color))
        notes.append(f"角色「{name}」不在 characters.json，{'已补' if do_write else '建议补'}色块 {color}（无头像则用色块）")
    if do_write and added:
        json.dump(cfg, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        open(path, "a", encoding="utf-8").write("\n")
    return added


def apply_offset(shots: list[dict], sfx_data: dict, offset: float):
    if abs(offset) < 0.04:
        return
    for s in shots:
        s["t0"] = max(0.0, s["t0"] + offset)
        s["t1"] = max(s["t0"] + 0.2, s["t1"] + offset)
    for e in sfx_data.get("sfx_spotting_list_seconds") or []:
        e["sec"] = max(0.0, float(e.get("sec") or 0) + offset)


def split_shots_with_align(shots: list[dict], align_lines: list[dict], notes: list[str]) -> list[dict]:
    """把过长台词按标点拆成多条镜头，时间用对齐后的字级时间。"""
    by_n = {ln["n"]: ln for ln in align_lines or []}
    out = []
    new_n = 1
    for s in shots:
        parts = split_dialogue(s["line"])
        ln = by_n.get(s["n"])
        chars = (ln or {}).get("chars") or []
        if len(parts) <= 1 or not chars or len(chars) != len(s["line"]):
            ns = dict(s, n=new_n)
            out.append(ns)
            new_n += 1
            continue
        chunks = []
        pos = 0
        ok = True
        for p in parts:
            i = s["line"].find(p, pos)
            if i < 0:
                ok = False
                break
            j = i + len(p)
            t0 = float(chars[i][1])
            t1 = float(chars[min(j, len(chars)) - 1][2])
            if t1 <= t0:
                t1 = t0 + max(0.2, 0.08 * max(len(p), 1))
            chunks.append((p, t0, t1))
            pos = j
        if not ok or not chunks:
            out.append(dict(s, n=new_n))
            new_n += 1
            continue
        notes.append(f"镜头原 #{s['n']}「{s['name']}」拆成 {len(chunks)} 条气泡")
        for k, (p, t0, t1) in enumerate(chunks):
            ns = dict(s, n=new_n, line=p, t0=t0, t1=t1)
            # 同一人连续气泡，后一条不要早于前一条
            if out and out[-1]["name"] == s["name"] and ns["t0"] < out[-1]["t1"]:
                # 允许很短的重叠；若严重倒挂则推到前一条结束
                if out[-1]["t1"] - ns["t0"] > 0.15:
                    ns["t0"] = out[-1]["t1"]
                    if ns["t1"] <= ns["t0"]:
                        ns["t1"] = ns["t0"] + 0.25
            out.append(ns)
            new_n += 1
    return out


def transcribe_audio(audio: str, notes: list[str]):
    import align as al
    try:
        pcm = al.load_pcm(audio)
        words = al.transcribe(pcm)
        notes.append(f"whisper 识别到 {len(words)} 个字")
        print(f"whisper 字数: {len(words)}")
        return words
    except Exception as e:
        notes.append(f"whisper 失败，回退字数计时: {e}")
        print("whisper 失败，回退字数计时:", e)
        return []


def run_align(script: str, audio: str, out: str, notes: list[str], words=None, rms=None):
    import align as al
    from render import parse
    title, shots = parse(script)
    if words is None:
        words = transcribe_audio(audio, notes)
    char_dur = al.median_char_dur(words)
    res = []
    for s in shots:
        ts, rate, method = al.align_shot(s, words, char_dur)
        chars = list(s["line"])
        res.append(dict(
            n=s["n"], method=method, match=round(rate, 3),
            chars=[[c, round(ts[i], 3), round(ts[i + 1], 3)] for i, c in enumerate(chars)],
        ))
        print(f"#{s['n']:>2} 匹配率 {rate:.0%} {method}")
    if rms is None:
        rms = al.rms_env(audio)
    payload = dict(lines=res, rms=rms)
    json.dump(payload, open(out, "w", encoding="utf-8"), ensure_ascii=False)
    print("写入", out)
    return payload, words, shots


def measure_drift(json_shots: list[dict], whisper_words: list, notes: list[str]) -> float:
    """比较 JSON 镜头起止和 whisper 里靠近的语音，估一个整体平移（秒）。"""
    if not whisper_words:
        notes.append("没有 whisper 结果，无法核对 JSON 时间")
        return 0.0
    deltas = []
    for s in json_shots:
        # 用镜头窗口附近的识别起点对比
        t0, t1 = s["t0"], s["t1"]
        nearby = [w for w in whisper_words if t0 - 2.5 <= w[1] <= t1 + 2.5]
        if not nearby:
            continue
        # 窗口内第一/最后一个识别字
        first = min(nearby, key=lambda w: w[1])
        last = max(nearby, key=lambda w: w[2])
        # 更严：取落在 [t0-0.4, t1+0.4] 的
        inside = [w for w in nearby if t0 - 0.4 <= w[1] <= t1 + 0.4]
        if inside:
            first = min(inside, key=lambda w: w[1])
            last = max(inside, key=lambda w: w[2])
        d0 = first[1] - t0
        d1 = last[2] - t1
        deltas.append((s["n"], d0, d1, first[1], last[2]))
    if not deltas:
        notes.append("whisper 与 JSON 镜头对不上，未做时间平移")
        return 0.0
    # 用各镜头起点差的中位数当整体漂移
    starts = sorted(d[1] for d in deltas)
    mid = starts[len(starts) // 2]
    details = ", ".join(f"#{n} 起点{d0:+.2f}s 终点{d1:+.2f}s" for n, d0, d1, _, _ in deltas[:6])
    notes.append(f"JSON 相对音频的起点差中位数 {mid:+.3f}s（{details}）")
    print("时间核对:", notes[-1])
    return mid


def guess_episode(data: dict, json_path: str) -> int:
    for src in (data.get("episode_code") or "", data.get("project_title") or "", os.path.basename(json_path)):
        m = re.search(r"EP0*(\d+)", src, re.I)
        if m:
            return int(m.group(1))
    return 1


def tighten_align_to_rms(align: dict, parsed_shots: list, notes: list, fps=30, sil=0.08):
    """只收回「镜头末尾拖进静音」的字级时间。从本镜头终点（或下一镜头起点之前）往回找最后一帧有声，
    把落在最后一段语音里、却被插值拉过静音的字压回到这段语音里。不会把句中停顿误当成结尾。"""
    rms = align.get("rms") or []
    if not rms:
        return align
    nxt = {}
    ordered = sorted(parsed_shots, key=lambda s: s["t0"])
    for a, b in zip(ordered, ordered[1:]):
        nxt[a["n"]] = b["t0"]

    def last_voice_end(t0, t1, next_t0):
        cap = t1
        if next_t0 is not None:
            cap = min(cap, next_t0 - 0.05)
        cap = max(t0 + 0.05, cap)
        i0 = max(0, int(t0 * fps))
        i1 = min(len(rms) - 1, max(i0, int(cap * fps)))
        last = None
        burst0 = None
        i = i1
        while i >= i0:
            if rms[i] >= sil:
                if last is None:
                    last = (i + 1) / fps
                burst0 = i / fps
            elif last is not None:
                break
            i -= 1
        if last is None:
            return t1, t0
        return last, (burst0 if burst0 is not None else t0)

    nfix = 0
    for ln in align.get("lines") or []:
        ch = ln.get("chars") or []
        if len(ch) < 2:
            continue
        t0, t1 = float(ch[0][1]), float(ch[-1][2])
        end, burst0 = last_voice_end(t0, t1, nxt.get(ln["n"]))
        if t1 - end < 0.15:
            continue
        # 只压缩被拉长的尾巴。括号里的拉丁文（越南语）通常才是被插值拖长的部分，
        # 从 '（' 或第一个拉丁字母起缩放，避免把已经对齐的汉字一起压短。
        latin_i = next((i for i, c in enumerate(ch) if any('A' <= x <= 'Z' or 'a' <= x <= 'z' or 'À' <= x <= 'ɏ' for x in c[0])), None)
        if latin_i is not None and latin_i > 0 and ch[latin_i - 1][0] == '（':
            anchor = latin_i - 1
        elif latin_i is not None:
            anchor = latin_i
        else:
            anchor = 0
            for i, c in enumerate(ch):
                if float(c[1]) >= burst0 - 0.06:
                    anchor = i
                    break
            else:
                anchor = max(0, len(ch) - 4)
        # 若锚之前的字已经对准，不要改它们
        a0 = float(ch[anchor][1])
        span = t1 - a0
        newspan = max(0.08, end - a0)
        if span <= 0 or newspan >= span:
            continue
        for i in range(anchor, len(ch)):
            c0, c1 = float(ch[i][1]), float(ch[i][2])
            ch[i][1] = round(a0 + (c0 - a0) * newspan / span, 3)
            ch[i][2] = round(a0 + (c1 - a0) * newspan / span, 3)
        for i in range(1, len(ch)):
            if ch[i][1] < ch[i - 1][1]:
                ch[i][1] = ch[i - 1][1]
            if ch[i][2] < ch[i][1]:
                ch[i][2] = round(ch[i][1] + 0.02, 3)
        ch[-1][2] = round(end, 3)
        ln["chars"] = ch
        nfix += 1
        notes.append(f"对齐收尾 #{ln['n']} {t1:.2f}s → {end:.2f}s（去掉拖进静音的 {t1-end:.2f}s）")
    if nfix:
        print(f"收紧了 {nfix} 条对齐尾巴")
    return align


def main():
    ap = argparse.ArgumentParser(description="语音 App JSON → vn_theater 渲染输入")
    ap.add_argument("json", help="EP*_render.json")
    ap.add_argument("audio", help="对应人声音频 mp3/wav")
    ap.add_argument("--outdir", default=".", help="输出目录（脚本/mix/特效/对齐/音频副本）")
    ap.add_argument("--stem", default=None, help="文件名前缀，默认 EP04 这种")
    ap.add_argument("--episode", type=int, default=None)
    ap.add_argument("--banner", default=None, help="横幅图片路径，写入 mix.json")
    ap.add_argument("--add-characters", action="store_true", help="把新角色的色块写入 characters.json（先自行备份）")
    ap.add_argument("--align", action="store_true", help="用 whisper 对齐并按标点拆气泡")
    ap.add_argument("--no-split", action="store_true", help="不对长句拆气泡")
    ap.add_argument("--max-drift", type=float, default=0.35, help="整体漂移超过该秒数才平移 JSON 时间")
    ap.add_argument("--roster", default=None, help="15 人名单 JSON，默认仓库内 roster15.json")
    args = ap.parse_args()

    data = json.load(open(args.json, encoding="utf-8"))
    episode = args.episode or guess_episode(data, args.json)
    stem = args.stem or f"EP{episode:02d}"
    outdir = os.path.abspath(args.outdir)
    roster = load_roster(args.roster)
    shots, roster_errors, expr_notes = build_shots(data, roster)
    notes = []
    if roster_errors:
        notes.append("【人物名单校验失败｜已中止，未写出脚本/音频副本，也不会继续渲染】")
        notes.extend(roster_errors)
        notes.append("请把 JSON 的 speaker 改成「编号·姓名」且与 roster15.json 一致（例：05·苏姐、13·肖雨晴）。")
        notes.append("已登记别名：肖老师 → 13·肖雨晴。名单外角色（如旧稿中的辛迪、贾总、老K、阿呆、冷哥）不会被自动替换。")
        os.makedirs(outdir, exist_ok=True)
        report_path = os.path.join(outdir, f"{stem}_import_report.txt")
        if os.path.exists(report_path):
            report_path = os.path.join(outdir, f"{stem}_import_report_error.txt")
            n = 2
            while os.path.exists(report_path):
                report_path = os.path.join(outdir, f"{stem}_import_report_error_{n}.txt")
                n += 1
        report = [
            f"源 JSON: {os.path.abspath(args.json)}",
            f"源音频: {os.path.abspath(args.audio)}",
            f"输出目录: {outdir}",
            f"名单: {roster['path']}",
            f"集数: {episode}",
            *notes,
        ]
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("\n".join(report) + "\n")
        print("\n".join(report))
        print("报告:", report_path)
        sys.exit(2)

    os.makedirs(outdir, exist_ok=True)

    notes = []
    words = extract_words(data)
    group = extract_group(data)
    names = []
    for s in shots:
        if s["name"] not in names:
            names.append(s["name"])
        if s.get("alias_used"):
            notes.append(f"镜头 #{s['n']}: 别名「{s['alias_used']}」已解析为 {s['num']}·{s['name']}")
        src_speaker = (s.get("src") or {}).get("speaker") or ""
        if src_speaker and parse_speaker(src_speaker)[0] is None and not (s.get("src") or {}).get("character_id"):
            notes.append(f"镜头 #{s['n']}: JSON 未写编号，已按 15 人表补全为 {s['num']}·{s['name']}")
        if s.get("expression"):
            notes.append(f"镜头 #{s['n']}: 表情 {s.get('expression_id') or ''}{s['expression']}（{s['name']}）")
    notes.extend(expr_notes)

    banner = args.banner
    if banner and not os.path.isabs(banner):
        cand = [
            os.path.abspath(banner),
            os.path.join(HERE, banner),
            os.path.join(HERE, "assets", "banner", os.path.basename(banner)),
        ]
        banner = next((p for p in cand if os.path.exists(p)), os.path.abspath(banner))
        if not os.path.exists(banner):
            notes.append(f"横幅不存在: {banner}")

    add_characters(names, notes, do_write=args.add_characters)

    script_path = os.path.join(outdir, f"{stem}_script.txt")
    audio_dest = os.path.join(outdir, f"{stem}_audio{os.path.splitext(args.audio)[1] or '.mp3'}")
    mix_path = os.path.join(outdir, f"{stem}_script.mix.json")
    fx_path = os.path.join(outdir, f"{stem}_script.effects.json")
    gloss_path = os.path.join(outdir, f"{stem}_script.gloss.json")
    align_path = os.path.join(outdir, f"{stem}_script.align.json")

    existing = [path for path in (script_path, audio_dest, mix_path, fx_path, gloss_path, align_path)
                if os.path.exists(path)]
    if existing:
        print("拒绝覆盖已有文件:")
        for path in existing:
            print("  ", path)
        print("请换一个 --outdir 或 --stem。EP01–EP04 既有文件不得覆盖。")
        sys.exit(2)

    # 先按 JSON 时间写一版脚本，供对齐使用
    write_script(script_path, data, shots, words, group)
    if os.path.abspath(args.audio) != os.path.abspath(audio_dest):
        shutil.copy2(args.audio, audio_dest)

    sfx_data = data  # may mutate sec if we apply offset
    align = None
    whisper_words = None
    if args.align:
        import align as al
        whisper_words = transcribe_audio(audio_dest, notes)
        rms = al.rms_env(audio_dest)
        align, whisper_words, parsed = run_align(script_path, audio_dest, align_path, notes, words=whisper_words, rms=rms)
        # 用对齐后的首字时间对比 JSON 起点（正值=语音比脚本晚）
        start_deltas = []
        for ln, sh in zip(align.get("lines") or [], shots):
            if (ln.get("match") or 0) < 0.3 or not ln.get("chars"):
                continue
            start_deltas.append(float(ln["chars"][0][1]) - sh["t0"])
        if start_deltas:
            start_deltas.sort()
            mid = start_deltas[len(start_deltas) // 2]
            notes.append(f"对齐首字相对 JSON 起点的中位数 {mid:+.3f}s")
            print("时间核对:", notes[-1])
            # 语音通常比镜头标的 t0 稍晚 0.1–0.3s，不算钟差；只修正明显的整体平移
            if mid <= -args.max_drift or mid >= max(args.max_drift, 0.5):
                notes.append(f"整体漂移 {mid:+.3f}s，已平移镜头和音效时间")
                apply_offset(shots, data, mid)
                write_script(script_path, data, shots, words, group)
                align, whisper_words, parsed = run_align(script_path, audio_dest, align_path, notes, words=whisper_words, rms=rms)
        else:
            drift = measure_drift(shots, whisper_words, notes)
            if abs(drift) >= args.max_drift:
                notes.append(f"整体漂移 {drift:+.3f}s ≥ {args.max_drift}s，已平移镜头和音效时间")
                apply_offset(shots, data, drift)
                write_script(script_path, data, shots, words, group)
                align, whisper_words, parsed = run_align(script_path, audio_dest, align_path, notes, words=whisper_words, rms=rms)
        if not args.no_split:
            shots = split_shots_with_align(shots, align.get("lines") if align else [], notes)
            write_script(script_path, data, shots, words, group)
            align, whisper_words, parsed = run_align(script_path, audio_dest, align_path, notes, words=whisper_words, rms=rms)

    if args.align and align:
        from render import parse as _parse
        _, parsed_final = _parse(script_path)
        tighten_align_to_rms(align, parsed_final, notes)
        json.dump(align, open(align_path, "w", encoding="utf-8"), ensure_ascii=False)

    write_mix(mix_path, data, words, group, episode, banner)
    write_effects(fx_path, data, notes)
    write_gloss(gloss_path, words)

    report_path = os.path.join(outdir, f"{stem}_import_report.txt")
    report = [
        f"源 JSON: {os.path.abspath(args.json)}",
        f"源音频: {os.path.abspath(args.audio)}",
        f"输出目录: {outdir}",
        f"名单: {roster['path']}",
        f"集数: {episode}  群名: {group}",
        f"角色: " + ", ".join(f"{next(x['num'] for x in shots if x['name']==n)}·{n}" for n in names),
        f"单词: " + ("; ".join(
            f"{w['word']}={w.get('meaning') or '—'} 谐音:{w.get('homophone') or '（无，原文未写）'}"
            for w in words
        ) or "（原文没有可收的单词）"),
        f"镜头数: {len(shots)}",
        *notes,
    ]
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report) + "\n")
    print("\n".join(report))
    print("报告:", report_path)


if __name__ == "__main__":
    main()
