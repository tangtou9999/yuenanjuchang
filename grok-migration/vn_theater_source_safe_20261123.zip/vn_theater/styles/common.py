"""公共绘图函数。所有风格共用；风格差异由 THEME 字典决定。
入口: draw_frame(state, T) -> PIL.Image (RGB)
state = dict(t=当前秒, shot=当前镜头, prev=上一镜头或None, chars=角色表, title=标题, board=[(vn,zh)], fade=交叉淡化秒数)
"""
import re, math
from PIL import Image, ImageDraw, ImageFont
W, H = 1080, 1920
FB = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
def F(sz, bold=True): return ImageFont.truetype(FB if bold else FR, sz, index=2)
VN_RE = re.compile(r"[A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ!?]*(?:\s+[A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ!?]*)*")
def seat_xy(x, y):  # 脚本坐标 → 画面坐标（Y 越大越靠后排、越靠上）
    return int(W/2 + x * 400), int(1130 - (y + 0.4) * 430)

def tw(d, s, f): b = d.textbbox((0, 0), s, font=f); return b[2] - b[0]

def draw_bg(chars, board_words, T):
    im = Image.new("RGB", (W, H)); d = ImageDraw.Draw(im)
    for yy in range(H):  # 墙面渐变
        k = yy / H; d.line([(0, yy), (W, yy)], fill=tuple(int(T["wall"][0][j]*(1-k)+T["wall"][1][j]*k) for j in range(3)))
    # 窗户
    for wx in (40, 860):
        d.rounded_rectangle([wx, 220, wx+180, 520], 12, fill=T["window"], outline=T["frame"], width=10)
        d.line([(wx+90, 220), (wx+90, 520)], fill=T["frame"], width=6); d.line([(wx, 370), (wx+180, 370)], fill=T["frame"], width=6)
    # 黑板
    d.rounded_rectangle([250, 190, 830, 560], 16, fill=T["board_frame"])
    d.rectangle([268, 208, 812, 542], fill=T["board"])
    d.text((W/2, 250), "今日单词", font=F(44), fill=T["board_head"], anchor="mm")
    for i, (vn, zh) in enumerate(board_words):
        d.text((W/2, 340 + i*100), f"{vn} = {zh}", font=F(64), fill=T["board_text"], anchor="mm")
    # 原木桌（透视椭圆）
    d.ellipse([60, 640, 1020, 1200], fill=T["table"][0]); d.ellipse([80, 655, 1000, 1180], fill=T["table"][1])
    for k in range(6): d.arc([120+k*25, 690+k*20, 960-k*25, 1150-k*20], 200, 340, fill=T["table"][2], width=3)
    # 冰咖啡杯
    for cx, cy in ((540, 1110), (330, 700), (750, 700)):
        d.rounded_rectangle([cx-16, cy-36, cx+16, cy+10], 6, fill=(120, 80, 50), outline=(230, 240, 250), width=3)
        d.line([(cx+6, cy-36), (cx+14, cy-60)], fill=(250, 90, 90), width=4)
    return im

def draw_seats(base, chars, spk, T):
    im = base.copy(); ov = Image.new("RGBA", (W, H)); d = ImageDraw.Draw(ov)
    for name, c in sorted(chars.items(), key=lambda kv: -kv[1]["y"]):
        px, py = seat_xy(c["x"], c["y"]); on = name == spk
        r = 70 if on else 44; col = c["color"] + ((255,) if on else (140,))
        if on:
            for g in range(5): d.ellipse([px-r-30+g*6, py-r-30+g*6, px+r+30-g*6, py+r+30-g*6], fill=c["color"]+(30,))
        d.ellipse([px-r, py-r, px+r, py+r], fill=col, outline=(255, 255, 255, 255 if on else 150), width=6 if on else 3)
        d.text((px, py), c["avatar"], font=F(64 if on else 38), fill=(255, 255, 255, 255 if on else 180), anchor="mm")
        d.text((px, py+r+24), name, font=F(30 if on else 24), fill=T["seat_label"] + (255 if on else 150,), anchor="mm")
    im.paste(ov, (0, 0), ov); return im

def card_layer(c, name, T):
    ov = Image.new("RGBA", (W, H)); d = ImageDraw.Draw(ov)
    x0, y0, x1, y1 = 90, 1240, 990, 1460
    d.rounded_rectangle([x0+8, y0+10, x1+8, y1+10], T["card_radius"], fill=(0, 0, 0, 90))
    d.rounded_rectangle([x0, y0, x1, y1], T["card_radius"], fill=(c["color"] if T["card_fill"]=="char" else T["card_fill"])+(255,), outline=c["color"] if T["card_fill"]!="char" else (255,255,255), width=8)
    d.ellipse([x0+30, y0+30, x0+190, y0+190], fill=(255, 255, 255) if T["card_fill"]=="char" else c["color"])
    d.text((x0+110, y0+110), c["avatar"], font=F(96), fill=c["color"] if T["card_fill"]=="char" else (255,255,255), anchor="mm")
    d.text((x0+230, y0+60), name, font=F(84), fill=T["card_text"], anchor="lm")
    d.text((x0+232, y0+160), c["role"], font=F(48, False), fill=T["card_text"], anchor="lm")
    return ov

def title_layer(title, T):
    ov = Image.new("RGBA", (W, H)); d = ImageDraw.Draw(ov)
    d.rectangle([0, 0, W, 160], fill=T["title_bg"]); d.rectangle([0, 160, W, 168], fill=T["accent"])
    parts = re.split(r"[：:]", title, maxsplit=1)
    d.text((W/2, 52), parts[0], font=F(40), fill=T["accent"], anchor="mm")
    sub = parts[1] if len(parts) > 1 else ""; f = F(44)
    while tw(d, sub, f) > W - 60: f = F(f.size - 2)
    d.text((W/2, 115), sub, font=f, fill=T["title_text"], anchor="mm")
    return ov

def split_pages(line, maxc=28):
    segs = re.findall(r"[^，。！？；…—!?]+[，。！？；…—!?]*", line) or [line]
    pages, cur = [], ""
    for s in segs:
        if cur and len(cur) + len(s) > maxc: pages.append(cur); cur = s
        else: cur += s
    if cur: pages.append(cur)
    return pages

def wrap_runs(d, text, f, maxw):
    # 拆成 (文本, 是否越南语) 的 token，再按宽度换行
    toks, pos = [], 0
    for m in VN_RE.finditer(text):
        toks += [(ch, False) for ch in text[pos:m.start()]]; toks.append((m.group(0), True)); pos = m.end()
    toks += [(ch, False) for ch in text[pos:]]
    lines, cur, cw = [], [], 0
    for t, v in toks:
        w = tw(d, t, f)
        if cur and cw + w > maxw: lines.append(cur); cur, cw = [], 0
        if not cur and t == " ": continue
        cur.append((t, v)); cw += w
    if cur: lines.append(cur)
    return lines

def sub_layer(text, T):
    ov = Image.new("RGBA", (W, H)); d = ImageDraw.Draw(ov); f = F(60)
    lines = wrap_runs(d, text, f, W - 140); lh = 84
    top = 1520; d.rounded_rectangle([40, top-20, W-40, top + lh*len(lines) + 20], 28, fill=T["sub_bg"])
    for i, ln in enumerate(lines):
        x = (W - sum(tw(d, t, f) for t, _ in ln)) / 2; y = top + i*lh
        for t, v in ln:
            d.text((x, y), t, font=f, fill=T["vn"] if v else T["sub_text"], stroke_width=4, stroke_fill=T["sub_stroke"])
            if v: d.line([(x, y+80), (x+tw(d, t, f), y+80)], fill=T["vn"], width=5)
            x += tw(d, t, f)
    return ov

def caption_img(text, T):
    f = F(120); d = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    w = tw(d, text, f) + 120; im = Image.new("RGBA", (w, 230)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([6, 6, w-6, 224], 50, fill=T["cap_bg"], outline=(255, 255, 255), width=10)
    d.text((w/2, 112), text, font=f, fill=T["cap_text"], anchor="mm", stroke_width=6, stroke_fill=T["cap_stroke"])
    if w > W - 60: im = im.resize((W-60, int(230*(W-60)/w)))
    return im


_cache = {}
def prep(s, chars, title, board, T):
    key = (T["name"], s["n"])
    if key in _cache: return _cache[key]
    if (T["name"], "base") not in _cache:
        _cache[(T["name"], "base")] = draw_bg(chars, board, T); _cache[(T["name"], "title")] = title_layer(title, T)
    c = chars[s["name"]]; bg = draw_seats(_cache[(T["name"], "base")], chars, s["name"], T)
    pages = split_pages(s["line"]); total = max(sum(len(p) for p in pages), 1); span = s["t1"] - s["t0"]; acc = 0; pl = []
    for p in pages:
        pl.append((s["t0"] + span*acc/total, sub_layer(p, T))); acc += len(p)
    r = dict(bg=bg, card=card_layer(c, s["name"], T), pages=pl, caps=[caption_img(x, T) for x in s["caps"]], focus=seat_xy(c["x"], c["y"]))
    _cache[key] = r
    return r

def _one(t, s, st, T):
    p = prep(s, st["chars"], st["title"], st["board"], T); tl = _cache[(T["name"], "title")]
    L = max(s["end"] - s["t0"], 0.1); k = min(max((t - s["t0"]) / L, 0), 1)
    k = 0.5 - 0.5*math.cos(math.pi*k); z = 1.0 + T["zoom"]*k
    fx, fy = p["focus"]; cw, ch = W/z, H/z
    cx = min(max(W/2 + (fx - W/2)*0.6*k, cw/2), W - cw/2); cy = min(max(H/2 + (fy - H/2)*0.6*k, ch/2), H - ch/2)
    im = p["bg"].crop((int(cx-cw/2), int(cy-ch/2), int(cx+cw/2), int(cy+ch/2))).resize((W, H), Image.BILINEAR).convert("RGBA")
    ct = t - s["t0"]
    if ct < 0.35:
        card = p["card"].crop((0, 1180, W, 1500)); sc = 0.7 + 0.3*(ct/0.35); cw2, ch2 = int(W*sc), int(320*sc)
        im.alpha_composite(card.resize((cw2, ch2)), ((W-cw2)//2, 1180 + (320-ch2)//2))
    else: im.alpha_composite(p["card"])
    im.alpha_composite(tl)
    sub = None
    for s0, lay in p["pages"]:
        if t >= s0: sub = lay
    if sub is not None and t <= s["t1"] + 0.3: im.alpha_composite(sub)
    for i, cap in enumerate(p["caps"]):
        dt = t - (s["t0"] + 0.6 + i*4.0)
        if 0 <= dt < 3.5:
            sc = 0.3 + dt/0.2*0.9 if dt < 0.2 else (1.2 - (dt-0.2)/0.15*0.2 if dt < 0.35 else 1.0)
            c = cap.resize((max(1, int(cap.width*sc)), max(1, int(cap.height*sc))))
            if dt > 3.2: c.putalpha(c.getchannel("A").point(lambda v: int(v*(3.5-dt)/0.3)))
            im.alpha_composite(c, ((W - c.width)//2, 880 - c.height//2))
    return im

def draw_frame(state, T):
    t, s, prev = state["t"], state["shot"], state.get("prev")
    im = _one(t, s, state, T); fade = state.get("fade", 0.25)
    if prev is not None and t - s["t0"] < fade:
        im = Image.blend(_one(t, prev, state, T), im, (t - s["t0"]) / fade)
    if len(_cache) > 12:
        for kk in [k for k in _cache if k[1] not in ("base", "title")][:6]: _cache.pop(kk)
    return im.convert("RGB")
