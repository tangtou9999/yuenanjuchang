"""聊天气泡风格公共引擎。每个 chat_x 提供 STYLE 字典 + 绘制函数，这里负责：取当前可见消息、排版、滚动、弹入动画。"""
import math
import re
import numpy as np
from PIL import Image, ImageDraw
from .common import F, VN_RE, W, H

GLOSS = {}   # 由 render.py 自动填入（glossary.py 生成的 <script>.gloss.json），不要手改
def gloss(word):
    return GLOSS.get(re.sub(r"[!?.,，。！？]+$", "", word.strip()).lower(), "")

def tokens(text):
    out, pos = [], 0
    for m in VN_RE.finditer(text):
        out += [(c, False) for c in text[pos:m.start()]]; out.append((m.group(0), True)); pos = m.end()
    return out + [(c, False) for c in text[pos:]]

_D = ImageDraw.Draw(Image.new("RGB", (1, 1)))
def tw(s, f): b = _D.textbbox((0, 0), s, font=f); return b[2] - b[0]

def wrap(text, f, maxw):
    lines, cur, cw = [], [], 0
    for t, v in tokens(text):
        w = tw(t, f)
        if cur and cw + w > maxw:
            if t in "，。！？；、…—）」!?,.":  # 标点不放行首
                cur.append((t, v)); lines.append(cur); cur, cw = [], 0; continue
            lines.append(cur); cur, cw = [], 0
        if not cur and t == " ": continue
        cur.append((t, v)); cw += w
    if cur: lines.append(cur)
    return lines

def draw_rich(d, x, y, lines, f, lh, col, vncol, hl=None, gloss_font=None, gloss_col=None, gloss_h=0):
    """逐行画文字；越南语词换色，可选黄色荧光底(hl)和下方中文注释(gloss)。返回每行实际行高。"""
    for ln in lines:
        cx = x; has_g = False
        for t, v in ln:
            w = tw(t, f)
            if v and hl: d.rounded_rectangle([cx-4, y+lh*0.18, cx+w+4, y+lh*0.92], 8, fill=hl)
            d.text((cx, y), t, font=f, fill=vncol if v else col)
            if v and gloss_font and gloss(t):
                g = gloss(t); d.text((cx + w/2, y + lh + 2), g, font=gloss_font, fill=gloss_col, anchor="mt"); has_g = True
            cx += w
        y += lh + (gloss_h if gloss_font and any(v and gloss(t) for t, v in ln) else 0)
    return y

def line_h(lines, lh, gloss_h=0):
    return sum(lh + (gloss_h if gloss_h and any(v and gloss(t) for t, v in ln) else 0) for ln in lines)

def visible(state):
    t = state["t"]; items = []
    for s in state["shots"]:
        if s["t0"] <= t:
            items.append(dict(kind="msg", shot=s, t0=s["t0"]))
            for i, c in enumerate(s["caps"]):
                ct = s["t0"] + 0.6 + i*0.8
                if ct <= t: items.append(dict(kind="cap", text=c, shot=s, t0=ct))
    items.sort(key=lambda x: x["t0"])
    return items

def ease(x): x = min(max(x, 0), 1); return 1 - (1 - x)**3

def layout_stack(items, t, measure, bottom, top, gap):
    """从下往上排；最新一条按弹入进度平滑把旧消息往上推。返回 [(item, y, h, k)]，k=弹入进度。"""
    out = []; y = bottom
    for idx, it in enumerate(reversed(items)):
        h = measure(it, idx)
        k = ease((t - it["t0"]) / 0.3)
        if idx == 0:
            push = (h + gap) * k; y = bottom - push + gap; yy = y
        else:
            y -= h + gap; yy = y
        if yy + h < top - 200: break
        out.append((it, yy, h, k))
    return out

def _safe_composite(dst, src, x, y):
    """alpha_composite with clipping so a 1px subpixel pad cannot go out of bounds."""
    x, y = int(x), int(y)
    dw, dh = dst.size
    sw, sh = src.size
    sx = 0 if x >= 0 else -x
    sy = 0 if y >= 0 else -y
    dx, dy = max(x, 0), max(y, 0)
    w = min(sw - sx, dw - dx)
    h = min(sh - sy, dh - dy)
    if w <= 0 or h <= 0:
        return
    if sx or sy or w != sw or h != sh:
        src = src.crop((sx, sy, sx + w, sy + h))
    dst.alpha_composite(src, (dx, dy))


def paste_subpixel(dst, src, x, y):
    """把图层贴到浮点坐标上。PIL 只能按整数像素贴图，慢速上滑时 int() 会一帧停在同一行、
    下一帧跳 1px，看起来就一顿一顿的。这里用双线性把小数偏移写进图层再贴。"""
    if src is None:
        return
    fx, fy = float(x), float(y)
    ix, iy = math.floor(fx), math.floor(fy)
    dx, dy = fx - ix, fy - iy
    if dx < 1e-4 and dy < 1e-4:
        _safe_composite(dst, src, ix, iy)
        return
    arr = np.asarray(src, dtype=np.float32)
    h, w = arr.shape[0], arr.shape[1]
    pad = np.zeros((h + 1, w + 1, arr.shape[2]), dtype=np.float32)
    pad[:h, :w] = arr
    out = (
        (1.0 - dx) * (1.0 - dy) * pad[:-1, :-1]
        + dx * (1.0 - dy) * pad[:-1, 1:]
        + (1.0 - dx) * dy * pad[1:, :-1]
        + dx * dy * pad[1:, 1:]
    )
    shifted = Image.fromarray(np.clip(np.round(out), 0, 255).astype(np.uint8), src.mode)
    _safe_composite(dst, shifted, ix, iy)


def pop(canvas, layer, box, k, anchor="left"):
    """把单条消息图层按弹入进度 k 缩放+淡入贴上（位置保持亚像素，避免滚动抖动）。"""
    if k >= 0.999:
        paste_subpixel(canvas, layer, box[0], box[1])
        return
    sc = 0.6 + 0.4 * k
    w, h = max(1, int(round(layer.width * sc))), max(1, int(round(layer.height * sc)))
    l = layer.resize((w, h), Image.Resampling.BILINEAR)
    l.putalpha(l.getchannel("A").point(lambda v, kk=k: int(v * kk)))
    if anchor == "left":
        ox = box[0]
    elif anchor == "right":
        ox = box[0] + layer.width - w
    else:
        ox = box[0] + (layer.width - w) / 2.0
    paste_subpixel(canvas, l, ox, box[1] + layer.height - h)
