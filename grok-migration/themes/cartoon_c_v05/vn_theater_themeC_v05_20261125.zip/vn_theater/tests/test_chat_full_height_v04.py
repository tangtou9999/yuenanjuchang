"""Regression guards for the mobile-first 2026-11-25 chat reading layout."""
import unittest
from styles.chat_final import INPUT_BAR_TOP, BOTTOM, TOP, CHAT_TOP, FN, FG, FNAME
from styles.common import H

class FullHeightChatV04Tests(unittest.TestCase):
    def test_chat_extends_to_input_bar(self):
        self.assertGreaterEqual(BOTTOM, 1790)
        self.assertLess(BOTTOM, INPUT_BAR_TOP)
        self.assertLessEqual(INPUT_BAR_TOP - BOTTOM, 20)
        self.assertGreater(CHAT_TOP, TOP)
        self.assertLess(INPUT_BAR_TOP, H - 90)

    def test_large_message_fonts(self):
        self.assertGreaterEqual(FN.size, 54)
        self.assertGreaterEqual(FNAME.size, 34)
        self.assertGreaterEqual(FG.size, 32)

if __name__ == '__main__':
    unittest.main()
