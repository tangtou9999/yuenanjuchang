#!/usr/bin/env python3
"""每集竖屏封面生成器。

输出 1080×1920 PNG；关键内容（标题、人物、词汇卡）全部落在画面中间的
1080×1440 区域内，方便小红书 3:4 网格直接裁切上下各 240px。

用法（一集一条命令）:
  python make_cover.py path/to/EP04_script.mix.json
  python make_cover.py --mix EP04_script.mix.json --json incoming/EP04_render.json \\
      -o /workspace/cover_check/EP04_cover.png

字段优先读 mix.json：
  episode, hook, banner_title, words[{word, meaning, homophone}], banner
  可选 cover: {theme, hero:{name,emotion}, reactors:[{name,emotion}],
               headline, highlight, word}  用来覆盖自动推断。
不足时再读 render json 的 project_title / millisecond_timeline。
谐音只采用 mix/脚本里显式给出的 homophone，不自动编。
"""
from __future__ import annotations

import argparse, json, math, os, re, sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = Path(__file__).resolve().parent
W, H = 1080, 1920
# 小红书 3:4 = 1080×1440，从 1920 上下各裁 240
SAFE_TOP, SAFE_BOT = 240, 1680
CROP_H = 1440

FB = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
DELA = "/usr/share/fonts/truetype/sand-box/google/Dela Gothic One/DelaGothicOne-Regular.ttf"
AVATAR_ROOT = HERE / "assets" / "avatars"
CHAR_PATH = HERE / "characters.json"

# 与 banner_05_stage 同色系；也可按集数轮换
THEMES = {
    "stage": {  # 紫夜红幕+黄光，默认
        "bg0": (18, 14, 38),
        "bg1": (58, 22, 52),
        "curtain": (184, 28, 52),
        "curtain_dark": (118, 14, 32),
        "spot": (255, 214, 70),
        "gold": (224, 176, 79),
        "title_w": (255, 255, 255),
        "title_y": (255, 205, 33),
        "stroke": (28, 16, 22),
    },
    "fresh": {
        "bg0": (12, 36, 48),
        "bg1": (18, 78, 86),
        "curtain": (20, 140, 130),
        "curtain_dark": (10, 88, 82),
        "spot": (255, 230, 120),
        "gold": (232, 196, 80),
        "title_w": (255, 255, 255),
        "title_y": (255, 214, 64),
        "stroke": (12, 28, 32),
    },
    "night": {
        "bg0": (10, 12, 28),
        "bg1": (32, 24, 72),
        "curtain": (88, 36, 160),
        "curtain_dark": (48, 18, 100),
        "spot": (180, 200, 255),
        "gold": (212, 190, 110),
        "title_w": (255, 255, 255),
        "title_y": (255, 210, 80),
        "stroke": (16, 12, 36),
    },
    "hot": {
        "bg0": (42, 10, 16),
        "bg1": (92, 22, 28),
        "curtain": (200, 36, 40),
        "curtain_dark": (120, 16, 20),
        "spot": (255, 186, 64),
        "gold": (232, 176, 64),
        "title_w": (255, 255, 255),
        "title_y": (255, 210, 50),
        "stroke": (40, 8, 12),
    },
}
THEME_ORDER = ["stage", "fresh", "hot", "night"]

EMOTIONS = ["普通微笑", "大笑", "坏笑", "懵", "震惊", "生气", "害羞", "无语", "委屈"]


def F(sz, bold=True):
    return ImageFont.truetype(FB if bold else FR, int(sz), index=2)


def hexrgb(h):
    h = str(h).lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _tb(d, text, font):
    b = d.textbbox((0, 0), text, font=font)
    return b[2] - b[0], b[3] - b[1]


def load_json(path, default=None):
    if path and os.path.exists(path):
        return json.load(open(path, encoding="utf-8"))
    return default if default is not None else {}


def find_mix_and_json(args):
    mix_path, json_path = args.mix, args.json
    # positional: a mix.json, a render json, or a directory
    if args.src:
        p = Path(args.src)
        if p.is_dir():
            mixes = list(p.glob("*mix.json")) or list(p.glob("*.mix.json"))
            if mixes:
                mix_path = str(mixes[0])
            js = list(p.glob("*_render.json")) or list(p.glob("*render.json"))
            if js:
                json_path = str(js[0])
        elif p.name.endswith(".mix.json") or p.name.endswith("mix.json"):
            mix_path = str(p)
        elif p.suffix == ".json":
            json_path = str(p)
    return mix_path, json_path


def infer_cfg(mix, data):
    """把 mix + render json 收成封面配置。"""
    cover = dict(mix.get("cover") or {})
    episode = cover.get("episode") or mix.get("episode") or 1
    if not isinstance(episode, int):
        m = re.search(r"(\d+)", str(episode))
        episode = int(m.group(1)) if m else 1
    title = data.get("project_title") or ""
    if not cover.get("episode") and title:
        m = re.search(r"EP0*(\d+)", title, re.I)
        if m:
            episode = int(m.group(1))

    hook = (cover.get("headline") or mix.get("hook") or "").strip()
    if not hook and title:
        # 越南语学习群EP04：请问你贵姓？姓赵(Xin chào)！四连环乌龙
        rest = re.sub(r"^.*?EP0*\d+[:：]?", "", title)
        rest = re.sub(r"四连环.*$", "", rest).strip(" ：:—-")
        hook = rest or title
    highlight = (cover.get("highlight") or "").strip()
    if not highlight:
        m = re.search(r"[“「『\"']([^”」』\"']+)[”」』\"']", hook)
        if m:
            highlight = m.group(1)
        else:
            words = mix.get("words") or []
            if words and words[0].get("homophone"):
                highlight = str(words[0]["homophone"])

    word = cover.get("word")
    if not word:
        words = mix.get("words") or []
        word = words[0] if words else {}
    # 谐音只信显式字段
    if word and not (word.get("homophone") or word.get("谐音")):
        word = dict(word)
        word.pop("homophone", None)

    parts = mix.get("banner_title") or ["越南语", "趣味大剧场"]
    if isinstance(parts, str):
        parts = [parts[:3], parts[3:]] if len(parts) > 3 else [parts, ""]

    theme_name = cover.get("theme") or mix.get("cover_theme")
    if not theme_name:
        banner = str(mix.get("banner") or "")
        for key in THEMES:
            if key in banner.lower():
                theme_name = key
                break
    if not theme_name:
        theme_name = THEME_ORDER[(int(episode) - 1) % len(THEME_ORDER)]
    if theme_name not in THEMES:
        theme_name = "stage"

    hero = cover.get("hero") or {}
    reactors = cover.get("reactors")
    names_in_json = []
    if data.get("millisecond_timeline"):
        for sh in data["millisecond_timeline"]:
            sp = sh.get("speaker") or ""
            m = re.search(r"\d+·([^(（]+)", sp)
            name = (m.group(1) if m else sp).strip()
            name = re.sub(r"（.*$|\(.*$", "", name).strip()
            if name and name not in names_in_json:
                names_in_json.append(name)

    def has_avatar(n):
        return n and (AVATAR_ROOT / n).is_dir()

    if not hero.get("name"):
        hero_name = next((n for n in names_in_json if has_avatar(n)), None)
        if not hero_name:
            hero_name = next((n for n in ("苏姐", "唐哥", "大鹏") if has_avatar(n)), None)
        hero = {"name": hero_name or "", "emotion": hero.get("emotion") or "震惊"}
    hero.setdefault("emotion", "震惊")
    # hook 带笑/哈哈则用大笑
    if "hero" not in cover and re.search(r"哈哈|大笑|笑死", hook):
        hero["emotion"] = "大笑"

    if reactors is None:
        reactors = []
        prefer = [("大笑", "大笑"), ("懵", "懵"), ("震惊", "震惊")]
        for n in names_in_json + ["大鹏", "唐哥", "坦克", "老刘", "阿强"]:
            if n == hero.get("name") or not has_avatar(n) or any(r.get("name") == n for r in reactors):
                continue
            emo = "大笑" if len(reactors) == 0 else "懵"
            reactors.append({"name": n, "emotion": emo})
            if len(reactors) >= 2:
                break

    episode_code = (cover.get("episode_code") or mix.get("episode_code") or data.get("episode_code") or "").strip()
    all_words = []
    for w in (mix.get("words") or mix.get("key_words") or []):
        item = dict(w)
        vn = (item.get("word") or item.get("vi") or "").strip()
        zh = (item.get("meaning") or item.get("zh") or "").strip()
        ho = (item.get("homophone") or item.get("谐音") or "").strip()
        if vn or zh:
            all_words.append({"word": vn, "meaning": zh, "homophone": ho})
    if not all_words and (word or {}).get("word"):
        all_words = [word]
    # 出演人物 + 各人用过的表情（供新封面拼贴；仍保留 hero/reactors 以兼容旧调用）
    try:
        from stage_recap import collect_cast_from_json
        cast = collect_cast_from_json(data) if data else []
    except Exception:
        cast = []
    if not cast and hero.get("name"):
        from_old = [{"name": hero["name"], "emotion": hero.get("emotion"), "used": [hero.get("emotion")]}]
        for r in reactors or []:
            from_old.append({"name": r.get("name"), "emotion": r.get("emotion"), "used": [r.get("emotion")]})
        cast = from_old
    return {
        "episode": int(episode),
        "episode_code": episode_code,
        "hook": hook,
        "highlight": highlight,
        "word": word or {},
        "words": all_words,
        "cast": cast,
        "parts": parts,
        "title_parts": parts,
        "subtitle": mix.get("banner_subtitle") or "每天一分钟学习越南语",
        "theme": theme_name,
        "hero": hero,
        "reactors": reactors,
        "group": mix.get("group") or "",
    }


# ---------- 背景 ----------
def paint_background(theme):
    im = Image.new("RGB", (W, H), theme["bg0"])
    px = im.load()
    r0, g0, b0 = theme["bg0"]
    r1, g1, b1 = theme["bg1"]
    for y in range(H):
        k = y / (H - 1)
        # 略向右下偏色
        col = (
            int(r0 * (1 - k) + r1 * k),
            int(g0 * (1 - k) + g1 * k),
            int(b0 * (1 - k) + b1 * k),
        )
        for x in range(W):
            px[x, y] = col
    # 聚光：从顶部中央打下的黄三角光
    spot = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sp = spot.load()
    sr, sg, sb = theme["spot"]
    cx, top, bot_y = W // 2, -80, int(H * 0.78)
    half_top, half_bot = 40, 520
    for y in range(max(0, top), min(H, bot_y)):
        t = (y - top) / (bot_y - top)
        half = half_top + (half_bot - half_top) * t
        fade = (1 - t) * 0.55
        x0 = int(cx - half)
        x1 = int(cx + half)
        for x in range(max(0, x0), min(W, x1 + 1)):
            # 距中心越远越淡
            edge = abs(x - cx) / max(half, 1)
            a = int(255 * fade * max(0, 1 - edge ** 1.6))
            if a <= 0:
                continue
            sp[x, y] = (sr, sg, sb, a)
    im = Image.alpha_composite(im.convert("RGBA"), spot).convert("RGBA")
    return im


def draw_curtains(im, theme):
    """左右舞台幕布 + 顶部横楣。"""
    L = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(L)
    cr, cd = theme["curtain"], theme["curtain_dark"]
    gold = theme["gold"]

    def drape(x0, x1, from_left):
        width = x1 - x0
        for x in range(x0, x1):
            t = (x - x0) / max(width, 1)
            # 褶皱
            fold = 0.55 + 0.45 * abs(math.sin(t * math.pi * 3.2))
            # 外侧更深
            edge = t if from_left else 1 - t
            shade = 0.35 + 0.65 * (1 - abs(edge - 0.35))
            col = tuple(int(cd[i] * (1 - fold) + cr[i] * fold) for i in range(3))
            col = tuple(int(c * (0.7 + 0.3 * shade)) for c in col)
            # 幕布下沿呈弧形
            drop = int(H * 0.92 - 80 * math.sin((t if from_left else 1 - t) * math.pi * 0.9))
            d.line([(x, 0), (x, drop)], fill=col + (245,), width=1)
        # 内侧一道高光
        hx = x1 - 10 if from_left else x0 + 10
        d.line([(hx, 40), (hx, int(H * 0.7))], fill=(255, 220, 200, 50), width=3)

    drape(0, 118, True)
    drape(W - 118, W, False)

    # 顶部横楣
    d.rectangle([0, 0, W, 70], fill=cd + (255,))
    for x in range(W):
        fold = 0.5 + 0.5 * abs(math.sin(x / 40 * math.pi))
        col = tuple(int(cd[i] * (1 - fold) + cr[i] * fold) for i in range(3))
        d.line([(x, 0), (x, 78 + int(10 * math.sin(x / 70)))], fill=col + (255,))
    # 金边
    d.rectangle([0, 78, W, 90], fill=gold + (240,))
    # 一排小金点（舞台灯）
    for i in range(13):
        cx = 50 + i * 80
        d.ellipse([cx - 8, 96, cx + 8, 112], fill=(255, 220, 110, 255))
        d.ellipse([cx - 4, 98, cx + 4, 108], fill=(255, 250, 210, 255))

    # 星星点缀（幕布内侧）
    stars = [(160, 180), (200, 260), (920, 200), (960, 280), (880, 150), (150, 320)]
    for sx, sy in stars:
        _star(d, sx, sy, 10, (255, 230, 120, 200))

    im.alpha_composite(L)
    return im


def _star(d, x, y, r, fill):
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.4
        pts.append((x + rad * math.cos(ang), y + rad * math.sin(ang)))
    d.polygon(pts, fill=fill)


def vietnam_flag(w=88, h=60):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w - 1, h - 1], 8, fill=(218, 37, 29, 255))
    # 星
    cx, cy, r = w / 2, h / 2, h * 0.28
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = r if i % 2 == 0 else r * 0.4
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    d.polygon(pts, fill=(255, 205, 0, 255))
    return im


# ---------- 文字 ----------
def stroke_text(base, xy, text, font, fill, stroke, sw, anchor="lt"):
    """描边文字（先画一圈描边再填字）。"""
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    x, y = xy
    if sw and stroke:
        # 阴影略向下
        d.text((x + 3, y + 5), text, font=font, fill=(0, 0, 0, 110), anchor=anchor,
               stroke_width=sw + 2, stroke_fill=(0, 0, 0, 80))
        d.text((x, y), text, font=font, fill=fill, anchor=anchor,
               stroke_width=sw, stroke_fill=stroke)
    else:
        d.text((x, y), text, font=font, fill=fill, anchor=anchor)
    base.alpha_composite(layer)
    return base


def split_headline(hook, highlight, font, max_w=920):
    """最多两行。若有高亮词，尽量让高亮单独成行或落在第一行。"""
    hook = (hook or "").strip()
    if not hook:
        return [("", "")]
    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))

    def fits(s):
        return _tb(probe, s, font)[0] <= max_w

    if highlight and highlight in hook:
        i = hook.index(highlight)
        before, after = hook[:i], hook[i + len(highlight):]
        # 把紧挨着的引号留在高亮一侧
        if before.endswith(("“", "「", "『", "\"", "'")):
            highlight = before[-1] + highlight
            before = before[:-1]
        if after.startswith(("”", "」", "』", "\"", "'")):
            highlight = highlight + after[0]
            after = after[1:]
        line1 = (before + highlight).strip()
        line2 = after.strip()
        if line2 and (fits(line1) and fits(line2)):
            return [(before, highlight), (line2, "")]
        if not line2 and fits(line1):
            return [(before, highlight)]
    # 按标点拆
    for sep in ("？", "！", "?", "!", "。", "，", ","):
        if sep in hook and hook.index(sep) < len(hook) - 1:
            a, b = hook.split(sep, 1)
            a, b = (a + sep).strip(), b.strip()
            if a and b and fits(a) and fits(b):
                return [(a, ""), (b, "")]
    if fits(hook):
        # 若有高亮，仍标出来
        if highlight and highlight in hook:
            i = hook.index(highlight)
            return [(hook[:i], highlight + hook[i + len(highlight):])] if False else (
                [(hook[:i], highlight), (hook[i + len(highlight):], "")] if hook[i + len(highlight):] and False
                else [ (hook[:hook.index(highlight)], highlight + hook[hook.index(highlight)+len(highlight):] ) ]
            )
        return [(hook, "")]
    # 硬拆一半
    mid = max(1, len(hook) // 2)
    return [(hook[:mid], ""), (hook[mid:], "")]


def draw_headline_block(im, cfg, theme, y):
    hook, hi = cfg["hook"], cfg["highlight"]
    # 字号自适应
    size = 118
    font = F(size)
    lines = None
    while size >= 72:
        font = F(size)
        lines = _headline_lines(hook, hi, font, max_w=940)
        probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
        if all(_tb(probe, _line_text(*ln), font)[0] <= 940 for ln in lines) and len(lines) <= 2:
            break
        size -= 6
    gap = 10
    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    total_h = 0
    heights = []
    for ln in lines:
        h = _tb(probe, _line_text(*ln) or "字", font)[1]
        heights.append(h)
        total_h += h + gap
    cy = y
    yellow, red, white = theme["title_y"], (230, 48, 40), (255, 252, 245)
    stroke = theme["stroke"]
    for (before, marked, after), h in zip(lines, heights):
        text_full = before + marked + after
        tw, _ = _tb(probe, text_full, font) if text_full else (0, 0)
        x = (W - tw) // 2
        # 分段着色
        if marked:
            if before:
                stroke_text(im, (x, cy), before, font, white, stroke, 8)
                x += _tb(probe, before, font)[0]
            stroke_text(im, (x, cy), marked, font, yellow, (160, 20, 24), 9)
            # 再铺一层红底黄字更跳
            x += _tb(probe, marked, font)[0]
            if after:
                stroke_text(im, (x, cy), after, font, white, stroke, 8)
        else:
            stroke_text(im, (x, cy), text_full, font, white, stroke, 8)
        cy += h + gap
    return cy + 8


def _line_text(before, marked, after=""):
    if isinstance(before, tuple):
        return "".join(before)
    return (before or "") + (marked or "") + (after or "")


def _headline_lines(hook, highlight, font, max_w=940):
    """返回 [(before, marked, after), ...] 最多两行。"""
    hook = (hook or "").strip()
    if not hook:
        return [("", "", "")]
    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))

    def fits(s):
        return _tb(probe, s, font)[0] <= max_w

    if highlight and highlight in hook:
        i = hook.index(highlight)
        before, after = hook[:i], hook[i + len(highlight):]
        marked = highlight
        if before.endswith(("“", "「", "『", "\"", "'")):
            marked = before[-1] + marked
            before = before[:-1]
        if after.startswith(("”", "」", "』", "\"", "'")):
            marked = marked + after[0]
            after = after[1:]
        # 高亮单独一行更有冲击
        # 结尾只有标点时，不要单独成行（避免「？」孤悬）
        if after.strip() and all(ch in "？！?!。，、,. " for ch in after.strip()):
            marked = marked + after
            after = ""
        line1 = before + marked
        if (not before or fits(line1)) and (not after or fits(after)):
            rows = [(before, marked, "")]
            if after.strip():
                rows.append((after.strip(), "", ""))
            return rows
    for sep in ("？", "！", "?", "!", "。"):
        if sep in hook and 0 < hook.index(sep) < len(hook) - 1:
            a, b = hook.split(sep, 1)
            a, b = (a + sep).strip(), b.strip()
            if a and b and fits(a) and fits(b):
                return [(a, "", ""), (b, "", "")]
    if fits(hook):
        if highlight and highlight in hook:
            i = hook.index(highlight)
            return [(hook[:i], highlight, hook[i + len(highlight):])]
        return [(hook, "", "")]
    mid = max(1, len(hook) // 2)
    return [(hook[:mid], "", ""), (hook[mid:], "", "")]


# ---------- 头像 ----------
def _avatar_path(name, emotion):
    folder = AVATAR_ROOT / (name or "")
    if not folder.is_dir():
        return None
    if emotion:
        for fn in os.listdir(folder):
            m = re.match(r"^(\d+)_(.+)\.(png|jpg)$", fn, re.I)
            if m and m.group(2) == emotion:
                return folder / fn
    # fallback
    for emo in ("震惊", "大笑", "普通微笑"):
        for fn in os.listdir(folder):
            if fn.endswith(".png") and f"_{emo}." in fn:
                return folder / fn
    pngs = sorted(folder.glob("[0-9]_*.png"))
    return pngs[0] if pngs else None


def _char_color(name):
    chars = load_json(CHAR_PATH, {})
    c = (chars.get(name) or {}).get("color") or "#E8553D"
    return hexrgb(c)


def _subject_alpha(face_rgb: Image.Image) -> Image.Image:
    """去掉九宫格浅灰背景，只留人物（头发可以溢出圆框）。"""
    import numpy as np
    a = np.array(face_rgb)
    h, w, _ = a.shape
    corners = np.concatenate([
        a[:8, :8].reshape(-1, 3), a[:8, -8:].reshape(-1, 3),
        a[-8:, :8].reshape(-1, 3), a[-8:, -8:].reshape(-1, 3),
    ], 0)
    bg = np.median(corners, axis=0)
    dev = np.linalg.norm(a.astype(np.float32) - bg, axis=2)
    # 软边：背景附近全透明。九宫格顶边常有 1px 浅线，先削掉四周 3px。
    alpha = np.clip((dev - 28) / 14.0, 0, 1)
    alpha = (alpha * 255).astype(np.uint8)
    alpha[:3, :] = 0
    alpha[-3:, :] = 0
    alpha[:, :3] = 0
    alpha[:, -3:] = 0
    return Image.fromarray(alpha, "L")


def pop_avatar(name, emotion, diameter, pop=True):
    """圆形角色头像；只有人物（不是浅灰底）可以从圆框顶上冒出。"""
    path = _avatar_path(name, emotion)
    color = _char_color(name)
    pad = int(diameter * 0.22)
    S = diameter + pad * 2
    ring = max(8, int(diameter * 0.07))
    cx = S // 2
    cy = int(S * 0.58) if pop else S // 2
    r = diameter // 2
    inner = r - ring

    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    # 阴影
    sh = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse([cx - r + 8, cy - r + 18, cx + r + 8, cy + r + 22], fill=(0, 0, 0, 110))
    out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(16)))
    # 色环底
    d = ImageDraw.Draw(out)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (255,))

    if not path:
        d.ellipse([cx - inner, cy - inner, cx + inner, cy + inner], fill=color)
        ch = name[1] if name and name[0] in "阿小老" and len(name) > 1 else (name or "?")[0]
        d.text((cx, cy), ch, font=F(inner), fill="white", anchor="mm")
        return out

    face = Image.open(path).convert("RGB")
    face_side = int(inner * 2 * 1.06)
    face = face.resize((face_side, face_side), Image.Resampling.LANCZOS)
    sub = _subject_alpha(face)
    face_rgba = face.convert("RGBA")
    face_rgba.putalpha(sub)
    fx = cx - face_side // 2
    fy = cy - inner - int(inner * 0.16)

    # 圆内：整张脸（含轻灰摄影背景，显得是一张肖像）
    disc = Image.new("L", (S, S), 0)
    ImageDraw.Draw(disc).ellipse([cx - inner, cy - inner, cx + inner, cy + inner], fill=255)
    # 羽化圆边
    disc = disc.filter(ImageFilter.GaussianBlur(1.2))
    in_face = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    in_face.paste(face.convert("RGBA"), (fx, fy))
    in_face.putalpha(disc)
    out.alpha_composite(in_face)

    if pop:
        # 圆上方：只贴去底后的头发/头顶，避免浅灰方块漏出来
        cap = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        cap.paste(face_rgba, (fx, fy))
        cap_m = Image.new("L", (S, S), 0)
        # 允许溢出的区域：圆顶以上、宽度略收
        ImageDraw.Draw(cap_m).rectangle(
            [cx - int(inner * 0.92), 0, cx + int(inner * 0.92), cy - inner + ring + 4],
            fill=255,
        )
        # 与人物 alpha 求交
        cap_a = cap.split()[-1]
        from PIL import ImageChops
        cap_a = ImageChops.multiply(cap_a, cap_m)
        cap.putalpha(cap_a)
        out.alpha_composite(cap)

    # 下半圈重描色环，上半留口给头发
    ring_l = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring_l)
    rd.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color + (255,), width=ring)
    if pop:
        # 擦掉顶部一小段环，免得压住头发
        wipe = Image.new("L", (S, S), 255)
        ImageDraw.Draw(wipe).rectangle(
            [cx - int(inner * 0.7), 0, cx + int(inner * 0.7), cy - inner + ring // 2],
            fill=0,
        )
        ra = ring_l.split()[-1]
        from PIL import ImageChops
        ring_l.putalpha(ImageChops.multiply(ra, wipe))
    out.alpha_composite(ring_l)
    return out


# ---------- 词汇卡 ----------
def episode_badge(cfg_or_ep, episode=None):
    """R01 等非 EP 编号原样显示；EP 集仍用「第05集」。"""
    if isinstance(cfg_or_ep, dict):
        code = (cfg_or_ep.get("episode_code") or "").strip()
        ep = cfg_or_ep.get("episode", 1)
    else:
        code = str(cfg_or_ep or "").strip()
        ep = episode if episode is not None else 1
        if re.match(r"^\d+$", code):
            ep, code = int(code), ""
    if code and not re.match(r"^EP\d+$", code, re.I):
        return code
    return f"第{int(ep):02d}集"


def vocab_card(word, episode, episode_code=""):
    wtxt = (word.get("word") or "").strip()
    meaning = (word.get("meaning") or "").strip()
    homo = (word.get("homophone") or word.get("谐音") or "").strip()
    if not wtxt and not meaning:
        return None
    cw, ch = 960, 268 if homo else 210
    L = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    # 阴影
    sh = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([8, 12, cw - 2, ch - 2], 28, fill=(0, 0, 0, 90))
    sh = sh.filter(ImageFilter.GaussianBlur(10))
    L.alpha_composite(sh)
    d = ImageDraw.Draw(L)
    d.rounded_rectangle([0, 0, cw - 8, ch - 12], 28, fill=(255, 250, 243, 255), outline=(224, 176, 79, 255), width=6)
    # 红标签
    lab, flab = "今日单词", F(28)
    lw, lh = _tb(d, lab, flab)
    d.rounded_rectangle([28, 22, 28 + lw + 36, 22 + lh + 18], 20, fill=(218, 61, 58))
    d.text((28 + (lw + 36) / 2, 22 + (lh + 18) / 2 - 1), lab, font=flab, fill="white", anchor="mm")
    tip = "越南语词汇卡 · " + episode_badge(episode_code or "", episode)
    d.text((cw - 36, 22 + (lh + 18) / 2), tip, font=F(22, False), fill=(142, 104, 99), anchor="rm")
    # 词 = 义
    midy = 22 + lh + 18 + 28 + 52
    fword, fmean = F(72), F(56)
    d.text((44, midy), wtxt, font=fword, fill=(214, 34, 33), anchor="lm")
    ww = _tb(d, wtxt, fword)[0]
    eqx = 44 + ww + 22
    d.text((eqx, midy), "=", font=fmean, fill=(122, 85, 78), anchor="lm")
    ew = _tb(d, "=", fmean)[0]
    d.text((eqx + ew + 18, midy), meaning, font=fmean, fill=(42, 28, 26), anchor="lm")
    if homo:
        hy = midy + 58
        hl, flh = "谐音", F(22)
        hlw, hlh = _tb(d, hl, flh)
        d.rounded_rectangle([44, hy, 44 + hlw + 22, hy + 34], 8, fill=(224, 176, 79))
        d.text((44 + (hlw + 22) / 2, hy + 17), hl, font=flh, fill="white", anchor="mm")
        d.text((44 + hlw + 34, hy + 18), homo, font=F(46, False), fill=(122, 70, 28), anchor="lm")
    return L


# ---------- 主绘制 ----------
def render_cover(cfg):
    """新默认封面 = 片尾页同款：暗舞台、简标题、全部今日单词、出演人物表情拼贴；无红幕。"""
    import sys
    root = str(HERE)
    if root not in sys.path:
        sys.path.insert(0, root)
    from stage_recap import render_stage_recap, assign_emotions, collect_cast_from_json
    cfg = dict(cfg)
    cfg.setdefault("title_parts", cfg.get("parts") or ["越南语", "趣味大剧场"])
    if not cfg.get("words"):
        w = cfg.get("word") or {}
        if w:
            cfg["words"] = [w]
    if cfg.get("cast"):
        cfg["cast"] = assign_emotions(list(cfg["cast"]))
    return render_stage_recap(cfg)


def crop_3x4(im):
    return im.crop((0, SAFE_TOP, W, SAFE_TOP + CROP_H))


def default_out_paths(cfg, out):
    if out:
        out_p = Path(out)
        if out_p.suffix.lower() != ".png":
            out_p = out_p / f"EP{cfg['episode']:02d}_cover.png"
        preview = out_p.with_name(out_p.stem + "_3x4.png")
        return out_p, preview
    folder = Path("/workspace/cover_check")
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"EP{cfg['episode']:02d}_cover.png", folder / f"EP{cfg['episode']:02d}_cover_3x4.png"


def main():
    ap = argparse.ArgumentParser(description="生成一集竖屏封面（1080×1920 + 3:4 预览）")
    ap.add_argument("src", nargs="?", help="mix.json / render.json / 目录")
    ap.add_argument("--mix", default=None)
    ap.add_argument("--json", default=None, help="语音 App 的 EP*_render.json（可选）")
    ap.add_argument("-o", "--out", default=None, help="1080×1920 PNG 路径")
    ap.add_argument("--theme", default=None, help="覆盖主题：stage / fresh / hot / night")
    ap.add_argument("--hero", default=None, help="主角名，如 苏姐")
    ap.add_argument("--emotion", default=None, help="主角表情，如 震惊")
    ap.add_argument("--headline", default=None, help="覆盖主标题")
    ap.add_argument("--highlight", default=None, help="覆盖高亮词")
    args = ap.parse_args()

    mix_path, json_path = find_mix_and_json(args)
    if not mix_path and not json_path:
        print("请提供 mix.json 或 render json", file=sys.stderr)
        sys.exit(2)
    mix = load_json(mix_path, {})
    data = load_json(json_path, {})
    # 若只给了 mix，尝试同目录/相邻 render json
    if not data and mix_path:
        p = Path(mix_path)
        for cand in (
            p.with_name(p.name.replace("_script.mix.json", "_render.json")),
            HERE / "incoming" / re.sub(r"_script.*", "_render.json", p.name),
            Path("/workspace/vn_theater/incoming") / re.sub(r".*?(EP\d+).*", r"\1_render.json", p.name, flags=re.I),
        ):
            if cand.exists():
                data = load_json(cand, {})
                break

    cfg = infer_cfg(mix, data)
    if args.theme:
        cfg["theme"] = args.theme if args.theme in THEMES else cfg["theme"]
    if args.hero:
        cfg["hero"]["name"] = args.hero
    if args.emotion:
        cfg["hero"]["emotion"] = args.emotion
    if args.headline:
        cfg["hook"] = args.headline
    if args.highlight:
        cfg["highlight"] = args.highlight

    print(f"封面: EP{cfg['episode']:02d}  hook={cfg['hook']!r}  highlight={cfg['highlight']!r}")
    print(f"  主题={cfg['theme']}  主角={cfg['hero']}  配角={cfg['reactors']}")
    print(f"  单词={cfg['word']}")

    im = render_cover(cfg)
    out_p, prev_p = default_out_paths(cfg, args.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    im.save(out_p, "PNG")
    crop_3x4(im).save(prev_p, "PNG")
    print("写入", out_p)
    print("3:4 预览", prev_p)


if __name__ == "__main__":
    main()
