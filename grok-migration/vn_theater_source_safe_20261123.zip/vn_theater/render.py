#!/usr/bin/env python3
"""越南语趣味自习室 批量渲染模板. 用法: render.py script.txt audio.mp3 out.mp4 [--start s --dur s] [--chars characters.json]

人声音频保持原响度；画面特效对应的音效按 assets/sfx/sfx.json 在同一时刻混入（默认约 -12 dB）；
背景音乐按 assets/bgm/bgm.json 循环铺底（默认约 -15 dB（曲目已响度对齐到 −16 LUFS）），说话时 sidechain 闪避，片头 1 秒淡入、片尾 2 秒淡出。
每集可用 <script>.mix.json 或 --bgm / --bgm-vol 覆盖曲目和音量。
"""
import re, sys, json, math, argparse, subprocess, os, colorsys

W, H, FPS = 1080, 1920, 30
HERE = os.path.dirname(os.path.abspath(__file__))
SFX_DIR = os.path.join(HERE, "assets", "sfx")
BGM_DIR = os.path.join(HERE, "assets", "bgm")
FB = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FR = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
def F(sz, bold=True): return ImageFont.truetype(FB if bold else FR, sz, index=2)  # index 2 = SC
VN_RE = re.compile(r"[A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ!?]*(?:\s+[A-Za-zÀ-ỹĐđ][A-Za-zÀ-ỹĐđ!?]*)*")
FADE = 0.25

def ts(s):
    m, r = s.split(":"); return int(m) * 60 + float(r)

def parse(path):
    txt = open(path, encoding="utf-8").read()
    title = re.search(r"《([^》]+)》", txt).group(1)
    shots = []
    blocks = re.split(r"### 【镜头 #(\d+)】", txt)[1:]
    for i in range(0, len(blocks), 2):
        n, b = int(blocks[i]), blocks[i + 1]
        t = re.match(r"\s*([\d:.]+)\s*-->\s*([\d:.]+)", b)
        role = re.search(r"角色与声纹\*\*：\s*\d+·([^(（\s]+)[(（]([^)）]+)[)）].*?X:\s*(-?[\d.]+),\s*Y:\s*(-?[\d.]+)", b)
        line = re.search(r"台词\*\*：「(.*?)」", b)
        cam = re.search(r"机位与动作\*\*：(.*)", b)
        caps = re.findall(r"【([^】]*[A-Za-zÀ-ỹĐđ][^】]*)】", cam.group(1) if cam else "")
        emo_m = re.search(r"表情:\s*([^|\s]+)", b)
        emotion = (emo_m.group(1).strip() if emo_m else "") or None
        shots.append(dict(n=n, t0=ts(t.group(1)), t1=ts(t.group(2)), name=role.group(1), role=role.group(2),
                          x=float(role.group(3)), y=float(role.group(4)), line=line.group(1) if line else "",
                          caps=list(dict.fromkeys(caps)), emotion=emotion))
    shots.sort(key=lambda s: s["t0"])
    # 重叠处理：在下一个镜头开始处切
    for a, b in zip(shots, shots[1:]):
        a["cut"] = b["t0"]
    shots[-1]["cut"] = None
    return title, shots

def hexrgb(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def load_display_names(path=None):
    """roster15.json: 画面称呼。缺省等于规范名；13 为「肖老师」。头像仍按规范名/avatar_folder。"""
    path = path or os.path.join(HERE, "roster15.json")
    out = {}
    if not os.path.exists(path):
        return out
    data = json.load(open(path, encoding="utf-8"))
    for p in data.get("roster") or []:
        name = p.get("name") or ""
        disp = (p.get("display_name") or name).strip() or name
        if name:
            out[name] = disp
        for a in p.get("aliases") or []:
            if a:
                out[a] = disp
    return out


def load_chars(shots, cfgpath):
    cfg = json.load(open(cfgpath, encoding="utf-8")) if os.path.exists(cfgpath) else {}
    displays = load_display_names()
    chars = {}
    for s in shots:
        if s["name"] in chars: continue
        c = cfg.get(s["name"], {})
        if "color" in c: col = hexrgb(c["color"])
        else:
            h = (hash(s["name"]) % 360) / 360; col = tuple(int(v*255) for v in colorsys.hsv_to_rgb(h, .6, .95))
        x, y = c.get("seat", [s["x"], s["y"]])
        disp = displays.get(s["name"], s["name"])
        chars[s["name"]] = dict(avatar=c.get("avatar", s["name"][1] if s["name"][0] in "阿小老" and len(s["name"])>1 else s["name"][0]), color=col, role=s["role"], x=x, y=y, name=s["name"], display_name=disp)
    return chars

def _load_json(path, default=None):
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    return {} if default is None else default


def first_word_time(word, shots, align):
    """返回单词在音频中首次出现的秒数（优先对齐结果）。"""
    if not word:
        return None
    target = word.strip()
    if align:
        for l in align.get("lines") or []:
            chars = l.get("chars") or []
            if not chars:
                continue
            text = "".join(c[0] for c in chars)
            i = text.lower().find(target.lower())
            if i >= 0 and i < len(chars):
                return float(chars[i][1])
    for s in shots:
        if target.lower() in (s.get("line") or "").lower():
            return float(s["t0"])
    return None

def resolve_episode(mix, script_path, shots, align):
    """从 <script>.mix.json 读取集数、钩子标题、顶部文案和重点单词卡。"""
    base = os.path.splitext(os.path.basename(script_path))[0]
    m = re.match(r"EP0*(\d+)", base, re.I)
    num = mix.get("episode", int(m.group(1)) if m else 1)
    try:
        num = int(num)
    except (TypeError, ValueError):
        num = 1
    hook = (mix.get("hook") or "").strip()
    words = []
    for w in mix.get("words") or mix.get("key_words") or []:
        item = dict(w)
        item["word"] = (item.get("word") or item.get("vn") or "").strip()
        item["meaning"] = (item.get("meaning") or item.get("zh") or "").strip()
        item["example_vi"] = (item.get("example_vi") or item.get("example") or "").strip()
        item["example_zh"] = (item.get("example_zh") or item.get("translation") or "").strip()
        if not item["word"]:
            continue
        # 谐音只采用本集 mix.json 里显式填写的 homophone，不从词库猜测
        item["homophone"] = (item.get("homophone") or "").strip()
        t0 = item.get("time")
        item["t"] = float(t0) if t0 is not None else first_word_time(item["word"], shots, align)
        item["dur"] = float(item.get("dur", 1.5))
        item["fly"] = float(item.get("fly", 0.6))
        if item["t"] is None:
            print("警告: 找不到单词首次出现时间，跳过单词卡", item["word"])
            continue
        words.append(item)
    code = (mix.get("episode_code") or "").strip()
    label = code if (code and not re.match(r"^EP\d+$", code, re.I)) else f"第{num:02d}集"
    tag = mix.get("tag") or (label + (f" · {hook}" if hook else ""))
    return dict(
        number=num, hook=hook, tag=tag, episode_code=code,
        group=mix.get("group"),
        subtitle=mix.get("banner_subtitle") or "每天一分钟学习越南语",
        title_parts=mix.get("banner_title") or ["越南语", "趣味大剧场"],
        banner=mix.get("banner"),
        words=words,
    )

def resolve_sfx_events(fx, start, dur, no_sfx=False):
    """特效落在 [start, start+dur) 内时，返回要混入的音效（delay 相对片段起点）。"""
    if no_sfx:
        return []
    cfg = _load_json(os.path.join(SFX_DIR, "sfx.json"), {})
    default_db = float(cfg.get("volume_db", -12))
    types = cfg.get("types", {})
    ev = []
    for e in fx or []:
        typ = e.get("type")
        info = types.get(typ)
        if not info:
            continue
        t = float(e["t"])
        if t < start - 0.02 or t >= start + dur:
            continue
        fn = info["file"]
        path = fn if os.path.isabs(fn) else os.path.join(SFX_DIR, fn)
        if not os.path.exists(path):
            print(f"警告: 找不到音效 {typ} -> {path}")
            continue
        ev.append(dict(
            path=path,
            delay_ms=max(0, int(round((t - start) * 1000))),
            volume_db=float(info.get("volume_db", default_db)),
            type=typ,
            t=t,
        ))
    return ev

def resolve_bgm(args, script_base):
    if getattr(args, "no_bgm", False):
        return None
    mix = _load_json(script_base + ".mix.json", {})
    cfg = _load_json(os.path.join(BGM_DIR, "bgm.json"), {})
    if not cfg.get("enabled", True):
        return None
    name = getattr(args, "bgm", None) or mix.get("bgm") or cfg.get("default")
    if not name:
        return None
    tracks = cfg.get("tracks", {})
    fn = tracks.get(name, name)
    candidates = []
    if os.path.isabs(str(fn)) or os.path.exists(str(fn)):
        candidates.append(fn)
    candidates.append(os.path.join(BGM_DIR, fn))
    stem = os.path.splitext(os.path.basename(str(name)))[0]
    for ext in (".mp3", ".wav", ".ogg", ".m4a"):
        candidates.append(os.path.join(BGM_DIR, stem + ext))
    path = next((p for p in candidates if os.path.exists(p)), None)
    if not path:
        print("警告: 找不到 BGM", name)
        return None
    vol = args.bgm_vol if getattr(args, "bgm_vol", None) is not None else mix.get("bgm_volume_db", cfg.get("volume_db", -15))
    return dict(
        path=path,
        volume_db=float(vol),
        fade_in=float(cfg.get("fade_in", 1.0)),
        fade_out=float(cfg.get("fade_out", 2.0)),
        duck=cfg.get("duck") or {},
    )

def build_audio_mix(start, dur, adur, fx, args, script_base):
    """构造 ffmpeg 额外输入和 filter_complex。无人声响度补偿（amix normalize=0）。
    返回 (extra_inputs, filter_complex 或 None, 音频 map 标签)。
    """
    sfx = resolve_sfx_events(fx, start, dur, no_sfx=getattr(args, "no_sfx", False))
    bgm = resolve_bgm(args, script_base)
    if not sfx and not bgm:
        return [], None, "1:a"

    extra, filters, mix_labels = [], [], ["[voice]"]
    if bgm:
        filters.append(
            f"[1:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,"
            f"atrim={start:.4f}:{start + dur:.4f},asetpts=PTS-STARTPTS,asplit=2[voice][voice_sc]"
        )
    else:
        filters.append(
            f"[1:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,"
            f"atrim={start:.4f}:{start + dur:.4f},asetpts=PTS-STARTPTS[voice]"
        )

    idx = 2
    if bgm:
        extra += ["-stream_loop", "-1", "-i", bgm["path"]]
        fade_parts = []
        if start <= 0.05 and bgm["fade_in"] > 0:
            fade_parts.append(f"afade=t=in:st=0:d={bgm['fade_in']:.3f}")
        if start + dur >= adur - 0.05 and bgm["fade_out"] > 0:
            fo = min(bgm["fade_out"], max(0.05, dur))
            fade_parts.append(f"afade=t=out:st={max(0.0, dur - fo):.3f}:d={fo:.3f}")
        fade = ("," + ",".join(fade_parts)) if fade_parts else ""
        filters.append(
            f"[{idx}:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,"
            f"atrim={start:.4f}:{start + dur:.4f},asetpts=PTS-STARTPTS,"
            f"volume={bgm['volume_db']}dB{fade}[bgmpre]"
        )
        d = bgm["duck"]
        filters.append(
            f"[bgmpre][voice_sc]sidechaincompress=threshold={float(d.get('threshold', 0.05))}:"
            f"ratio={float(d.get('ratio', 8))}:attack={float(d.get('attack', 40))}:"
            f"release={float(d.get('release', 500))}:makeup=1:knee={float(d.get('knee', 2.5))}:"
            f"mix=1[bgm]"
        )
        mix_labels.append("[bgm]")
        idx += 1

    for i, ev in enumerate(sfx):
        extra += ["-i", ev["path"]]
        filters.append(
            f"[{idx}:a]aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,"
            f"adelay={ev['delay_ms']}:all=1,volume={ev['volume_db']}dB[s{i}]"
        )
        mix_labels.append(f"[s{i}]")
        idx += 1
        print(f"  音效 {ev['type']} @ {ev['t']:.2f}s  (片段内 {ev['delay_ms']}ms, {ev['volume_db']} dB)")

    filters.append(
        f"{''.join(mix_labels)}amix=inputs={len(mix_labels)}:duration=first:dropout_transition=0:normalize=0,"
        f"alimiter=limit=0.99:attack=5:release=50[aout]"
    )
    if bgm:
        print(f"  BGM {os.path.basename(bgm['path'])}  {bgm['volume_db']} dB  (循环+闪避)")
    return extra, ";".join(filters), "[aout]"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("script"); ap.add_argument("audio"); ap.add_argument("out")
    ap.add_argument("--start", type=float, default=0); ap.add_argument("--dur", type=float, default=None)
    ap.add_argument("--chars", default=os.path.join(HERE, "characters.json"))
    ap.add_argument("--style", default="style_a", help="style_a / style_b / style_c")
    ap.add_argument("--still", type=float, default=None, help="只渲染该秒的一张 PNG")
    ap.add_argument("--bgm", default=None, help="BGM 曲目名或文件路径（默认 assets/bgm 的 default）")
    ap.add_argument("--bgm-vol", type=float, default=None, dest="bgm_vol", help="BGM 相对人声的 dB，默认 -15")
    ap.add_argument("--no-bgm", action="store_true", help="不混入背景音乐")
    ap.add_argument("--no-sfx", action="store_true", help="不混入音效")
    ap.add_argument("--effects", default=None, help="特效表 JSON（默认 <script>.effects.json）")
    ap.add_argument("--skip-glossary", action="store_true", help="不重跑 glossary，避免改写词库缓存")
    ap.add_argument("--no-endcard", action="store_true", help="片尾不切到独立封面/回顾页，成片在台词结束后结束")
    a = ap.parse_args()
    title, shots = parse(a.script)
    txt = open(a.script, encoding="utf-8").read()
    bw = re.search(r"黑板上写着今日单词：([^\n.]+)", txt)
    board = [tuple(p.strip() for p in w.split("=")) for w in re.split(r"[，,]", bw.group(1))] if bw else []
    chars = load_chars(shots, a.chars)
    adur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.audio]))
    sdur = max(s["t1"] for s in shots)
    print(f"音频 {adur:.3f}s / 脚本 {sdur:.3f}s / 差 {adur - sdur:+.3f}s")
    for s in shots: s["end"] = s["cut"] if s["cut"] is not None else max(s["t1"], adur)
    dur = a.dur if a.dur else adur - a.start
    import importlib; style = importlib.import_module(f"styles.{a.style}")
    base_ = os.path.splitext(a.script)[0]
    alp, fxp = base_ + ".align.json", a.effects or (base_ + ".effects.json")
    venv_py = os.path.join(HERE, ".venv", "bin", "python")
    if a.style in ("chat_final", "radio_podcast") and not os.path.exists(alp):   # 第一次：自动逐字对齐（缓存）
        subprocess.call([venv_py if os.path.exists(venv_py) else sys.executable, os.path.join(HERE, "align.py"), a.script, a.audio, alp])
    if a.style in ("chat_final", "radio_podcast") and not os.path.exists(fxp):   # 第一次：自动生成特效表（可手动改）
        if a.effects:
            print("警告: 找不到特效表", fxp)
        else:
            subprocess.call([sys.executable, os.path.join(HERE, "make_effects.py"), a.script])
    gp = base_ + ".gloss.json"   # 越南语词义：每次渲染自动更新（脚本写法 > 词库 > 机器翻译）
    if not a.skip_glossary:
        subprocess.call([venv_py if os.path.exists(venv_py) else sys.executable, os.path.join(HERE, "glossary.py"), a.script, "--outdir", os.path.join(HERE, "out")])
    import styles.chat_common as _cc
    _cc.GLOSS.clear(); _cc.GLOSS.update(json.load(open(gp, encoding="utf-8")) if os.path.exists(gp) else {})
    align = json.load(open(alp, encoding="utf-8")) if os.path.exists(alp) else None
    fx = json.load(open(fxp, encoding="utf-8"))["effects"] if os.path.exists(fxp) else []
    mix = _load_json(base_ + ".mix.json", {})
    ep = resolve_episode(mix, a.script, shots, align)
    fx = list(fx)
    for w in ep["words"]:
        fx.append(dict(type="vocab", t=w["t"], dur=0.5, desc=f"vocab:{w['word']}"))
        fx.append(dict(type="chalk", t=w["t"] + w["dur"], dur=0.15, desc=f"chalk:{w['word']}"))
        print(f"  单词卡 {w['word']} @ {w['t']:.2f}s  停留 {w['dur']:.1f}s 飞入 {w['fly']:.1f}s")
    st = dict(chars=chars, title=title, board=board, fade=FADE, shots=shots, audio_dur=adur, align=align, fx=fx, mix=mix, episode=ep, words=ep["words"], audio=a.audio, no_endcard=bool(a.no_endcard))

    def shot_at(t):
        for s in shots:
            if s["t0"] <= t < s["end"]: return s
        return shots[0] if t < shots[0]["t0"] else shots[-1]

    if a.still is not None:  # 只出一张静帧（风格预览）
        s = shot_at(a.still); i = shots.index(s)
        style.draw_frame(dict(st, t=a.still, shot=s, prev=shots[i-1] if i else None)).save(a.out); print("静帧:", a.out); return
    extra, fc, amap = build_audio_mix(a.start, dur, adur, fx, a, base_)
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
    if fc:
        # 完整解码后再 atrim，避免 mp3 输入 -ss 不精确导致音效和画面错位
        cmd += ["-i", a.audio]
        cmd += extra
        cmd += ["-filter_complex", fc, "-map", "0:v", "-map", amap]
    else:
        cmd += ["-ss", str(a.start), "-t", str(dur), "-i", a.audio, "-map", "0:v", "-map", "1:a"]
    cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", "20",
            "-profile:v", "main", "-level:v", "4.0", "-pix_fmt", "yuv420p", "-tag:v", "avc1",
            "-c:a", "aac", "-ar", "48000", "-ac", "2", "-b:a", "192k",
            "-map_metadata", "-1", "-map_chapters", "-1", "-fflags", "+bitexact",
            "-shortest", "-movflags", "+faststart", a.out]
    pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    nf = int(round(dur * FPS))
    for i in range(nf):
        t = a.start + i / FPS; s = shot_at(t); j = shots.index(s)
        im = style.draw_frame(dict(st, t=t, shot=s, prev=shots[j-1] if j else None))
        pr.stdin.write(im.tobytes())
        if i % 90 == 0: print(f"\r{i}/{nf} 帧", end="", flush=True)
    pr.stdin.close(); pr.wait(); print(f"\n完成: {a.out}")
    if pr.returncode:
        sys.exit(pr.returncode)

if __name__ == "__main__":
    main()
